package eu.pb4.polymer.common.impl;


import eu.pb4.polymer.common.mixin.ReferenceAccessor;
import eu.pb4.polymer.common.mixin.WorldAccessor;
import io.netty.util.internal.shaded.org.jctools.util.UnsafeAccess;
import it.unimi.dsi.fastutil.objects.ObjectIterators;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderOwner;
import net.minecraft.core.HolderSet;
import net.minecraft.core.Registry;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.registry.*;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.AbortableIterationConsumer;
import net.minecraft.util.RandomSource;
import net.minecraft.util.profiling.ActiveProfiler;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.*;
import net.minecraft.world.damagesource.DamageScaling;
import net.minecraft.world.damagesource.DamageSources;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.animal.WolfVariant;
import net.minecraft.world.entity.decoration.PaintingVariant;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.flag.FeatureFlagSet;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.item.alchemy.PotionBrewing;
import net.minecraft.world.item.crafting.RecipeManager;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeManager;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BannerPattern;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.border.WorldBorder;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ChunkSource;
import net.minecraft.world.level.chunk.LightChunk;
import net.minecraft.world.level.chunk.LightChunkGetter;
import net.minecraft.world.level.chunk.status.ChunkStatus;
import net.minecraft.world.level.dimension.BuiltinDimensionTypes;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.world.level.entity.EntityTypeTest;
import net.minecraft.world.level.entity.LevelEntityGetter;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.level.lighting.ChunkSkyLightSources;
import net.minecraft.world.level.lighting.LevelLightEngine;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.saveddata.maps.MapId;
import net.minecraft.world.level.saveddata.maps.MapItemSavedData;
import net.minecraft.world.level.storage.WritableLevelData;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.scores.Scoreboard;
import net.minecraft.world.ticks.LevelTickAccess;
import net.minecraft.world.ticks.ScheduledTick;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.stream.Stream;

@SuppressWarnings({"rawtypes", "unchecked"})
@ApiStatus.Internal
public final class FakeWorld extends Level implements LightChunk {
    public static final Level INSTANCE;

    public static final Level INSTANCE_UNSAFE;
    public static final Level INSTANCE_REGULAR;
    static final Scoreboard SCOREBOARD = new Scoreboard();

    static final RegistryAccess FALLBACK_REGISTRY_MANAGER = new RegistryAccess.Frozen() {
        private static final Map<ResourceKey<?>, Registry<?>> REGISTRIES = new HashMap<>();
        @Override
        public Optional<Registry> registry(ResourceKey key) {
            var x = BuiltInRegistries.REGISTRY.get(key);
            if (x != null) {
                return Optional.of(x);
            }

            var reg = REGISTRIES.get(key);

            if (reg != null) {
                return Optional.of(reg);
            }

            return Optional.empty();
        }

        @Override
        public Stream<RegistryEntry<?>> registries() {
            return Stream.empty();
        }

        public static void addRegistry(FakeRegistry<?> registry) {
            REGISTRIES.put(registry.key(), registry);
        }

        static {
            addRegistry(new FakeRegistry<>(Registries.DAMAGE_TYPE, ResourceLocation.fromNamespaceAndPath("polymer","fake_damage"),
                    new DamageType("", DamageScaling.NEVER, 0)));
            addRegistry(new FakeRegistry<>(Registries.BANNER_PATTERN,
                    ResourceLocation.fromNamespaceAndPath("polymer","fake_pattern"),
                    new BannerPattern(ResourceLocation.fromNamespaceAndPath("polymer","fake_pattern"), "")));
            addRegistry(new FakeRegistry<>(Registries.PAINTING_VARIANT,
                    ResourceLocation.fromNamespaceAndPath("polymer","painting"),
                    new PaintingVariant(1, 1, ResourceLocation.fromNamespaceAndPath("polymer","painting"))));
            addRegistry(new FakeRegistry<>(Registries.WOLF_VARIANT,
                    ResourceLocation.fromNamespaceAndPath("polymer","wolf"),
                    new WolfVariant(ResourceLocation.fromNamespaceAndPath("polymer","wolf"), ResourceLocation.fromNamespaceAndPath("polymer","wolf"),ResourceLocation.fromNamespaceAndPath("polymer","wolf"), HolderSet.empty())));
        }
    };
    static final RecipeManager RECIPE_MANAGER = new RecipeManager(FALLBACK_REGISTRY_MANAGER);
    private static final FeatureFlagSet FEATURES = FeatureFlags.REGISTRY.allFlags();
    final ChunkSource chunkManager = new ChunkSource() {
        private LevelLightEngine lightingProvider = null;

        @Nullable
        @Override
        public ChunkAccess getChunk(int x, int z, ChunkStatus leastStatus, boolean create) {
            return null;
        }

        @Override
        public void tick(BooleanSupplier shouldKeepTicking, boolean tickChunks) {

        }

        @Override
        public String gatherStats() {
            return "Potato";
        }

        @Override
        public int getLoadedChunksCount() {
            return 0;
        }

        @Override
        public LevelLightEngine getLightEngine() {
            if (this.lightingProvider == null) {
                this.lightingProvider = new LevelLightEngine(new LightChunkGetter() {
                    @Nullable
                    @Override
                    public LightChunk getChunkForLighting(int chunkX, int chunkZ) {
                        return FakeWorld.this;
                    }

                    @Override
                    public BlockGetter getLevel() {
                        return FakeWorld.this;
                    }
                }, false, false);
            }

            return this.lightingProvider;
        }

        @Override
        public BlockGetter getLevel() {
            return FakeWorld.this;
        }
    };
    private static final LevelEntityGetter<Entity> ENTITY_LOOKUP = new LevelEntityGetter<>() {
        @Nullable
        @Override
        public Entity get(int id) {
            return null;
        }

        @Nullable
        @Override
        public Entity get(UUID uuid) {
            return null;
        }

        @Override
        public Iterable<Entity> getAll() {
            return () -> ObjectIterators.emptyIterator();
        }

        @Override
        public <U extends Entity> void get(EntityTypeTest<Entity, U> filter, AbortableIterationConsumer<U> consumer) {

        }

        @Override
        public void get(AABB box, Consumer<Entity> action) {

        }

        @Override
        public <U extends Entity> void get(EntityTypeTest<Entity, U> filter, AABB box, AbortableIterationConsumer<U> consumer) {

        }

    };
    private static final LevelTickAccess<?> FAKE_SCHEDULER = new LevelTickAccess<Object>() {
        @Override
        public boolean willTickThisTick(BlockPos pos, Object type) {
            return false;
        }

        @Override
        public void schedule(ScheduledTick<Object> orderedTick) {

        }

        @Override
        public boolean hasScheduledTick(BlockPos pos, Object type) {
            return false;
        }

        @Override
        public int count() {
            return 0;
        }
    };

    static {
        Level worldUnsafe, worldDefault;

        var dimType = Holder.Reference.createIntrusive(new HolderOwner<>() {}, new DimensionType(OptionalLong.empty(), true, false, false, true, 1.0D, true, false, -64, 384, 384, BlockTags.INFINIBURN_OVERWORLD, BuiltinDimensionTypes.OVERWORLD_EFFECTS, 0.0F, new DimensionType.MonsterSettings(false, true, UniformInt.of(0, 7), 0)));
        ((ReferenceAccessor) dimType).callSetRegistryKey(ResourceKey.create(Registries.DIMENSION_TYPE, ResourceLocation.parse("overworld")));
        try {
            worldUnsafe = (FakeWorld) UnsafeAccess.UNSAFE.allocateInstance(FakeWorld.class);
            var accessor = (WorldAccessor) worldUnsafe;
            accessor.polymer$setBiomeAccess(new BiomeManager(worldUnsafe, 1l));
            accessor.polymer$setBorder(new WorldBorder());
            accessor.polymer$setDebugWorld(true);
            accessor.polymer$setProfiler(() -> new ActiveProfiler(() -> 0l, () -> 0, false));
            accessor.polymer$setProperties(new FakeWorldProperties());
            accessor.polymer$setRegistryKey(ResourceKey.create(Registries.DIMENSION, ResourceLocation.fromNamespaceAndPath("polymer","fake_world")));
            //accessor.polymer$setDimensionKey(DimensionTypes.OVERWORLD);
            accessor.polymer$setDimensionEntry(dimType);
            accessor.polymer$setThread(Thread.currentThread());
            accessor.polymer$setRandom(RandomSource.create());
            accessor.polymer$setAsyncRandom(RandomSource.createThreadSafe());
            accessor.polymer$setBlockEntityTickers(new ArrayList<>());
            accessor.polymer$setPendingBlockEntityTickers(new ArrayList<>());
            try {
                accessor.polymer$setDamageSources(new DamageSources(FALLBACK_REGISTRY_MANAGER));
            } catch (Throwable e) {

            }

        } catch (Throwable e) {
            CommonImpl.LOGGER.error("Creating fake world with unsafe failed...", e);
            worldUnsafe = null;
        }

        try {
            worldDefault = new FakeWorld(
                    new FakeWorldProperties(),
                    ResourceKey.create(Registries.DIMENSION, ResourceLocation.fromNamespaceAndPath("polymer", "fake_world")),
                    dimType,
                    () -> new ActiveProfiler(() -> 0l, () -> 0, false),
                    false,
                    true,
                    1
            );
        } catch (Throwable e) {
            CommonImpl.LOGGER.error("Creating fake world in regular way failed...", e);
            worldDefault = null;
        }


        INSTANCE_UNSAFE = worldUnsafe;
        INSTANCE_REGULAR = worldDefault;

        INSTANCE = worldUnsafe != null ? worldUnsafe : worldDefault;
    }

    private TickRateManager tickManager = new TickRateManager();

    protected FakeWorld(WritableLevelData properties, ResourceKey<Level> registryRef, Holder<DimensionType> dimensionType, Supplier<ProfilerFiller> profiler, boolean isClient, boolean debugWorld, long seed) {
        super(properties, registryRef, FALLBACK_REGISTRY_MANAGER, dimensionType, profiler, isClient, debugWorld, seed, 0);
    }

    @Override
    public void sendBlockUpdated(BlockPos pos, BlockState oldState, BlockState newState, int flags) {

    }

    @Override
    public void playSeededSound(@Nullable Player except, double x, double y, double z, Holder<SoundEvent> registryEntry, SoundSource category, float volume, float pitch, long seed) {

    }

    @Override
    public void playSeededSound(@Nullable Player except, Entity entity, Holder<SoundEvent> registryEntry, SoundSource category, float volume, float pitch, long seed) {

    }

    @Override
    public void playSound(@Nullable Player player, double x, double y, double z, SoundEvent sound, SoundSource category, float volume, float pitch) {

    }

    @Override
    public void playSound(@Nullable Player player, Entity entity, SoundEvent sound, SoundSource category, float volume, float pitch) {

    }

    @Override
    public String gatherChunkSourceStats() {
        return "FakeWorld!";
    }

    @Nullable
    @Override
    public Entity getEntity(int id) {
        return null;
    }

    @Override
    public TickRateManager tickRateManager() {
        return this.tickManager;
    }

    @Nullable
    @Override
    public MapItemSavedData getMapData(MapId id) {
        return null;
    }

    @Override
    public void setMapData(MapId id, MapItemSavedData state) {

    }

    @Override
    public MapId getFreeMapId() {
        return null;
    }

    @Override
    public void destroyBlockProgress(int entityId, BlockPos pos, int progress) {

    }

    @Override
    public Scoreboard getScoreboard() {
        return SCOREBOARD;
    }

    @Override
    public RecipeManager getRecipeManager() {
        return RECIPE_MANAGER;
    }

    @Override
    protected LevelEntityGetter<Entity> getEntities() {
        return ENTITY_LOOKUP;
    }

    @Override
    public LevelTickAccess<Block> getBlockTicks() {
        return (LevelTickAccess<Block>) FAKE_SCHEDULER;
    }

    @Override
    public LevelTickAccess<Fluid> getFluidTicks() {
        return (LevelTickAccess<Fluid>) FAKE_SCHEDULER;
    }

    @Override
    public ChunkSource getChunkSource() {
        return chunkManager;
    }

    @Override
    public void levelEvent(@Nullable Player player, int eventId, BlockPos pos, int data) {

    }

    @Override
    public void gameEvent(Holder<GameEvent> event, Vec3 emitterPos, GameEvent.Context emitter) {

    }
    @Override
    public RegistryAccess registryAccess() {
        return FALLBACK_REGISTRY_MANAGER;
    }

    @Override
    public PotionBrewing potionBrewing() {
        return null;
    }

    @Override
    public FeatureFlagSet enabledFeatures() {
        return FEATURES;
    }

    @Override
    public float getShade(Direction direction, boolean shaded) {
        return 0;
    }

    @Override
    public List<? extends Player> players() {
        return Collections.emptyList();
    }

    @Override
    public Holder<Biome> getUncachedNoiseBiome(int biomeX, int biomeY, int biomeZ) {
        return null;//BuiltinRegistries.BIOME.getEntry(BiomeKeys.THE_VOID).get();
    }

    @Override
    public void findBlockLightSources(BiConsumer<BlockPos, BlockState> callback) {

    }

    @Override
    public ChunkSkyLightSources getSkyLightSources() {
        return null;
    }


    static class FakeWorldProperties implements WritableLevelData {
        @Override
        public BlockPos getSpawnPos() {
            return BlockPos.ZERO;
        }

        @Override
        public float getSpawnAngle() {
            return 0;
        }

        @Override
        public long getGameTime() {
            return 0;
        }

        @Override
        public long getDayTime() {
            return 0;
        }

        @Override
        public boolean isThundering() {
            return false;
        }

        @Override
        public boolean isRaining() {
            return false;
        }

        @Override
        public void setRaining(boolean raining) {

        }

        @Override
        public boolean isHardcore() {
            return false;
        }

        @Override
        public GameRules getGameRules() {
            return new GameRules();
        }

        @Override
        public Difficulty getDifficulty() {
            return Difficulty.NORMAL;
        }

        @Override
        public boolean isDifficultyLocked() {
            return false;
        }

        @Override
        public void setSpawn(BlockPos pos, float angle) {

        }
    }
}
