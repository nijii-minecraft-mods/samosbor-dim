package eu.pb4.polymer.common.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import java.util.function.Supplier;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceKey;
import net.minecraft.util.RandomSource;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraft.world.damagesource.DamageSources;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.BiomeManager;
import net.minecraft.world.level.block.entity.TickingBlockEntity;
import net.minecraft.world.level.border.WorldBorder;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.world.level.storage.WritableLevelData;

@Mixin(Level.class)
public interface WorldAccessor {
    @Mutable
    @Accessor("thread")
    void polymer$setThread(Thread thread);

    @Mutable
    @Accessor("debugWorld")
    void polymer$setDebugWorld(boolean debugWorld);

    @Mutable
    @Accessor("properties")
    void polymer$setProperties(WritableLevelData properties);

    @Mutable
    @Accessor("profiler")
    void polymer$setProfiler(Supplier<ProfilerFiller> profiler);

    @Mutable
    @Accessor("border")
    void polymer$setBorder(WorldBorder border);

    @Mutable
    @Accessor("biomeAccess")
    void polymer$setBiomeAccess(BiomeManager biomeAccess);

    @Mutable
    @Accessor("registryKey")
    void polymer$setRegistryKey(ResourceKey<Level> registryKey);

    @Mutable
    @Accessor("dimensionEntry")
    void polymer$setDimensionEntry(Holder<DimensionType> dimensionEntry);

    @Mutable
    @Accessor("random")
    void polymer$setRandom(RandomSource random);

    @Mutable
    @Accessor("threadSafeRandom")
    void polymer$setAsyncRandom(RandomSource random);

    @Mutable
    @Accessor("blockEntityTickers")
    void polymer$setBlockEntityTickers(List<TickingBlockEntity> list);

    @Mutable
    @Accessor("pendingBlockEntityTickers")
    void polymer$setPendingBlockEntityTickers(List<TickingBlockEntity> list);

    @Mutable
    @Accessor("damageSources")
    void polymer$setDamageSources(DamageSources sources);
}
