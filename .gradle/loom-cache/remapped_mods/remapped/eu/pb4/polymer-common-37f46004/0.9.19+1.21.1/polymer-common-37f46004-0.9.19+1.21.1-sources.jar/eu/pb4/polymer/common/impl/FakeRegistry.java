package eu.pb4.polymer.common.impl;

import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Lifecycle;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.stream.Stream;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.HolderOwner;
import net.minecraft.core.HolderSet;
import net.minecraft.core.RegistrationInfo;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.util.RandomSource;

public record FakeRegistry<T>(ResourceKey<? extends Registry<T>> registryKey, ResourceLocation defaultId, T defaultValue) implements Registry<T>, HolderOwner<T> {

    @Override
    public ResourceKey<? extends Registry<T>> key() {
        return registryKey;
    }

    @Nullable
    @Override
    public ResourceLocation getKey(T value) {
        return defaultId;
    }

    @Override
    public Optional<ResourceKey<T>> getResourceKey(T entry) {
        return Optional.of(ResourceKey.create(registryKey, defaultId));
    }

    @Override
    public int getId(@Nullable T value) {
        return 0;
    }

    @Nullable
    @Override
    public T byId(int index) {
        return defaultValue;
    }

    @Override
    public int size() {
        return 1;
    }

    @Nullable
    @Override
    public T get(@Nullable ResourceKey<T> key) {
        return defaultValue;
    }

    @Nullable
    @Override
    public T get(@Nullable ResourceLocation id) {
        return defaultValue;
    }

    @Override
    public Optional<RegistrationInfo> registrationInfo(ResourceKey<T> key) {
        return Optional.of(RegistrationInfo.BUILT_IN);
    }

    @Override
    public Lifecycle registryLifecycle() {
        return Lifecycle.experimental();
    }

    @Override
    public Optional<Holder.Reference<T>> getAny() {
        return Optional.of(createIntrusiveHolder(defaultValue));
    }

    @Override
    public Set<ResourceLocation> keySet() {
        return Set.of(defaultId);
    }

    @Override
    public Set<Map.Entry<ResourceKey<T>, T>> entrySet() {
        return Set.of();
    }

    @Override
    public Set<ResourceKey<T>> registryKeySet() {
        return Set.of();
    }

    @Override
    public Optional<Holder.Reference<T>> getRandom(RandomSource random) {
        return Optional.empty();
    }

    @Override
    public boolean containsKey(ResourceLocation id) {
        return true;
    }

    @Override
    public boolean containsKey(ResourceKey<T> key) {
        return true;
    }

    @Override
    public Registry<T> freeze() {
        return this;
    }

    @Override
    public Holder.Reference<T> createIntrusiveHolder(T value) {
        return Holder.Reference.createIntrusive(this, value);
    }

    @Override
    public Optional<Holder.Reference<T>> getHolder(int rawId) {
        return getAny();
    }

    @Override
    public Optional<Holder.Reference<T>> getHolder(ResourceLocation id) {
        return getAny();
    }

    @Override
    public Optional<Holder.Reference<T>> getHolder(ResourceKey<T> key) {
        return Optional.of(Holder.Reference.createStandAlone(this, key));
    }

    @Override
    public Holder<T> wrapAsHolder(T value) {
        return Holder.direct(value);
    }

    @Override
    public Stream<Holder.Reference<T>> holders() {
        return Stream.empty();
    }

    @Override
    public Optional<HolderSet.Named<T>> getTag(TagKey<T> tag) {
        return Optional.empty();
    }

    @Override
    public HolderSet.Named<T> getOrCreateTag(TagKey<T> tag) {
        return HolderSet.emptyNamed(this, tag);
    }

    @Override
    public Stream<Pair<TagKey<T>, HolderSet.Named<T>>> getTags() {
        return Stream.empty();
    }

    @Override
    public Stream<TagKey<T>> getTagNames() {
        return Stream.empty();
    }

    @Override
    public void resetTags() {

    }

    @Override
    public void bindTags(Map<TagKey<T>, List<Holder<T>>> tagEntries) {

    }

    @Override
    public HolderOwner<T> holderOwner() {
        return this;
    }

    @Override
    public HolderLookup.RegistryLookup<T> asLookup() {
        return new HolderLookup.RegistryLookup<T>() {
            @Override
            public ResourceKey<? extends Registry<? extends T>> key() {
                return FakeRegistry.this.registryKey;
            }

            @Override
            public Lifecycle registryLifecycle() {
                return Lifecycle.experimental();
            }

            @Override
            public Stream<Holder.Reference<T>> listElements() {
                return Stream.empty();
            }

            @Override
            public Stream<HolderSet.Named<T>> listTags() {
                return Stream.empty();
            }

            @Override
            public Optional<Holder.Reference<T>> get(ResourceKey<T> key) {
                return getAny();
            }

            @Override
            public Optional<HolderSet.Named<T>> get(TagKey<T> tag) {
                return Optional.empty();
            }
        };
    }

    @NotNull
    @Override
    public Iterator<T> iterator() {
        return new Iterator<T>() {
            @Override
            public boolean hasNext() {
                return false;
            }

            @Override
            public T next() {
                return null;
            }
        };
    }
}
