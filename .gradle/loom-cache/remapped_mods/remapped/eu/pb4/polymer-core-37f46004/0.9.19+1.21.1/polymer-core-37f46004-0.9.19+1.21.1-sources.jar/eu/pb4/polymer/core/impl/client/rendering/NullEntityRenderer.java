package eu.pb4.polymer.core.impl.client.rendering;

import com.mojang.blaze3d.vertex.PoseStack;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.NoopRenderer;
import net.minecraft.world.entity.Entity;

@Environment(EnvType.CLIENT)
public class NullEntityRenderer extends NoopRenderer<Entity> {
    public static final EntityRenderer<Entity> INSTANCE = new NullEntityRenderer();

    private NullEntityRenderer() {
        super(new EntityRendererProvider.Context(null, null, null, null, null, null, null));
    }

    @Override
    public boolean shouldRender(Entity entity, Frustum frustum, double x, double y, double z) {
        return false;
    }

    @Override
    public void render(Entity entity, float yaw, float tickDelta, PoseStack matrices, MultiBufferSource vertexConsumers, int light) {

    }
}
