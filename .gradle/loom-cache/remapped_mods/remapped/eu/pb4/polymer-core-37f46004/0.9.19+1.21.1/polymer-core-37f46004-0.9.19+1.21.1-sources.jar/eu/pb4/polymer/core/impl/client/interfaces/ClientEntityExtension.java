package eu.pb4.polymer.core.impl.client.interfaces;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
@Environment(EnvType.CLIENT)
public interface ClientEntityExtension {
    void polymer$setId(ResourceLocation id);
    ResourceLocation polymer$getId();
}
