package eu.pb4.polymer.core.mixin.item.component;

import eu.pb4.polymer.core.api.utils.PolymerObject;
import eu.pb4.polymer.core.impl.TransformingComponent;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import xyz.nucleoid.packettweaker.PacketContext;

import java.util.List;
import java.util.Optional;
import net.minecraft.core.Holder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.item.alchemy.PotionContents;

@Mixin(PotionContents.class)
public abstract class PotionContentsComponentMixin implements TransformingComponent {

    @Shadow @Final private List<MobEffectInstance> customEffects;

    @Shadow public abstract int getColor();

    @SuppressWarnings("OptionalUsedAsFieldOrParameterType")
    @Shadow @Final private Optional<Holder<Potion>> potion;

    @Override
    public Object polymer$getTransformed(PacketContext context) {
        if (!polymer$requireModification(context)) {
            return this;
        }

        return new PotionContents(Optional.empty(), Optional.of(this.getColor()), List.of());
    }

    @Override
    public boolean polymer$requireModification(PacketContext context) {
        if (this.potion.isPresent() && this.potion.get().value() instanceof PolymerObject) {
            return true;
        }

        for (MobEffectInstance statusEffectInstance : this.customEffects) {
            if (statusEffectInstance.getEffect().value() instanceof PolymerObject) {
                return true;
            }
        }
        return false;
    }
}
