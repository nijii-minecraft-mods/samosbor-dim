package eu.pb4.polymer.core.impl.client;

import eu.pb4.polymer.core.api.client.ClientPolymerEntry;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;

public record ClientPolymerEntryImpl<T>(ResourceLocation identifier, @Nullable T registryEntry) implements ClientPolymerEntry<T> {
}
