package eu.pb4.polymer.core.api.utils;

import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;
import net.minecraft.core.IdMap;
import net.minecraft.resources.ResourceLocation;

@ApiStatus.NonExtendable
public interface PolymerRegistry<T> extends IdMap<T> {
    @Nullable
    T get(ResourceLocation identifier);

    @Nullable
    T byId(int id);

    @Nullable
    T getDirect(ResourceLocation identifier);

    @Nullable
    ResourceLocation getId(T entry);
    int getId(T entry);
    Iterable<ResourceLocation> ids();
    Iterable<Map.Entry<ResourceLocation, T>> entries();

    Set<T> getTag(ResourceLocation tag);
    Collection<ResourceLocation> getTags();
    Collection<ResourceLocation> getTagsOf(T entry);
    int size();

    boolean contains(ResourceLocation id);
    boolean containsEntry(T entry);

    Stream<T> stream();
}
