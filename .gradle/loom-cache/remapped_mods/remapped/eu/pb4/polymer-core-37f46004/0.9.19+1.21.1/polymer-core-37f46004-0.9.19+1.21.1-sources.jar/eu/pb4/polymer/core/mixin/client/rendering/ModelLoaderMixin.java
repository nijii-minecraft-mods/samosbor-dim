package eu.pb4.polymer.core.mixin.client.rendering;

import eu.pb4.polymer.core.api.item.PolymerItem;
import eu.pb4.polymer.core.api.utils.PolymerKeepModel;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.resources.model.ModelBakery;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Environment(EnvType.CLIENT)
@Mixin(ModelBakery.class)
public class ModelLoaderMixin {
    @ModifyVariable(method = "<init>", at = @At("STORE"), ordinal = 0, require = 0)
    private ResourceLocation polymer$skipPolymerItems(ResourceLocation identifier) {
        return BuiltInRegistries.ITEM.get(identifier) instanceof PolymerItem item && !PolymerKeepModel.is(item) ? ResourceLocation.parse("air") : identifier;
    }
}
