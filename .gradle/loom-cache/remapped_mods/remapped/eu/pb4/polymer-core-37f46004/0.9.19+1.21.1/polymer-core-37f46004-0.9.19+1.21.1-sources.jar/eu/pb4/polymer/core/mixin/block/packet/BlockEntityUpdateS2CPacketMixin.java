package eu.pb4.polymer.core.mixin.block.packet;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import eu.pb4.polymer.core.api.block.PolymerBlockUtils;
import eu.pb4.polymer.core.impl.networking.TransformingPacketCodec;
import eu.pb4.polymer.core.mixin.block.BlockEntityUpdateS2CPacketAccessor;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import xyz.nucleoid.packettweaker.PacketContext;

@Mixin(ClientboundBlockEntityDataPacket.class)
public class BlockEntityUpdateS2CPacketMixin {
    @ModifyExpressionValue(method = "<clinit>", at = @At(value = "INVOKE", target = "Lnet/minecraft/network/codec/PacketCodec;tuple(Lnet/minecraft/network/codec/PacketCodec;Ljava/util/function/Function;Lnet/minecraft/network/codec/PacketCodec;Ljava/util/function/Function;Lnet/minecraft/network/codec/PacketCodec;Ljava/util/function/Function;Lcom/mojang/datafixers/util/Function3;)Lnet/minecraft/network/codec/PacketCodec;"))
    private static StreamCodec<RegistryFriendlyByteBuf, ClientboundBlockEntityDataPacket> changeNbt(StreamCodec<RegistryFriendlyByteBuf, ClientboundBlockEntityDataPacket> original) {
        return TransformingPacketCodec.encodeOnly(original, (buf, packet) -> {
            if (packet.getTag() == null) {
                return packet;
            }
            var nbt = PolymerBlockUtils.transformBlockEntityNbt(PacketContext.get(), packet.getType(), packet.getTag());
            if (packet.getTag() == nbt) {
                return packet;
            }
            return BlockEntityUpdateS2CPacketAccessor.createBlockEntityUpdateS2CPacket(packet.getPos(), packet.getType(), nbt);
        });
    }
}
