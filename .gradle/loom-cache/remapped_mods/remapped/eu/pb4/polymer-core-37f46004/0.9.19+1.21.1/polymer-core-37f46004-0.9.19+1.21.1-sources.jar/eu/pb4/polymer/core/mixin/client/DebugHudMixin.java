package eu.pb4.polymer.core.mixin.client;

import eu.pb4.polymer.core.api.client.ClientPolymerBlock;
import eu.pb4.polymer.core.api.client.ClientPolymerBlock.State;
import eu.pb4.polymer.core.api.client.ClientPolymerEntityType;
import eu.pb4.polymer.core.api.client.PolymerClientUtils;
import eu.pb4.polymer.core.impl.PolymerImpl;
import eu.pb4.polymer.core.impl.client.InternalClientRegistry;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.DebugScreenOverlay;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.List;
import java.util.Map.Entry;

@Environment(EnvType.CLIENT)
@Mixin(DebugScreenOverlay.class)
public abstract class DebugHudMixin {
    @Shadow private HitResult blockHit;

    @Shadow @Final private Minecraft client;

    @Inject(method = "getRightText", at = @At(value = "INVOKE", target = "Ljava/util/List;add(Ljava/lang/Object;)Z", ordinal = 2), locals = LocalCapture.CAPTURE_FAILSOFT)
    private void polymer$replaceBlockString(CallbackInfoReturnable<List<String>> cir, long l, long m, long n, long o, List<String> list) {
        if (this.blockHit.getType() == HitResult.Type.BLOCK && InternalClientRegistry.enabled) {
            var blockPos = ((BlockHitResult)this.blockHit).getBlockPos();
            var block = InternalClientRegistry.getBlockAt(blockPos);
            var worldState = this.client.level.getBlockState(blockPos);
            if (block != ClientPolymerBlock.NONE_STATE && block.blockState() != worldState) {
                list.add(block.block().identifier().toString());
                for (var entry : block.states().entrySet()) {
                    list.add(entry.getKey() + ": " + switch (entry.getValue()) {
                        case "true" -> ChatFormatting.GREEN + "true";
                        case "false" -> ChatFormatting.RED + "false";
                        default -> entry.getValue();
                    });
                }
                list.add("");
                list.add(ChatFormatting.UNDERLINE + "Targeted Client Block: " + blockPos.getX() + ", " + blockPos.getY() + ", " + blockPos.getZ());
            }
        }
    }

    @Inject(method = "getRightText", at = @At(value = "INVOKE", target = "Ljava/util/List;add(Ljava/lang/Object;)Z", ordinal = 9), locals = LocalCapture.CAPTURE_FAILSOFT)
    private void polymer$replaceEntityString(CallbackInfoReturnable<List<String>> cir, long l, long m, long n, long o, List<String> list) {
        if (this.client.crosshairPickEntity != null && InternalClientRegistry.enabled) {
            var type = PolymerClientUtils.getEntityType(this.client.crosshairPickEntity);

            if (type != null) {
                list.add(type.identifier().toString());
                list.add("");
                list.add(ChatFormatting.UNDERLINE + "Targeted Client Entity");
            }
        }
    }

    @Inject(method = "getLeftText", at = @At("RETURN"))
    private void polymer$debugText(CallbackInfoReturnable<List<String>> cir) {
        if (InternalClientRegistry.serverHasPolymer && PolymerImpl.DISPLAY_DEBUG_INFO_CLIENT) {
            var list = cir.getReturnValue();

            list.add(InternalClientRegistry.debugServerInfo);
            list.add(InternalClientRegistry.debugRegistryInfo);
        }
    }
}
