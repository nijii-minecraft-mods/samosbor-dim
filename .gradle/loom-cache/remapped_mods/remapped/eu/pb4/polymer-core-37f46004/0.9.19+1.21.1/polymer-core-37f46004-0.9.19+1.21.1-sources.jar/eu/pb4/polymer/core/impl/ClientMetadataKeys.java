package eu.pb4.polymer.core.impl;

import org.jetbrains.annotations.ApiStatus;

import static eu.pb4.polymer.core.impl.PolymerImplUtils.id;

import net.minecraft.resources.ResourceLocation;

@ApiStatus.Internal
public class ClientMetadataKeys {
    public static final ResourceLocation MINECRAFT_PROTOCOL = ServerMetadataKeys.MINECRAFT_PROTOCOL;
    public static final ResourceLocation BLOCKSTATE_BITS = id("core/blockstate_bits");
    public static final ResourceLocation ADVANCED_TOOLTIP = id("core/advanced_tooltip");
}
