package eu.pb4.polymer.core.mixin.block.packet;

import eu.pb4.polymer.core.api.block.BlockMapper;
import eu.pb4.polymer.core.api.block.PolymerBlockUtils;
import eu.pb4.polymer.core.api.utils.PolymerUtils;
import eu.pb4.polymer.core.impl.interfaces.ChunkDataS2CPacketInterface;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.BitSet;
import net.minecraft.network.protocol.game.ClientboundLevelChunkWithLightPacket;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.lighting.LevelLightEngine;

@Mixin(ClientboundLevelChunkWithLightPacket.class)
public class ChunkDataS2CPacketMixin implements ChunkDataS2CPacketInterface {
    @Unique
    private LevelChunk polymer$worldChunk;

    @Unique
    private BlockMapper polymer$usedMapper;

    @Unique
    private boolean polymer$hasPlayerDependentBlocks;

    @Inject(method = "<init>(Lnet/minecraft/world/chunk/WorldChunk;Lnet/minecraft/world/chunk/light/LightingProvider;Ljava/util/BitSet;Ljava/util/BitSet;)V", at = @At("TAIL"))
    private void polymer$storeWorldChunk(LevelChunk chunk, LevelLightEngine lightingProvider, BitSet bitSet, BitSet bitSet2, CallbackInfo ci) {
        this.polymer$worldChunk = chunk;
        this.polymer$usedMapper = BlockMapper.getFrom(PolymerUtils.getPlayerContext());
        for (var section : chunk.getSections()) {
            if (section != null && section.maybeHas(PolymerBlockUtils.IS_POLYMER_BLOCK_STATE_PREDICATE)) {
                this.polymer$hasPlayerDependentBlocks = true;
                break;
            }
        }
    }

    public LevelChunk polymer$getWorldChunk() {
        return this.polymer$worldChunk;
    }

    @Override
    public BlockMapper polymer$getMapper() {
        return this.polymer$usedMapper;
    }

    @Override
    public boolean polymer$hasPlayerDependentBlocks() {
        return this.polymer$hasPlayerDependentBlocks;
    }
}
