package eu.pb4.polymer.core.impl.networking;

import eu.pb4.polymer.core.api.block.PolymerBlock;
import eu.pb4.polymer.core.impl.PolymerImplUtils;
import eu.pb4.polymer.core.impl.interfaces.ChunkDataS2CPacketInterface;
import eu.pb4.polymer.core.impl.interfaces.PolymerBlockPosStorage;
import eu.pb4.polymer.core.impl.interfaces.PolymerPlayNetworkHandlerExtension;
import eu.pb4.polymer.core.mixin.block.packet.BlockUpdateS2CPacketAccessor;
import eu.pb4.polymer.core.mixin.block.packet.ChunkDeltaUpdateS2CPacketAccessor;
import java.util.Iterator;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundBlockUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundLevelChunkWithLightPacket;
import net.minecraft.network.protocol.game.ClientboundSectionBlocksUpdatePacket;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;

public class BlockPacketUtil {
    public static void sendFromPacket(Packet<?> packet, ServerGamePacketListenerImpl handler) {
        if (packet instanceof ClientboundBlockUpdatePacket blockUpdatePacket) {
            BlockState blockState = ((BlockUpdateS2CPacketAccessor) blockUpdatePacket).polymer$getState();
            if (PolymerImplUtils.POLYMER_STATES.contains(blockState)) {
                PolymerPlayNetworkHandlerExtension.of(handler).polymer$delayAfterSequence(new SendSingleBlockInfo(handler, blockUpdatePacket.getPos(), blockState));
            }
        } else if (packet instanceof ClientboundLevelChunkWithLightPacket) {
            LevelChunk wc = ((ChunkDataS2CPacketInterface) packet).polymer$getWorldChunk();
            PolymerBlockPosStorage wci = (PolymerBlockPosStorage) wc;
            if (wc != null && wci.polymer$hasAny()) {
                PolymerServerProtocol.sendSectionUpdate(handler, wc);

                var iterator = wci.polymer$iterator();
                while (iterator.hasNext()) {
                    var pos = iterator.next();
                    var blockState = wc.getBlockState(pos);
                    if (blockState.getBlock() instanceof PolymerBlock polymerBlock) {
                        polymerBlock.onPolymerBlockSend(blockState, pos, handler.player);
                    }
                }
            }
        } else if (packet instanceof ClientboundSectionBlocksUpdatePacket) {
            var chunk = (ChunkDeltaUpdateS2CPacketAccessor) packet;

            PolymerPlayNetworkHandlerExtension.of(handler).polymer$delayAfterSequence(new SendSequanceBlockInfo(handler,
                    chunk.polymer_getSectionPos(), chunk.polymer_getBlockStates(), chunk.polymer_getPositions()));
        }
    }

    public static void splitChunkDelta(ServerGamePacketListenerImpl handler, ClientboundSectionBlocksUpdatePacket cPacket) {
        cPacket.runUpdates((blockPos, blockState) -> handler.send(new ClientboundBlockUpdatePacket(blockPos.immutable(), blockState)));
    }

    private record SendSingleBlockInfo(ServerGamePacketListenerImpl handler, BlockPos pos, BlockState blockState) implements Runnable {
        @Override
        public void run() {
            PolymerServerProtocol.sendBlockUpdate(handler, pos, blockState);
            if (blockState.getBlock() instanceof PolymerBlock polymerBlock) {
                polymerBlock.onPolymerBlockSend(blockState, pos.mutable(), handler.player);
            }
        }
    }

    private record SendSequanceBlockInfo(ServerGamePacketListenerImpl handler, SectionPos chunkPos,
                                         BlockState[] blockStates, short[] localPos) implements Runnable {
        @Override
        public void run() {
            PolymerServerProtocol.sendMultiBlockUpdate(handler, chunkPos, localPos, blockStates);

            var blockPos = new BlockPos.MutableBlockPos();

            for (int i = 0; i < localPos.length; i++) {
                BlockState blockState = blockStates[i];
                blockPos.set(chunkPos.relativeToBlockX(localPos[i]), chunkPos.relativeToBlockY(localPos[i]), chunkPos.relativeToBlockZ(localPos[i]));

                if (blockState.getBlock() instanceof PolymerBlock) {
                    ((PolymerBlock) blockState.getBlock()).onPolymerBlockSend(blockState, blockPos, handler.player);
                }
            }
        }
    }
}
