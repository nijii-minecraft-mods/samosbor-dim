package eu.pb4.polymer.core.impl.networking;

import Z;
import eu.pb4.polymer.core.api.utils.PolymerSyncUtils;
import eu.pb4.polymer.core.api.utils.PolymerUtils;
import eu.pb4.polymer.core.impl.PolymerImplUtils;
import eu.pb4.polymer.core.impl.ServerMetadataKeys;
import eu.pb4.polymer.core.impl.interfaces.PolymerPlayNetworkHandlerExtension;
import eu.pb4.polymer.core.impl.networking.payloads.c2s.PolymerChangeTooltipC2SPayload;
import eu.pb4.polymer.core.impl.networking.payloads.c2s.PolymerPickBlockC2SPayload;
import eu.pb4.polymer.core.impl.networking.payloads.c2s.PolymerPickEntityC2SPayload;
import eu.pb4.polymer.networking.api.server.PolymerServerNetworking;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
public class PolymerServerProtocolHandler {
    @SuppressWarnings("ResultOfMethodCallIgnored")
    public static void register() {
        PolymerServerNetworking.registerPlayHandler(PolymerPickBlockC2SPayload.class, PolymerServerProtocolHandler::handlePickBlock);
        PolymerServerNetworking.registerPlayHandler(PolymerPickEntityC2SPayload.class, PolymerServerProtocolHandler::handlePickEntity);
        PolymerServerNetworking.registerPlayHandler(PolymerChangeTooltipC2SPayload.class, PolymerServerProtocolHandler::handleTooltipChange);

        PolymerServerNetworking.ON_PLAY_SYNC.register((handler, x) -> {
            PolymerServerProtocol.sendSyncPackets(handler, true);
        });

        ServerMetadataKeys.setup();
        S2CPackets.SYNC_BLOCK.getNamespace();
        C2SPackets.WORLD_PICK_BLOCK.getNamespace();
    }

    private static void handleTooltipChange(MinecraftServer server, ServerGamePacketListenerImpl handler, PolymerChangeTooltipC2SPayload payload) {
        handler.getPlayer().getServer().execute(() -> {
            PolymerPlayNetworkHandlerExtension.of(handler).polymer$setAdvancedTooltip(payload.advanced());

            if (PolymerServerNetworking.getLastPacketReceivedTime(handler, C2SPackets.CHANGE_TOOLTIP) + 1000 < System.currentTimeMillis()) {
                PolymerSyncUtils.synchronizeCreativeTabs(handler);
                PolymerUtils.reloadInventory(handler.player);
            }
        });
    }

    private static void handlePickBlock(MinecraftServer server, ServerGamePacketListenerImpl handler, PolymerPickBlockC2SPayload payload) {
        var pos = payload.pos();
        var ctr = payload.control();


        server.execute(() -> {
            if (pos.distManhattan(handler.player.blockPosition()) <= 32) {
                PolymerImplUtils.pickBlock(handler.player, pos, ctr);
            }
        });
    }

    private static void handlePickEntity(MinecraftServer server, ServerGamePacketListenerImpl handler, PolymerPickEntityC2SPayload payload) {
        server.execute(() -> {
            var entity = handler.player.serverLevel().getEntity(payload.entityId());

            if (entity != null && entity.position().vectorTo(handler.player.position()).lengthSqr() < 1024) {
                PolymerImplUtils.pickEntity(handler.player, entity);
            }
        });
    }
}
