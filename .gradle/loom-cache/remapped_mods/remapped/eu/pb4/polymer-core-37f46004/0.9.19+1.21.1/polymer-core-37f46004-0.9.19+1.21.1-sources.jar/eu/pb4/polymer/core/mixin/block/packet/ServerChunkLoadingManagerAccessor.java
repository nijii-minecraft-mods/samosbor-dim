package eu.pb4.polymer.core.mixin.block.packet;

import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import net.minecraft.server.level.ChunkMap;
import net.minecraft.server.level.ServerLevel;
import org.apache.commons.lang3.mutable.MutableObject;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(ChunkMap.class)
public interface ServerChunkLoadingManagerAccessor {

    @Accessor("world")
    ServerLevel polymer$getWorld();

    @Accessor("watchDistance")
    int polymer$getWatchDistance();

    @Accessor("entityTrackers")
    Int2ObjectMap<ChunkMap.TrackedEntity> polymer$getEntityTrackers();
}
