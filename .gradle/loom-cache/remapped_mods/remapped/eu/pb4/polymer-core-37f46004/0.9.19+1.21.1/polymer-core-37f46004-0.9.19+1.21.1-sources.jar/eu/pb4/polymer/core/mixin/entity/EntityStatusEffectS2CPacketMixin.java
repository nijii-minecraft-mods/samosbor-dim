package eu.pb4.polymer.core.mixin.entity;

import eu.pb4.polymer.core.impl.interfaces.StatusEffectPacketExtension;
import net.minecraft.core.Holder;
import net.minecraft.network.protocol.game.ClientboundUpdateMobEffectPacket;
import net.minecraft.world.effect.MobEffect;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(ClientboundUpdateMobEffectPacket.class)
public class EntityStatusEffectS2CPacketMixin implements StatusEffectPacketExtension {
    @Shadow @Final private Holder<MobEffect> effectId;

    @Override
    public MobEffect polymer$getStatusEffect() {
        return this.effectId.value();
    }
}
