package eu.pb4.polymer.core.mixin.other;


import I;
import eu.pb4.polymer.core.api.other.PolymerSoundEvent;
import eu.pb4.polymer.core.api.utils.PolymerObject;
import eu.pb4.polymer.core.api.utils.PolymerSyncedObject;
import eu.pb4.polymer.core.api.utils.PolymerUtils;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.util.ArrayList;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderSet;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.RegistryFriendlyByteBuf;

@Mixin(targets = "net/minecraft/network/codec/PacketCodecs$18", priority = 500)
public abstract class PacketCodecsRegistryEntryListMixin {
    @ModifyVariable(method = "encode(Lnet/minecraft/network/RegistryByteBuf;Lnet/minecraft/registry/entry/RegistryEntryList;)V", at = @At("HEAD"), argsOnly = true)
    private HolderSet polymer$changeData(HolderSet registryEntryList, RegistryFriendlyByteBuf registryByteBuf) {
        if (registryEntryList.unwrapKey().isEmpty()) {
            var player = PolymerUtils.getPlayerContext();

            if (player != null) {
                var arr = new ArrayList<Holder>();
                for (var i = 0; i < registryEntryList.size(); i++) {
                    var val = registryEntryList.get(i);
                    if (val.value() instanceof PolymerSoundEvent syncedObject) {
                        var replacement = syncedObject.getPolymerReplacement(PolymerUtils.getPlayerContext());

                        if (replacement instanceof PolymerSoundEvent) {
                            arr.add(Holder.direct(replacement));
                        }

                        arr.add(BuiltInRegistries.SOUND_EVENT.wrapAsHolder(replacement));
                    } else if ((val.value() instanceof PolymerSyncedObject<?> s && s.canSyncRawToClient(player)) || !(val.value() instanceof PolymerObject)) {
                        arr.add(val);
                    }
                }
            }
        }

        return registryEntryList;
    }

}