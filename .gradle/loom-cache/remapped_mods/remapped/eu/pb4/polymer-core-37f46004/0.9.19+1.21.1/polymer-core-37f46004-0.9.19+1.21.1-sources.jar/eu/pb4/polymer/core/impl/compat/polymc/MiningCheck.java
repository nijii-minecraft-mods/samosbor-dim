package eu.pb4.polymer.core.impl.compat.polymc;

import eu.pb4.polymer.core.api.block.PolymerBlockUtils;
import io.github.theepicblock.polymc.api.misc.PolyMapProvider;
import io.github.theepicblock.polymc.impl.Util;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.state.BlockState;

public class MiningCheck implements PolymerBlockUtils.MineEventListener {
    @Override
    public boolean onBlockMine(BlockState state, BlockPos pos, ServerPlayer player) {
        if (!Util.isPolyMapVanillaLike(player) || player.isCreative()) {
            return false;
        }

        var polyMap = PolyMapProvider.getPolyMap(player);
        return polyMap.getBlockPoly(state.getBlock()) != null || polyMap.getItemPoly(player.getMainHandItem().getItem()) != null;
    }
}
