package eu.pb4.polymer.core.impl.networking;

import eu.pb4.polymer.common.impl.CompatStatus;
import eu.pb4.polymer.common.impl.entity.InternalEntityHelpers;
import eu.pb4.polymer.core.api.block.PolymerBlockUtils;
import eu.pb4.polymer.core.api.entity.PolymerEntity;
import eu.pb4.polymer.core.api.other.PolymerStatusEffect;
import eu.pb4.polymer.core.api.utils.PolymerUtils;
import eu.pb4.polymer.core.impl.compat.ImmersivePortalsUtils;
import eu.pb4.polymer.core.impl.interfaces.EntityAttachedPacket;
import eu.pb4.polymer.core.impl.interfaces.StatusEffectPacketExtension;
import net.minecraft.network.packet.s2c.play.*;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.configuration.ClientboundUpdateEnabledFeaturesPacket;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.network.protocol.game.ClientboundBundlePacket;
import net.minecraft.network.protocol.game.ClientboundSetEquipmentPacket;
import net.minecraft.network.protocol.game.ClientboundUpdateAttributesPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.network.ServerCommonPacketListenerImpl;
import net.minecraft.server.network.ServerConfigurationPacketListenerImpl;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.flag.FeatureFlag;
import net.minecraft.world.flag.FeatureFlagSet;
import net.minecraft.world.flag.FeatureFlags;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

public class PacketPatcher {

    public static Packet<?> replace(ServerCommonPacketListenerImpl handler, Packet<?> packet) {
        if (handler.getClass() == ServerGamePacketListenerImpl.class) {
            if (packet instanceof ClientboundSetEquipmentPacket original && EntityAttachedPacket.get(original, original.getEntity()) instanceof PolymerEntity polymerEntity) {
                return EntityAttachedPacket.setIfEmpty(
                        new ClientboundSetEquipmentPacket(((Entity) polymerEntity).getId(), polymerEntity.getPolymerVisibleEquipment(original.getSlots(), ((ServerGamePacketListenerImpl) handler).getPlayer())),
                        (Entity) polymerEntity
                );
            }

            if (packet instanceof ClientboundBundlePacket bundleS2CPacket) {
                var list = new ArrayList<Packet<? super ClientGamePacketListener>>();
                var iterator = bundleS2CPacket.subPackets().iterator();
                while (iterator.hasNext()) {
                    var x = replace(handler, iterator.next());
                    if (!prevent(handler, x)) {
                        list.add((Packet<ClientGamePacketListener>) x);
                    }
                }

                return new ClientboundBundlePacket(list);
            }
        } else if (handler.getClass() == ServerConfigurationPacketListenerImpl.class) {
            if (packet instanceof ClientboundUpdateEnabledFeaturesPacket featuresS2CPacket) {
                var x = PolymerUtils.getClientEnabledFeatureFlags();

                if (x.isEmpty()) {
                    return packet;
                }

                FeatureFlagSet set = FeatureFlags.REGISTRY.subset(x.toArray(new FeatureFlag[0]));

                if (featuresS2CPacket.features().getClass() == HashSet.class) {
                    featuresS2CPacket.features().addAll(FeatureFlags.REGISTRY.toNames(set));
                } else {
                    var y = new HashSet<ResourceLocation>();
                    y.addAll(featuresS2CPacket.features());
                    y.addAll(FeatureFlags.REGISTRY.toNames(set));
                    return new ClientboundUpdateEnabledFeaturesPacket(y);
                }
            }

        }

        return packet;
    }

    public static void sendExtra(ServerCommonPacketListenerImpl handler, Packet<?> packet) {
        if (handler.getClass() == ServerGamePacketListenerImpl.class) {
            if (CompatStatus.IMMERSIVE_PORTALS) {
                ImmersivePortalsUtils.sendBlockPackets((ServerGamePacketListenerImpl) handler, packet);
            } else {
                BlockPacketUtil.sendFromPacket(packet, (ServerGamePacketListenerImpl) handler);
            }
        }
    }

    public static boolean prevent(ServerCommonPacketListenerImpl handler, Packet<?> packet) {
        if (handler.getClass() == ServerGamePacketListenerImpl.class) {
            var player = ((ServerGamePacketListenerImpl) handler).player;
            if ((
                    packet instanceof StatusEffectPacketExtension packet2
                            && ((packet2.polymer$getStatusEffect() instanceof PolymerStatusEffect pol && pol.getPolymerReplacement(player) == null))
            ) || !EntityAttachedPacket.shouldSend(packet, player)
            ) {
                return true;
            } else if ((packet instanceof ClientboundSetEquipmentPacket original && original.getSlots().isEmpty()) || !EntityAttachedPacket.shouldSend(packet, player)) {
                return true;
            } else if ((packet instanceof ClientboundUpdateAttributesPacket original
                    && EntityAttachedPacket.get(packet, original.getEntityId()) instanceof PolymerEntity entity
                    && !InternalEntityHelpers.isLivingEntity(entity.getPolymerEntityType(player)))) {
                return true;
            } else if (packet instanceof ClientboundBlockEntityDataPacket be && PolymerBlockUtils.isPolymerBlockEntityType(be.getType())) {
                return true;
            }
        }

        return false;
    }
}
