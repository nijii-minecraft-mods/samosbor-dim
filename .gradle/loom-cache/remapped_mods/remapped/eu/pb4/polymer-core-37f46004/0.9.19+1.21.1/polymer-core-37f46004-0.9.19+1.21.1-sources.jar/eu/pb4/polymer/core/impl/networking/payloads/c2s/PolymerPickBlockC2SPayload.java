package eu.pb4.polymer.core.impl.networking.payloads.c2s;

import eu.pb4.polymer.core.impl.networking.C2SPackets;
import eu.pb4.polymer.networking.api.ContextByteBuf;
import eu.pb4.polymer.networking.impl.packets.DisableS2CPayload;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import xyz.nucleoid.packettweaker.PacketContext;

public record PolymerPickBlockC2SPayload(BlockPos pos, boolean control) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<DisableS2CPayload> ID = new CustomPacketPayload.Type<>(C2SPackets.WORLD_PICK_BLOCK);
    public static final StreamCodec<ContextByteBuf, PolymerPickBlockC2SPayload> CODEC = StreamCodec.ofMember(PolymerPickBlockC2SPayload::write, PolymerPickBlockC2SPayload::read);

    public void write(FriendlyByteBuf buf) {
        buf.writeBlockPos(this.pos);
        buf.writeBoolean(control);
    }


    public static PolymerPickBlockC2SPayload read(FriendlyByteBuf buf) {
        return new PolymerPickBlockC2SPayload(buf.readBlockPos(), buf.readBoolean());
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return ID;
    }
}
