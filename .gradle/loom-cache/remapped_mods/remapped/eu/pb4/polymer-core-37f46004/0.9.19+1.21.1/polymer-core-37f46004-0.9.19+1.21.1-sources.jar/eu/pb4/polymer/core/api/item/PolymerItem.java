package eu.pb4.polymer.core.api.item;

import eu.pb4.polymer.core.api.utils.PolymerSyncedObject;
import eu.pb4.polymer.core.impl.PolymerImplUtils;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Interface used for creation of server-side items
 */
public interface PolymerItem extends PolymerSyncedObject<Item> {
    /**
     * Returns main/default item used on client for specific player
     *
     * @param itemStack ItemStack of virtual item
     * @param player    Player for which it's send
     * @return Vanilla (or other) Item instance
     */
    Item getPolymerItem(ItemStack itemStack, @Nullable ServerPlayer player);

    /**
     * Method used for creation of client-side ItemStack
     *
     * @param itemStack Server-side ItemStack
     * @param player    Player for which it's send
     * @return Client-side ItemStack
     */
    default ItemStack getPolymerItemStack(ItemStack itemStack, TooltipFlag tooltipType, HolderLookup.Provider lookup, @Nullable ServerPlayer player) {
        return PolymerItemUtils.createItemStack(itemStack, tooltipType, lookup, player);
    }


    /**
     * Method used for getting custom model data of items
     *
     * @param itemStack Server-side ItemStack
     * @param player    Player for which it's send
     * @return Custom model data or -1 if not present
     */
    default int getPolymerCustomModelData(ItemStack itemStack, @Nullable ServerPlayer player) {
        return -1;
    }

    /**
     * Method used for getting custom armor color of items
     * It's designed to be used alongside {@link eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils#requestArmor(ResourceLocation)}
     * Make sure colors isn't even so it won't get wrong texture
     *
     * @param itemStack Server-side ItemStack
     * @param player    Player for which it's send
     * @return Custom color or -1 if not present
     */
    default int getPolymerArmorColor(ItemStack itemStack, @Nullable ServerPlayer player) {
        return -1;
    }

    /**
     * This method allows to modify tooltip text
     * If you just want to add your own one, use {@link Item#appendHoverText(ItemStack, Item.TooltipContext, List, TooltipFlag)}
     *
     * @param tooltip Current tooltip text
     * @param stack   Server-side ItemStack
     * @param player  Target player
     */
    default void modifyClientTooltip(List<Component> tooltip, ItemStack stack, @Nullable ServerPlayer player) {
    }
    @Override
    default Item getPolymerReplacement(ServerPlayer player) {
        return this.getPolymerItem(((Item) this).getDefaultInstance(), player);
    }

    default boolean handleMiningOnServer(ItemStack tool, BlockState targetBlock, BlockPos pos, ServerPlayer player) {
        return false;
    }

    default boolean shouldStorePolymerItemStackCount() {
        return false;
    }
}