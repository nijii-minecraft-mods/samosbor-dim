package eu.pb4.polymer.core.mixin;

import it.unimi.dsi.fastutil.ints.IntList;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.Map;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagNetworkSerialization;

@Mixin(TagNetworkSerialization.NetworkPayload.class)
public interface SerializedAccessor {
    @Accessor
    Map<ResourceLocation, IntList> getContents();

    @Invoker("<init>")
    static TagNetworkSerialization.NetworkPayload createSerialized(Map<ResourceLocation, IntList> contents) {
        throw new UnsupportedOperationException();
    }
}
