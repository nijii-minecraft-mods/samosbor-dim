package eu.pb4.polymer.core.api.client;

import eu.pb4.polymer.core.impl.client.ClientPolymerEntryImpl;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;

@Environment(EnvType.CLIENT)
public interface ClientPolymerEntry<T> {
    ResourceLocation identifier();
    @Nullable T registryEntry();

    static <T> ClientPolymerEntry<T> of(ResourceLocation identifier, @Nullable T registryEntry) {
        return new ClientPolymerEntryImpl<>(identifier, registryEntry);
    }

    static <T> ClientPolymerEntry<T> of(ResourceLocation identifier, Registry<T> registry) {
        return new ClientPolymerEntryImpl<>(identifier, registry.containsKey(identifier) ? registry.get(identifier) : null);
    }

    static <T> ClientPolymerEntry<T> of(ResourceLocation identifier) {
        return new ClientPolymerEntryImpl<>(identifier, null);
    }
}
