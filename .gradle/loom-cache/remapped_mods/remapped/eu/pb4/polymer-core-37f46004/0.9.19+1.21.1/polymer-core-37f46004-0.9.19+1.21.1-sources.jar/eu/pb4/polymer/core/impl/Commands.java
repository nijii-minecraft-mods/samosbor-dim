package eu.pb4.polymer.core.impl;

import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import eu.pb4.polymer.common.api.PolymerCommonUtils;
import eu.pb4.polymer.common.impl.CommonImplUtils;
import eu.pb4.polymer.core.api.block.BlockMapper;
import eu.pb4.polymer.core.api.item.PolymerItemGroupUtils;
import eu.pb4.polymer.core.api.item.PolymerItemUtils;
import eu.pb4.polymer.core.api.other.PolymerStat;
import eu.pb4.polymer.core.api.utils.PolymerSyncUtils;
import eu.pb4.polymer.core.api.utils.PolymerUtils;
import eu.pb4.polymer.core.impl.compat.ServerTranslationUtils;
import eu.pb4.polymer.core.impl.networking.PolymerServerProtocol;
import eu.pb4.polymer.core.impl.ui.CreativeTabListUi;
import eu.pb4.polymer.core.impl.ui.CreativeTabUi;
import eu.pb4.polymer.core.impl.ui.PotionUi;
import eu.pb4.polymer.core.mixin.block.PalettedContainerAccessor;
import eu.pb4.polymer.networking.impl.ExtClientConnection;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import it.unimi.dsi.fastutil.objects.Object2IntMap.Entry;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import javax.naming.spi.StateFactory;
import net.minecraft.ChatFormatting;
import net.minecraft.Util;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.ResourceArgument;
import net.minecraft.commands.arguments.ResourceLocationArgument;
import net.minecraft.commands.arguments.UuidArgument;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.TextComponentTagVisitor;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.network.Filterable;
import net.minecraft.stats.StatType;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.LecternMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.WrittenBookContent;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import static net.minecraft.commands.Commands.argument;
import static net.minecraft.commands.Commands.literal;

import D;
import I;
import Z;

@SuppressWarnings("ResultOfMethodCallIgnored")
@ApiStatus.Internal
public class Commands {
    public static void register(LiteralArgumentBuilder<CommandSourceStack> command, CommandBuildContext access) {
        command.then(literal("stats")
                        .requires(CommonImplUtils.permission("command.stats", 0))
                        .executes(Commands::statsGeneral)
                        .then(argument("type", ResourceArgument.resource(access, Registries.STAT_TYPE)).executes(Commands::stats))
                )
                .then(literal("effects")
                        .requires(CommonImplUtils.permission("command.effects", 0))
                        .executes(Commands::effects)
                )
                .then(literal("client-item")
                        .requires(CommonImplUtils.permission("command.client-item", 3))
                        .executes(Commands::displayClientItem)
                        .then(literal("get").executes(Commands::getClientItem))
                )
                .then(literal("export-registry")
                        .requires(CommonImplUtils.permission("command.export-registry", 3))
                        .executes(Commands::dumpRegistries)
                )
                .then(literal("target-block")
                        .requires(CommonImplUtils.permission("command.target-block", 3))
                        .executes(Commands::targetBlock)
                )
                .then(literal("target-item")
                        .requires(CommonImplUtils.permission("command.target-item", 3))
                        .executes(Commands::targetItem)
                )
                .then(literal("pick")
                        .requires(CommonImplUtils.permission("command.pick", 0))
                        .executes((ctx) -> Commands.pickTarget(ctx, false))
                        .then(
                                literal("withnbt").executes((ctx) -> Commands.pickTarget(ctx, true))
                        )

                )
                .then(literal("creative")
                        .requires(CommonImplUtils.permission("command.creative", 0))
                        .then(argument("itemGroup", ResourceLocationArgument.id())
                                .suggests((context, builder) -> {
                                    var remaining = builder.getRemaining().toLowerCase(Locale.ROOT);

                                    var groups = PolymerItemGroupUtils.getItemGroups(context.getSource().getPlayerOrException());

                                    SharedSuggestionProvider.filterResources(groups, remaining, BuiltInRegistries.CREATIVE_MODE_TAB::getKey, group -> builder.suggest(BuiltInRegistries.CREATIVE_MODE_TAB.getKey(group).toString(), group.getDisplayName()));
                                    return builder.buildFuture();
                                })
                                .executes(Commands::creativeTab)
                        )
                        .executes(Commands::creativeTab));
    }

    private static int pickTarget(CommandContext<CommandSourceStack> serverCommandSourceCommandContext, boolean withNbt) throws CommandSyntaxException {
        var player = serverCommandSourceCommandContext.getSource().getPlayerOrException();
        var range = player.entityInteractionRange();

        var min = player.getEyePosition(0);
        var rot = player.getViewVector(0);
        var max = min.add(rot.x * range, rot.y * range, rot.z * range);

        var box = player.getBoundingBox().expandTowards(rot.scale(range)).inflate(1.0, 1.0, 1.0);
        var entityHit = ProjectileUtil.getEntityHitResult(player, min, max, box, entity -> !player.isSpectator() && entity.isPickable(), range);

        if (entityHit != null) {
            PolymerImplUtils.pickEntity(player, entityHit.getEntity());
            return 1;
        }

        var hit = player.pick(player.blockInteractionRange(), 0, false);
        if (hit instanceof BlockHitResult result && hit.getType() != HitResult.Type.MISS) {
            PolymerImplUtils.pickBlock(player, result.getBlockPos(), withNbt);
            return 2;
        }

        return 0;
    }

    public static void registerDev(LiteralArgumentBuilder<CommandSourceStack> dev) {
        dev
                .then(literal("reload-world")
                        .executes((ctx) -> {
                            PolymerUtils.reloadWorld(ctx.getSource().getPlayer());
                            return 0;
                        })
                )
                .then(literal("get-mapper")
                        .executes((ctx) -> {
                            ctx.getSource().sendSuccess(() -> Component.literal(BlockMapper.getFrom(ctx.getSource().getPlayer()).getMapperName()), false);
                            return 0;
                        })
                )
                .then(literal("reset-mapper")
                        .executes((ctx) -> {
                            BlockMapper.resetMapper(ctx.getSource().getPlayer());
                            return 0;
                        })
                )
                .then(literal("run-sync")
                        .executes((ctx) -> {
                            PolymerSyncUtils.synchronizePolymerRegistries(ctx.getSource().getPlayer().connection);
                            return 0;
                        }))
                .then(literal("protocol-info")
                        .executes((ctx) -> {
                            ctx.getSource().sendSuccess(() -> Component.literal("Protocol supported by your client:"), false);
                            for (var entry : ExtClientConnection.of(ctx.getSource().getPlayer().connection).polymerNet$getSupportMap().object2IntEntrySet()) {
                                ctx.getSource().sendSuccess(() -> Component.literal("- " + entry.getKey() + " = " + entry.getIntValue()), false);
                            }
                            return 0;
                        })
                )
                .then(literal("validate_states")
                        .executes((ctx) -> {
                            PolymerServerProtocol.sendDebugValidateStatesPackets(ctx.getSource().getPlayer().connection);
                            return 0;
                        })
                )
                .then(literal("set-pack-status")
                        .then(argument("status", BoolArgumentType.bool())
                                .then(argument("uuid", UuidArgument.uuid())
                                        .executes((ctx) -> {
                                            var status = ctx.getArgument("status", Boolean.class);
                                            PolymerCommonUtils.setHasResourcePack(ctx.getSource().getPlayerOrException(), UuidArgument.getUuid(ctx, "uuid"), status);
                                            ctx.getSource().sendSuccess(() -> Component.literal("New resource pack status: " + status), false);
                                            return 0;
                                        }))
                        )
                )
                .then(literal("get-pack-status")
                        .executes((ctx) -> {
                            var status = PolymerUtils.hasResourcePack(ctx.getSource().getPlayer(), PolymerResourcePackUtils.getMainUuid());
                            ctx.getSource().sendSuccess(() -> Component.literal("Resource pack status: " + status), false);
                            return 0;
                        })
                )
                .then(literal("chunk_section_info")
                        .executes((ctx) -> {
                            var chunk = ctx.getSource().getLevel().getChunk(ctx.getSource().getPlayer().blockPosition());
                            var s = chunk.getSection(ctx.getSource().getLevel().getSectionIndex(ctx.getSource().getPlayer().getBlockY()));

                            var a = ((PalettedContainerAccessor<BlockState>) s.getStates()).getData();

                            ctx.getSource().sendSuccess(() -> Component.literal("Chunk: " + chunk.getPos() + " Palette: " + a.palette() + " | " + " Storage: " + a.storage() + " | Bits: " + a.storage().getElementBits()), false);
                            return 0;
                        })
                );
    }

    private static int targetBlock(CommandContext<CommandSourceStack> context) {
        var raycast = (BlockHitResult) context.getSource().getPlayer().pick(10, 0, true);

        var builder = new StringBuilder();
        var state = context.getSource().getLevel().getBlockState(raycast.getBlockPos());

        builder.append(BuiltInRegistries.BLOCK.getKey(state.getBlock()));

        if (!state.getBlock().getStateDefinition().getProperties().isEmpty()) {
            builder.append("[");
            var iterator = state.getBlock().getStateDefinition().getProperties().iterator();

            while (iterator.hasNext()) {
                var property = iterator.next();
                builder.append(property.getName());
                builder.append("=");
                builder.append(((Property) property).getName(state.getValue(property)));

                if (iterator.hasNext()) {
                    builder.append(",");
                }
            }
            builder.append("]");
        }

        context.getSource().sendSuccess(() -> Component.literal(builder.toString()), false);

        return 0;
    }

    private static int targetItem(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        var itemStack = context.getSource().getPlayerOrException().getMainHandItem();
        context.getSource().sendSuccess(() -> Component.translationArg(BuiltInRegistries.ITEM.getKey(itemStack.getItem())), false);
        return 0;
    }

    private static int dumpRegistries(CommandContext<CommandSourceStack> context) {
        var path = PolymerImplUtils.dumpRegistry();
        if (path != null) {
            context.getSource().sendSuccess(() -> Component.literal("Exported registry state as " + path), false);
        } else {
            context.getSource().sendFailure(Component.literal("Couldn't export registry!"));
        }
        return 0;
    }

    private static int effects(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        new PotionUi(context.getSource().getPlayer());
        return 1;
    }

    private static int statsGeneral(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        var player = context.getSource().getPlayer();

        var list = new ArrayList<Filterable<Component>>();

        int line = 0;
        MutableComponent text = null;

        for (var statType : BuiltInRegistries.STAT_TYPE) {
            if (text == null) {
                text = Component.literal("");
            }
            text.append(Component.empty().append(BuiltInRegistries.STAT_TYPE.getKey(statType).toString()).append("\n").withStyle(x -> x.withUnderlined(true).withColor(ChatFormatting.BLUE).withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/polymer stats " + BuiltInRegistries.STAT_TYPE.getKey(statType)))));
            line++;

            if (line == 13) {
                list.add(Filterable.passThrough(text));
                text = null;
                line = 0;
            }
        }

        if (text != null) {
            list.add(Filterable.passThrough(text));
        }

        var stack = new ItemStack(Items.WRITTEN_BOOK);
        stack.set(DataComponents.WRITTEN_BOOK_CONTENT, new WrittenBookContent(
                Filterable.passThrough("/polymer start"),
                player.getGameProfile().getName(),
                0,
                list,
                false
        ));


        player.openMenu(new MenuProvider() {
            @Override
            public Component getDisplayName() {
                return Component.empty();
            }

            @Nullable
            @Override
            public AbstractContainerMenu createMenu(int syncId, Inventory inv, Player player) {
                var lectern = new LecternMenu(syncId) {
                    @Override
                    public boolean canTakeItemForPickAll(ItemStack stack, Slot slot) {
                        return false;
                    }

                    @Override
                    public boolean canDragTo(Slot slot) {
                        return false;
                    }

                    @Override
                    public boolean clickMenuButton(Player player, int id) {
                        if (id == 3) {
                            return false;
                        } else {
                            return super.clickMenuButton(player, id);
                        }
                    }

                    @Override
                    public void clicked(int slotIndex, int button, ClickType actionType, Player player) {
                        // noop
                    }
                };
                lectern.getSlot(0).setByPlayer(stack);
                return lectern;
            }
        });

        return 1;
    }

    private static int stats(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        var player = context.getSource().getPlayer();

        var list = new ArrayList<Filterable<Component>>();

        int line = 0;
        MutableComponent text = null;

        var type = (StatType<Object>) ResourceArgument.getResource(context, "type", Registries.STAT_TYPE).value();

        for (var statObj : type.getRegistry()) {
            if (PolymerUtils.isServerOnly(statObj) && type.contains(statObj)) {


                var stat = type.get(statObj);

                if (text == null) {
                    text = Component.literal("");
                }

                var statVal = player.getStats().getValue(stat);

                Component title;

                if (statObj instanceof ResourceLocation stat1) {
                    title = PolymerStat.getName(stat1);
                } else if (statObj instanceof Item item) {
                    title = item.getDescription();
                } else if (statObj instanceof Block item) {
                    title = item.getName();
                } else if (statObj instanceof EntityType item) {
                    title = item.getDescription();
                } else {
                    title = Component.translatable(Util.makeDescriptionId(type.getRegistry().key().location().getPath(), type.getRegistry().getKey(statObj)));
                }

                text.append(title).append(Component.literal(": ").withStyle(ChatFormatting.GRAY)).append(Component.literal(stat.format(statVal) + "\n").withStyle(ChatFormatting.DARK_GRAY));
                line++;

                if (line == 13) {
                    list.add(Filterable.passThrough(text));
                    text = null;
                    line = 0;
                }
            }
        }

        if (text != null) {
            list.add(Filterable.passThrough(text));
        }

        var stack = new ItemStack(Items.WRITTEN_BOOK);
        stack.set(DataComponents.WRITTEN_BOOK_CONTENT, new WrittenBookContent(
                Filterable.passThrough("/polymer start"),
                player.getGameProfile().getName(),
                0,
                list,
                false
        ));


        player.openMenu(new MenuProvider() {
            @Override
            public Component getDisplayName() {
                return Component.empty();
            }

            @Nullable
            @Override
            public AbstractContainerMenu createMenu(int syncId, Inventory inv, Player player) {
                var lectern = new LecternMenu(syncId) {
                    @Override
                    public boolean canTakeItemForPickAll(ItemStack stack, Slot slot) {
                        return false;
                    }

                    @Override
                    public boolean canDragTo(Slot slot) {
                        return false;
                    }

                    @Override
                    public boolean clickMenuButton(Player player, int id) {
                        if (id == 3) {
                            return false;
                        } else {
                            return super.clickMenuButton(player, id);
                        }
                    }

                    @Override
                    public void clicked(int slotIndex, int button, ClickType actionType, Player player) {
                        // noop
                    }
                };
                lectern.getSlot(0).setByPlayer(stack);
                return lectern;
            }
        });

        return 1;
    }

    private static int creativeTab(CommandContext<CommandSourceStack> context) {
        if (context.getSource().getPlayer().isCreative()) {
            try {
                var id = context.getArgument("itemGroup", ResourceLocation.class);

                var itemGroup = BuiltInRegistries.CREATIVE_MODE_TAB.get(id);
                if (itemGroup != null) {
                    new CreativeTabUi(context.getSource().getPlayer(), itemGroup);
                    return 2;
                }
            } catch (Exception e) {
                //
            }

            new CreativeTabListUi(context.getSource().getPlayer());
            return 1;
        } else {
            return 0;
        }
    }

    private static int displayClientItem(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        var player = context.getSource().getPlayer();
        var stack = PolymerItemUtils.getPolymerItemStack(player.getMainHandItem(), context.getSource().registryAccess(), player).copy();
        stack.remove(DataComponents.CUSTOM_DATA);

        context.getSource().sendSuccess(() -> (new TextComponentTagVisitor("")).visit(stack.save(context.getSource().registryAccess())), false);

        return 1;
    }

    private static int getClientItem(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        var player = context.getSource().getPlayer();

        var stack = PolymerItemUtils.getPolymerItemStack(player.getMainHandItem(), context.getSource().registryAccess(), player);
        stack.remove(DataComponents.CUSTOM_DATA);
        player.addItem(stack);
        context.getSource().sendSuccess(() -> Component.literal("Given client representation to player"), true);

        return 1;
    }
}
