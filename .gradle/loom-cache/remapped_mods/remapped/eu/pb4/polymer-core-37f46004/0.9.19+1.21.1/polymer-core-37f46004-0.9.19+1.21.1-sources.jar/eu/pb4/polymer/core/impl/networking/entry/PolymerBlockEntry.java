package eu.pb4.polymer.core.impl.networking.entry;

import I;
import eu.pb4.polymer.networking.api.ContextByteBuf;
import io.netty.buffer.ByteBuf;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentSerialization;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.ApiStatus;


@ApiStatus.Internal
public record PolymerBlockEntry(ResourceLocation identifier, int numId, Component text, BlockState visual, ItemStack visualStack) {
    private static final StreamCodec<ByteBuf, BlockState> STATE = ByteBufCodecs.idMapper(Block.BLOCK_STATE_REGISTRY);
    public static final StreamCodec<ContextByteBuf, PolymerBlockEntry> CODEC = StreamCodec.ofMember(PolymerBlockEntry::write, PolymerBlockEntry::read);
    public void write(ContextByteBuf buf) {
        buf.writeResourceLocation(identifier);
        buf.writeVarInt(numId);
        ComponentSerialization.TRUSTED_CONTEXT_FREE_STREAM_CODEC.encode(buf, text);
        STATE.encode(buf, visual);
        if (buf.version() >= 7) {
            ItemStack.OPTIONAL_STREAM_CODEC.encode(buf, this.visualStack);
        }
    }

    public static PolymerBlockEntry of(Block block) {
        return new PolymerBlockEntry(BuiltInRegistries.BLOCK.getKey(block), BuiltInRegistries.BLOCK.getId(block),
                block.getName(), block.defaultBlockState(), block.asItem() != null ? block.asItem().getDefaultInstance() : ItemStack.EMPTY);
    }

    public static PolymerBlockEntry read(ContextByteBuf buf) {
        var id = buf.readResourceLocation();
        var numId = buf.readVarInt();
        var name = ComponentSerialization.TRUSTED_CONTEXT_FREE_STREAM_CODEC.decode(buf);
        var visual = STATE.decode(buf);
        var visualStack = buf.version() >= 7 ? ItemStack.OPTIONAL_STREAM_CODEC.decode(buf)
                : (visual.getBlock().asItem() != null ? visual.getBlock().asItem().getDefaultInstance() : ItemStack.EMPTY);
        return new PolymerBlockEntry(id, numId, name, visual, visualStack);
    }
}
