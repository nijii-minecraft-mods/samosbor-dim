package eu.pb4.polymer.core.mixin.block;

import ;
import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import eu.pb4.polymer.common.api.PolymerCommonUtils;
import eu.pb4.polymer.core.impl.PolymerImplUtils;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.BitSet;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundLevelChunkWithLightPacket;
import net.minecraft.server.network.PlayerChunkSender;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.lighting.LevelLightEngine;

@Mixin(value = PlayerChunkSender.class, priority = 1001)
public class ChunkDataSenderMixin {
    @WrapOperation(method = "sendChunkData", at = @At(value = "NEW", target = "(Lnet/minecraft/world/chunk/WorldChunk;Lnet/minecraft/world/chunk/light/LightingProvider;Ljava/util/BitSet;Ljava/util/BitSet;)Lnet/minecraft/network/packet/s2c/play/ChunkDataS2CPacket;"), require = 0)
    private static ClientboundLevelChunkWithLightPacket addContext(LevelChunk chunk, LevelLightEngine lightProvider, @Nullable BitSet skyBits, @Nullable BitSet blockBits, Operation<ClientboundLevelChunkWithLightPacket> call,
                                                 @Local(argsOnly = true) ServerGamePacketListenerImpl handler) {
        var storage = new ClientboundLevelChunkWithLightPacket[1];
        PolymerCommonUtils.executeWithNetworkingLogic(handler, () -> storage[0] = call.call(chunk, lightProvider, skyBits, blockBits));
        return storage[0];
    }

    @WrapWithCondition(method = "unload", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerPlayNetworkHandler;sendPacket(Lnet/minecraft/network/packet/Packet;)V"), require = 0)
    private boolean skipChunkClearing(ServerGamePacketListenerImpl instance, Packet packet) {
        return PolymerImplUtils.IS_RELOADING_WORLD.get() == null;
    }
}
