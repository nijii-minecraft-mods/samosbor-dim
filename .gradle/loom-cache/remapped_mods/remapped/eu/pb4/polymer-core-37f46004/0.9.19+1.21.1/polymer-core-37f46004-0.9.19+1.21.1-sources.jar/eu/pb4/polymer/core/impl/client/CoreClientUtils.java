package eu.pb4.polymer.core.impl.client;

import eu.pb4.polymer.common.impl.client.ClientUtils;
import eu.pb4.polymer.core.api.item.PolymerItem;
import eu.pb4.polymer.core.api.utils.PolymerKeepModel;
import eu.pb4.polymer.core.api.utils.PolymerUtils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.core.HolderLookup;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
@Environment(EnvType.CLIENT)
public class CoreClientUtils {
    public static ItemStack getRenderingStack(ItemStack stack, HolderLookup.Provider lookup) {
        if (stack.getItem() instanceof VirtualClientItem virtualItem) {
            var og = stack;

            stack = virtualItem.getPolymerEntry().visualStack().copy();
            stack.setCount(og.getCount());
        }

        return stack.getItem() instanceof PolymerItem item && !PolymerKeepModel.is(item) ? item.getPolymerItemStack(stack, PolymerUtils.getTooltipType(ClientUtils.getPlayer()), lookup, ClientUtils.getPlayer()) : stack;
    }
}
