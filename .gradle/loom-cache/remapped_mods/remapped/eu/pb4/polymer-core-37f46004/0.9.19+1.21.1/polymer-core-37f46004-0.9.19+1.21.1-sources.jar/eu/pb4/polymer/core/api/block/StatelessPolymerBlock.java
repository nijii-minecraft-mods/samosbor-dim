package eu.pb4.polymer.core.api.block;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

public interface StatelessPolymerBlock extends PolymerBlock {
    /**
     * Returns main/default block used on client
     *
     * @return Vanilla (or other) Block instance
     */
    Block getPolymerBlock(BlockState state);

    /**
     * Returns block used on client for player
     *
     * @return Vanilla (or other) Block instance
     */
    default Block getPolymerBlock(BlockState state, ServerPlayer player) {
        return this.getPolymerBlock(state, player);
    }

    @Override
    default BlockState getPolymerBlockState(BlockState state) {
        return this.getPolymerBlock(state).defaultBlockState();
    }

    @Override
    default BlockState getPolymerBlockState(BlockState state, ServerPlayer player) {
        return this.getPolymerBlock(state, player).defaultBlockState();
    }
}
