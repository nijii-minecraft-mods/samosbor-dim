package eu.pb4.polymer.core.mixin.other;


import eu.pb4.polymer.core.api.utils.PolymerSyncedObject;
import eu.pb4.polymer.core.api.utils.PolymerUtils;
import net.minecraft.core.Holder;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.resources.ResourceKey;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(targets = "net/minecraft/network/codec/PacketCodecs$16", priority = 500)
public abstract class PacketCodecsRegistryMixin {

    @Shadow @Final private ResourceKey field_48575;

    @ModifyVariable(method = "encode(Lnet/minecraft/network/RegistryByteBuf;Ljava/lang/Object;)V", at = @At("HEAD"), argsOnly = true)
    private Object polymer$changeData(Object val, RegistryFriendlyByteBuf buf) {
        var player = PolymerUtils.getPlayerContext();
        
        if (player != null) {
            if (val instanceof PolymerSyncedObject<?> polymerSyncedObject) {
                var obj = polymerSyncedObject.getPolymerReplacement(player);

                if (obj != null) {
                    return obj;
                }
            } else if (val instanceof Holder<?> registryEntry) {
                var value = registryEntry.value();
                if (value instanceof PolymerSyncedObject<?> polymerSyncedObject) {
                    var obj = polymerSyncedObject.getPolymerReplacement(player);

                    if (obj != null) {
                        //noinspection unchecked
                        return buf.registryAccess().registryOrThrow(this.field_48575).wrapAsHolder(obj);
                    }
                }
            }
        }

        return val;
    }
}