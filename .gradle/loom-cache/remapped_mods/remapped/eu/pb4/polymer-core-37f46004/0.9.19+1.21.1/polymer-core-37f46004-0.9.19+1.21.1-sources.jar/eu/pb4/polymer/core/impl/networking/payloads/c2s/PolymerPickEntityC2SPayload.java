package eu.pb4.polymer.core.impl.networking.payloads.c2s;

import eu.pb4.polymer.core.impl.networking.C2SPackets;
import eu.pb4.polymer.networking.api.ContextByteBuf;
import eu.pb4.polymer.networking.impl.packets.DisableS2CPayload;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import xyz.nucleoid.packettweaker.PacketContext;

public record PolymerPickEntityC2SPayload(int entityId, boolean control) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<DisableS2CPayload> ID = new CustomPacketPayload.Type<>(C2SPackets.WORLD_PICK_ENTITY);
    public static final StreamCodec<ContextByteBuf, PolymerPickEntityC2SPayload> CODEC = StreamCodec.ofMember(PolymerPickEntityC2SPayload::write, PolymerPickEntityC2SPayload::read);

    public void write(FriendlyByteBuf buf) {
        buf.writeVarInt(this.entityId);
        buf.writeBoolean(control);
    }

    public static PolymerPickEntityC2SPayload read(FriendlyByteBuf buf) {
        return new PolymerPickEntityC2SPayload(buf.readVarInt(), buf.readBoolean());
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return ID;
    }
}
