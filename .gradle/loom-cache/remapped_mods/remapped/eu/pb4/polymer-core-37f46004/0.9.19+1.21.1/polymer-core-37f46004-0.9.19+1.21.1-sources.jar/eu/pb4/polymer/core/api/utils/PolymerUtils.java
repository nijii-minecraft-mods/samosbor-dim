package eu.pb4.polymer.core.api.utils;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import eu.pb4.polymer.common.api.PolymerCommonUtils;
import eu.pb4.polymer.common.impl.CommonImpl;
import eu.pb4.polymer.common.impl.client.ClientUtils;
import eu.pb4.polymer.core.api.block.PolymerBlockUtils;
import eu.pb4.polymer.core.api.entity.PolymerEntityUtils;
import eu.pb4.polymer.core.api.item.PolymerItemUtils;
import eu.pb4.polymer.core.api.other.PolymerComponent;
import eu.pb4.polymer.core.impl.PolymerImpl;
import eu.pb4.polymer.core.impl.PolymerImplUtils;
import eu.pb4.polymer.core.impl.interfaces.PolymerPlayNetworkHandlerExtension;
import eu.pb4.polymer.core.impl.networking.PacketPatcher;
import eu.pb4.polymer.core.mixin.block.packet.ServerChunkLoadingManagerAccessor;
import eu.pb4.polymer.core.mixin.entity.ServerWorldAccessor;
import eu.pb4.polymer.rsm.api.RegistrySyncUtils;
import org.jetbrains.annotations.Nullable;

import java.nio.file.Path;
import java.util.*;
import net.minecraft.Util;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.protocol.Packet;
import net.minecraft.server.level.ServerChunkCache;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerCommonPacketListenerImpl;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.util.Unit;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.npc.VillagerProfession;
import net.minecraft.world.flag.FeatureFlag;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.ResolvableProfile;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * General use case utils that can be useful in multiple situations
 */
public final class PolymerUtils {
    public static final String ID = "polymer";
    public static final String NO_TEXTURE_HEAD_VALUE = "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNGUyY2UzMzcyYTNhYzk3ZmRkYTU2MzhiZWYyNGIzYmM0OWY0ZmFjZjc1MWZlOWNhZDY0NWYxNWE3ZmI4Mzk3YyJ9fX0=";
    private static final Set<FeatureFlag> ENABLED_FEATURE_FLAGS = new HashSet<>();

    private PolymerUtils() {
    }

    public static String getVersion() {
        return CommonImpl.VERSION;
    }

    /**
     * Returns player if it's known to polymer (otherwise null!)
     */
    @Nullable
    public static ServerPlayer getPlayerContext() {
        return PolymerCommonUtils.getPlayerContext();
    }

    /**
     * Returns true, if server is running in singleplayer
     */
    public static boolean isSingleplayer() {
        if (!PolymerImpl.IS_CLIENT) {
            return false;
        } else {
            return ClientUtils.isSingleplayer();
        }
    }

    /**
     * Returns true, if code is running on logical client side (not server/singleplayer server)
     */
    public static boolean isOnClientThread() {
        if (!PolymerImpl.IS_CLIENT) {
            return false;
        } else {
            return ClientUtils.isClientThread();
        }
    }

    public static boolean isOnPlayerNetworking() {
        if (!PolymerImpl.IS_CLIENT) {
            return getPlayerContext() != null;
        } else {
            return getPlayerContext() != null || ClientUtils.isSingleplayer();
        }
    }

    public static void addClientEnabledFeatureFlags(FeatureFlag... flags) {
        ENABLED_FEATURE_FLAGS.addAll(List.of(flags));
    }

    public static Collection<FeatureFlag> getClientEnabledFeatureFlags() {
        return ENABLED_FEATURE_FLAGS;
    }

    /**
     * Schedules a packet sending
     *
     * @param handler  used for packet sending
     * @param packet   sent packet
     * @param duration time (in ticks) waited before packet is send
     */
    public static void schedulePacket(ServerGamePacketListenerImpl handler, Packet<?> packet, int duration) {
        ((PolymerPlayNetworkHandlerExtension) handler).polymer$schedulePacket(packet, duration);
    }

    /**
     * Resends world to player. It's useful to run this after player changes resource packs
     */
    public static void reloadWorld(ServerPlayer player) {
        player.server.execute(() -> {
            PolymerImplUtils.IS_RELOADING_WORLD.set(Unit.INSTANCE);
            try {
                player.containerMenu.sendAllDataToRemote();

                var world = player.level();
                var tacsAccess = ((ServerChunkLoadingManagerAccessor) ((ServerChunkCache) player.level().getChunkSource()).chunkMap);

                for (var e : ((ServerWorldAccessor) player.level()).polymer_getEntityManager().getEntityGetter().getAll()) {
                    var tracker = tacsAccess.polymer$getEntityTrackers().get(e.getId());
                    if (tracker != null) {
                        tracker.stopTracking(player);
                    }
                }


                player.getChunkTrackingView().forEach((chunkPos) -> {
                    var chunk = world.getChunk(chunkPos.x, chunkPos.z);
                    player.connection.chunkSender.dropChunk(player, chunk.getPos());
                    player.connection.chunkSender.markChunkPendingToSend(chunk);
                });
            } catch (Throwable e) {
                PolymerImpl.LOGGER.warn("Failed to reload player's world view!", e);
            }

            PolymerImplUtils.IS_RELOADING_WORLD.remove();
        });
    }
    /**
     * @deprecated Use {@link PolymerComponent#registerDataComponent(DataComponentType[])} instead
     */
    @Deprecated
    public static void markAsPolymer(DataComponentType<?>... types) {
        PolymerItemUtils.markAsPolymer(types);
    }

    /**
     * Resends inventory to player
     */
    public static void reloadInventory(ServerPlayer player) {
        player.containerMenu.sendAllDataToRemote();
    }

    /**
     * Returns current TooltipContext of player,
     */
    public static TooltipFlag getTooltipType(@Nullable ServerPlayer player) {
        return PolymerImplUtils.getTooltipContext(player);
    }

    /**
     * Returns current TooltipContext of player,
     */
    public static TooltipFlag getCreativeTooltipType(@Nullable ServerPlayer player) {
        return PolymerImplUtils.getTooltipContext(player).withCreative();
    }

    public static GameProfile createSkinGameProfile(String value, @Nullable String signature) {
        var profile = new GameProfile(Util.NIL_UUID, "");
        profile.getProperties().put("textures", new Property("textures", value, signature));
        return profile;
    }


    public static ItemStack createPlayerHead(String value) {
        return createPlayerHead(value, null);
    }

    public static ItemStack createPlayerHead(String value, String signature) {
        var stack = new ItemStack(Items.PLAYER_HEAD);
        stack.set(DataComponents.PROFILE, new ResolvableProfile(createSkinGameProfile(value, signature)));
        return stack;
    }

    public static Level getFakeWorld() {
        return PolymerCommonUtils.getFakeWorld();
    }

    @Nullable
    public static Path getClientJar() {
        return PolymerCommonUtils.getClientJar();
    }

    @SuppressWarnings("unchecked")
    public static boolean isServerOnly(Object obj) {
        return obj instanceof PolymerObject
                || (obj instanceof ItemStack stack && PolymerItemUtils.isPolymerServerItem(stack))
                || (obj instanceof EntityType<?> type && PolymerEntityUtils.isPolymerEntityType(type))
                || (obj instanceof BlockEntityType<?> typeBE && PolymerBlockUtils.isPolymerBlockEntityType(typeBE))
                || (obj instanceof Holder<?> entry && (
                        (entry.value() instanceof ArmorMaterial && PolymerItemUtils.isPolymerArmorMaterial((Holder<ArmorMaterial>) entry))
                        || (entry.value() instanceof Attribute && PolymerEntityUtils.isPolymerEntityAttribute((Holder<Attribute>) entry))))
                || (obj instanceof DataComponentType<?> componentType && PolymerComponent.isPolymerComponent(componentType))
                || (obj instanceof VillagerProfession villagerProfession && PolymerEntityUtils.getPolymerProfession(villagerProfession) != null);
    }
    public static <T> boolean isServerOnly(Registry<T> registry, T obj) {
        return RegistrySyncUtils.isServerEntry(registry, obj) || isServerOnly(obj);
    }

    public static boolean hasResourcePack(@Nullable ServerPlayer player, UUID uuid) {
        return PolymerCommonUtils.hasResourcePack(player, uuid);
    }

    public static Packet<?> replacePacket(ServerCommonPacketListenerImpl handler, Packet<?> packet) {
        return PacketPatcher.replace(handler, packet);
    }

    public static boolean shouldPreventPacket(ServerCommonPacketListenerImpl handler, Packet<?> packet) {
        return PacketPatcher.prevent(handler, packet);
    }

    public static ResolvableProfile createProfileComponent(String value, @Nullable String signature) {
        return new ResolvableProfile(createSkinGameProfile(value, signature));
    }

    /**
     * Use PolymerCommonUtils.executeWithNetworkingLogic
     */
    @Deprecated
    public static void executeWithPlayerContext(ServerPlayer player, Runnable runnable) {
        PolymerCommonUtils.executeWithPlayerContext(player, runnable);
    }
}
