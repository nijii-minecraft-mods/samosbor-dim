package eu.pb4.polymer.core.mixin.item.packet;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import eu.pb4.polymer.common.impl.client.ClientUtils;
import eu.pb4.polymer.core.api.utils.PolymerObject;
import eu.pb4.polymer.core.api.utils.PolymerSyncedObject;
import eu.pb4.polymer.core.api.utils.PolymerUtils;
import eu.pb4.polymer.core.impl.PolymerImpl;
import io.netty.buffer.Unpooled;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundUpdateRecipesPacket;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeHolder;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

@Mixin(ClientboundUpdateRecipesPacket.class)
public abstract class SynchronizeRecipesS2CPacketMixin implements Packet {
    @ModifyReturnValue(method = "method_55955", at = @At("TAIL"))
    private static List<RecipeHolder<?>> polymer$remapRecipes(List<RecipeHolder<?>> recipes) {
        List<RecipeHolder<?>> list = new ArrayList<>();
        var player = PolymerUtils.getPlayerContext();
        for (var recipe : recipes) {
            if (recipe.value() instanceof PolymerSyncedObject<?> syncedRecipe) {
                Recipe<?> polymerRecipe = (Recipe<?>) syncedRecipe.getPolymerReplacement(player);
                if (polymerRecipe != null) {
                    list.add(new RecipeHolder<Recipe<?>>(recipe.id(), polymerRecipe));
                }
            } else if (!(PolymerObject.is(recipe.value().getSerializer()) || PolymerObject.is(recipe))) {
                list.add(recipe);
            }
        }
        return list;
    }
    @Override
    public boolean isSkippable() {
        return true;
    }
}
