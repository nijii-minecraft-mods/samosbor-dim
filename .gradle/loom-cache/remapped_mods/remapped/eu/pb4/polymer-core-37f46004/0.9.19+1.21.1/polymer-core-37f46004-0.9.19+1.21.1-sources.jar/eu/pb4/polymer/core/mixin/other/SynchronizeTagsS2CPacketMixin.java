package eu.pb4.polymer.core.mixin.other;

import eu.pb4.polymer.core.api.utils.PolymerSyncedObject;
import eu.pb4.polymer.core.api.utils.PolymerUtils;
import eu.pb4.polymer.core.mixin.SerializedAccessor;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntList;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.protocol.common.ClientboundUpdateTagsPacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagNetworkSerialization;

@Mixin(ClientboundUpdateTagsPacket.class)
public class SynchronizeTagsS2CPacketMixin {
    @ModifyArg(method = "write", at = @At(value = "INVOKE", target = "Lnet/minecraft/network/PacketByteBuf;writeMap(Ljava/util/Map;Lnet/minecraft/network/codec/PacketEncoder;Lnet/minecraft/network/codec/PacketEncoder;)V"))
    private Map<ResourceKey<? extends Registry<?>>, TagNetworkSerialization.NetworkPayload> polymer$skipEntries(Map<ResourceKey<? extends Registry<?>>, TagNetworkSerialization.NetworkPayload> groups) {
        var regMap = new HashMap<ResourceKey<? extends Registry<?>>, TagNetworkSerialization.NetworkPayload>();
        var player = PolymerUtils.getPlayerContext();
        for (var regEntry : groups.entrySet()) {
            //noinspection rawtypes,unchecked
            var reg = BuiltInRegistries.REGISTRY.get((ResourceKey) regEntry.getKey());

            if (reg != null) {
                var map = new HashMap<ResourceLocation, IntList>();

                for (var entry : ((SerializedAccessor) (Object) regEntry.getValue()).getContents().entrySet()) {
                    var list = new IntArrayList(entry.getValue().size());

                    for (int i : entry.getValue()) {
                        //noinspection unchecked
                        if (PolymerSyncedObject.canSyncRawToClient(reg, reg.byId(i), player)) {
                            list.add(i);
                        }
                    }
                    map.put(entry.getKey(), list);
                }

                regMap.put(regEntry.getKey(), SerializedAccessor.createSerialized(map));
            } else {
                // Dynamic registry, client should understand it
                regMap.put(regEntry.getKey(), regEntry.getValue());
            }
        }
        return regMap;
    }
}