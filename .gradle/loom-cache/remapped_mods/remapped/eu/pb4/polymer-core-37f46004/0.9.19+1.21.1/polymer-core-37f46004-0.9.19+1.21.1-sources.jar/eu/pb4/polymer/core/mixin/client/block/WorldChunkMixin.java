package eu.pb4.polymer.core.mixin.client.block;

import I;
import eu.pb4.polymer.core.api.client.ClientPolymerBlock;
import eu.pb4.polymer.core.impl.client.interfaces.ClientBlockStorageInterface;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.core.Registry;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.chunk.UpgradeData;
import net.minecraft.world.level.levelgen.blending.BlendingData;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;

@Environment(EnvType.CLIENT)
@Mixin(LevelChunk.class)
public abstract class WorldChunkMixin extends ChunkAccess implements ClientBlockStorageInterface {

    public WorldChunkMixin(ChunkPos pos, UpgradeData upgradeData, LevelHeightAccessor heightLimitView, Registry<Biome> biome, long inhabitedTime, @Nullable LevelChunkSection[] sectionArrayInitializer, @Nullable BlendingData blendingData) {
        super(pos, upgradeData, heightLimitView, biome, inhabitedTime, sectionArrayInitializer, blendingData);
    }

    @Override
    public void polymer$setClientBlock(int x, int y, int z, ClientPolymerBlock.State block) {
        var id = this.getSectionIndex(y);

        if (id >= 0 && id < this.sections.length) {
            var section = this.getSection(id);

            if (section != null && !section.hasOnlyAir()) {
                ((ClientBlockStorageInterface) section).polymer$setClientBlock(x, y, z, block);
            }
        }
    }

    @Override
    public ClientPolymerBlock.State polymer$getClientBlock(int x, int y, int z) {
        var id = this.getSectionIndex(y);
        if (id >= 0 && id < this.sections.length) {
            var section = this.getSection(id);

            if (section != null && !section.hasOnlyAir()) {
                return ((ClientBlockStorageInterface) section).polymer$getClientBlock(x, y, z);
            }
        }

        return ClientPolymerBlock.NONE_STATE;
    }
}
