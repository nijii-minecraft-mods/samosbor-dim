package eu.pb4.polymer.core.mixin.item;

import eu.pb4.polymer.core.api.item.PolymerItemUtils;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.StonecutterMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.StonecutterRecipe;
import net.minecraft.world.level.Level;

@Mixin(StonecutterMenu.class)
public class StonecutterScreenHandlerMixin {
    @Shadow
    @Final
    private Level world;
    @Shadow private List<RecipeHolder<StonecutterRecipe>> availableRecipes;
    @Unique
    private ServerPlayer polymerCore$player;

    @Inject(method = "<init>(ILnet/minecraft/entity/player/PlayerInventory;Lnet/minecraft/screen/ScreenHandlerContext;)V", at = @At("TAIL"))
    private void polymerCore$storePlayer(int syncId, Inventory playerInventory, ContainerLevelAccess context, CallbackInfo ci) {
        this.polymerCore$player = playerInventory.player instanceof ServerPlayer player ? player : null;
    }

    @Inject(method = "updateInput", at = @At("TAIL"))
    private void polymerCore$fixOrdering(Container input, ItemStack stack, CallbackInfo ci) {
        if (!stack.isEmpty() && this.polymerCore$player != null) {
            var list = new ArrayList<>(this.availableRecipes);

            list.sort(Comparator.comparing(
                    (recipe) -> PolymerItemUtils.getPolymerItemStack(recipe.value().getResultItem(this.world.registryAccess()), this.world.registryAccess(), this.polymerCore$player).getDescriptionId()
            ));
            this.availableRecipes = list;
        }
    }
}
