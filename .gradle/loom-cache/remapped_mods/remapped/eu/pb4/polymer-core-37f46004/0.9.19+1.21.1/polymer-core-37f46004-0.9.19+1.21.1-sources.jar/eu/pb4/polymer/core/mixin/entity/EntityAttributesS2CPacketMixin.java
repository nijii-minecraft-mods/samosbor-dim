package eu.pb4.polymer.core.mixin.entity;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import eu.pb4.polymer.core.api.entity.PolymerEntity;
import eu.pb4.polymer.core.api.entity.PolymerEntityUtils;
import eu.pb4.polymer.core.api.utils.PolymerUtils;
import eu.pb4.polymer.common.impl.entity.InternalEntityHelpers;
import eu.pb4.polymer.core.impl.interfaces.EntityAttachedPacket;
import eu.pb4.polymer.core.impl.interfaces.PossiblyInitialPacket;
import eu.pb4.polymer.core.impl.networking.TransformingPacketCodec;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.game.ClientboundUpdateAttributesPacket;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.DefaultAttributes;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import xyz.nucleoid.packettweaker.PacketContext;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Mixin(ClientboundUpdateAttributesPacket.class)
public abstract class EntityAttributesS2CPacketMixin implements PossiblyInitialPacket {
    @Unique
    private boolean isInitial = false;

    @Override
    public boolean polymer$getInitial() {
        return this.isInitial;
    }

    @Override
    public void polymer$setInitial() {
        this.isInitial = true;
    }

    @SuppressWarnings("UnreachableCode")
    @ModifyExpressionValue(method = "<clinit>", at = @At(value = "INVOKE", target = "Lnet/minecraft/network/codec/PacketCodec;tuple(Lnet/minecraft/network/codec/PacketCodec;Ljava/util/function/Function;Lnet/minecraft/network/codec/PacketCodec;Ljava/util/function/Function;Ljava/util/function/BiFunction;)Lnet/minecraft/network/codec/PacketCodec;"))
    private static StreamCodec<RegistryFriendlyByteBuf, ClientboundUpdateAttributesPacket> patchCodec(StreamCodec<RegistryFriendlyByteBuf, ClientboundUpdateAttributesPacket> original) {
        return TransformingPacketCodec.encodeOnly(original, (buf, packet) -> {
            if (EntityAttachedPacket.get(packet, packet.getEntityId()) instanceof PolymerEntity entity) {
                var context = PacketContext.get();
                var type = entity.getPolymerEntityType(context.getPlayer());
                var p = new ClientboundUpdateAttributesPacket(packet.getEntityId(), List.of());
                var list = ((EntityAttributesS2CPacketAccessor) p).getEntries();
                var vanillaContainer = DefaultAttributes.getSupplier((EntityType<? extends LivingEntity>) type);
                var data = new ArrayList<>(packet.getValues());
                entity.modifyRawEntityAttributeData(data, context, ((PossiblyInitialPacket) packet).polymer$getInitial());
                for (var entry : data) {
                    if (vanillaContainer.hasAttribute(entry.attribute()) && !PolymerEntityUtils.isPolymerEntityAttribute(entry.attribute())) {
                        list.add(entry);
                    }
                }
                return p;
            } else {
                var p = new ClientboundUpdateAttributesPacket(packet.getEntityId(), List.of());
                var list = ((EntityAttributesS2CPacketAccessor) p).getEntries();
                for (var entry : packet.getValues()) {
                    if (!PolymerEntityUtils.isPolymerEntityAttribute(entry.attribute())) {
                        list.add(entry);
                    }
                }
                return p;
            }
        });
    }
}
