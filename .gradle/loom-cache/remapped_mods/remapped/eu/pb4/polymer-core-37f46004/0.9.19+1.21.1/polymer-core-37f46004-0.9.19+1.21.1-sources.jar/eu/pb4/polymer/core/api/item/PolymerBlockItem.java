package eu.pb4.polymer.core.api.item;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import org.jetbrains.annotations.Nullable;

/**
 * Basic implementation of PolymerItem for blocks
 */
public class PolymerBlockItem extends BlockItem implements PolymerItem {
    private final Item polymerItem;

    public PolymerBlockItem(Block block, Properties settings, Item virtualItem) {
        super(block, settings);
        this.polymerItem = virtualItem;
    }

    @Override
    public Item getPolymerItem(ItemStack itemStack, @Nullable ServerPlayer player) {
        return this.polymerItem;
    }
}
