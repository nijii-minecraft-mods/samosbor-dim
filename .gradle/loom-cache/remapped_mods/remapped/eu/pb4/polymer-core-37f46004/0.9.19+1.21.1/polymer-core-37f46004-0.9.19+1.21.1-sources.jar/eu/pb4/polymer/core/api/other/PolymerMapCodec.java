package eu.pb4.polymer.core.api.other;

import com.mojang.serialization.*;
import eu.pb4.polymer.common.api.PolymerCommonUtils;
import eu.pb4.polymer.core.api.utils.PolymerObject;
import eu.pb4.polymer.core.api.utils.PolymerUtils;
import java.util.List;
import java.util.stream.Stream;
import net.minecraft.world.item.enchantment.LevelBasedValue;
import net.minecraft.world.item.enchantment.effects.AllOf;
import net.minecraft.world.item.enchantment.effects.EnchantmentEntityEffect;
import net.minecraft.world.item.enchantment.effects.EnchantmentLocationBasedEffect;
import net.minecraft.world.item.enchantment.effects.EnchantmentValueEffect;

public class PolymerMapCodec<T> extends MapCodec<T> implements PolymerObject {
    private final MapCodec<T> selfCodec;
    private final MapCodec<Object> fallbackCodec;
    private final Object fallbackValue;

    public <K> PolymerMapCodec(MapCodec<T> selfCodec, MapCodec<K> fallbackCodec, K fallbackValue) {
        this.selfCodec = selfCodec;
        //noinspection unchecked
        this.fallbackCodec = (MapCodec<Object>) fallbackCodec;
        this.fallbackValue = fallbackValue;
    }

    public static <T extends EnchantmentValueEffect> MapCodec<T> ofEnchantmentValueEffect(MapCodec<T> codec) {
        return new PolymerMapCodec<T>(codec, AllOf.ValueEffects.CODEC, new AllOf.ValueEffects(List.of()));
    }

    public static <T extends EnchantmentLocationBasedEffect> MapCodec<T> ofEnchantmentLocationBasedEffect(MapCodec<T> codec) {
        return new PolymerMapCodec<T>(codec, AllOf.LocationBasedEffects.CODEC, new AllOf.LocationBasedEffects(List.of()));
    }

    public static <T extends EnchantmentEntityEffect> MapCodec<T> ofEnchantmentEntityEffect(MapCodec<T> codec) {
        return new PolymerMapCodec<T>(codec, AllOf.EntityEffects.CODEC, new AllOf.EntityEffects(List.of()));
    }

    public static <T extends LevelBasedValue> MapCodec<T> ofEnchantmentLevelBasedValue(MapCodec<T> codec) {
        return new PolymerMapCodec<T>(codec, LevelBasedValue.Constant.TYPED_CODEC, new LevelBasedValue.Constant(0));
    }

    public Object fallbackValue() {
        return fallbackValue;
    }

    public MapCodec<Object> fallbackCodec() {
        return fallbackCodec;
    }

    @Override
    public <T1> Stream<T1> keys(DynamicOps<T1> ops) {
        return this.selfCodec.keys(ops);
    }

    @Override
    public <T1> DataResult<T> decode(DynamicOps<T1> ops, MapLike<T1> input) {
        return this.selfCodec.decode(ops, input);
    }

    @Override
    public <T1> RecordBuilder<T1> encode(T input, DynamicOps<T1> ops, RecordBuilder<T1> prefix) {
        if (PolymerCommonUtils.isServerNetworkingThreadWithContext()) {
            return this.fallbackCodec.encode(this.fallbackValue, ops, prefix);
        }

        return this.selfCodec.encode(input, ops, prefix);
    }
}
