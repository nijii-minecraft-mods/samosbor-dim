package eu.pb4.polymer.core.mixin.item;

import eu.pb4.polymer.common.impl.CommonImplUtils;
import eu.pb4.polymer.core.api.item.PolymerItem;
import eu.pb4.polymer.core.api.item.PolymerItemUtils;
import eu.pb4.polymer.core.api.item.PolymerItemUtils.ItemWithMetadata;
import eu.pb4.polymer.core.impl.ClientMetadataKeys;
import eu.pb4.polymer.core.impl.PolymerImpl;
import eu.pb4.polymer.core.impl.interfaces.PolymerPlayNetworkHandlerExtension;
import eu.pb4.polymer.core.impl.networking.PolymerServerProtocol;
import eu.pb4.polymer.networking.api.server.PolymerServerNetworking;
import net.minecraft.core.Direction;
import net.minecraft.network.Connection;
import net.minecraft.network.packet.s2c.play.*;
import net.minecraft.network.protocol.common.ClientboundUpdateTagsPacket;
import net.minecraft.network.protocol.common.ServerboundClientInformationPacket;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.network.protocol.game.ClientboundBlockUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundContainerSetSlotPacket;
import net.minecraft.network.protocol.game.ClientboundUpdateRecipesPacket;
import net.minecraft.network.protocol.game.ServerboundContainerClickPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemOnPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerCommonPacketListenerImpl;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.tags.TagNetworkSerialization;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.BucketItem;
import net.minecraft.world.item.Equipable;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;

@Mixin(value = ServerGamePacketListenerImpl.class, priority = 1200)
public abstract class ServerPlayNetworkHandlerMixin extends ServerCommonPacketListenerImpl {
    @Shadow
    public ServerPlayer player;
    @Unique
    private final List<ItemStack> polymerCore$armorItems = new ArrayList<>();
    @Unique
    private String polymerCore$language;

    public ServerPlayNetworkHandlerMixin(MinecraftServer server, Connection connection, CommonListenerCookie clientData) {
        super(server, connection, clientData);
    }

    @Inject(method = "<init>", at = @At("TAIL"))
    private void polymerCore$storeLanguage(MinecraftServer server, Connection connection, ServerPlayer player, CommonListenerCookie clientData, CallbackInfo ci) {
        this.polymerCore$language = clientData.clientInformation().language();
    }


    @Inject(method = "onClientOptions", at = @At("TAIL"))
    private void polymerCore$resendLanguage(ServerboundClientInformationPacket packet, CallbackInfo ci) {
        if (CommonImplUtils.isMainPlayer(this.player)) {
            return;
        }

        if (!this.polymerCore$language.equals(packet.information().language())) {
            this.polymerCore$language = packet.information().language();
            PolymerServerProtocol.sendSyncPackets(player.connection, true);
            this.send(new ClientboundUpdateTagsPacket(TagNetworkSerialization.serializeTagsToNetwork(this.player.serverLevel().getServer().registries())));
            this.send(new ClientboundUpdateRecipesPacket(this.player.serverLevel().getRecipeManager().getRecipes()));
            this.player.getRecipeBook().sendInitialRecipeBook(this.player);
        }
    }

    @Inject(method = "onPlayerInteractBlock", at = @At(value = "INVOKE", target = "Lnet/minecraft/network/NetworkThreadUtils;forceMainThread(Lnet/minecraft/network/packet/Packet;Lnet/minecraft/network/listener/PacketListener;Lnet/minecraft/server/world/ServerWorld;)V", shift = At.Shift.AFTER))
    private void polymer$resendHandOnPlace(ServerboundUseItemOnPacket packet, CallbackInfo ci) {
        ItemStack itemStack = this.player.getItemInHand(packet.getHand());

        if (itemStack.getItem() instanceof PolymerItem polymerItem) {
            var data = PolymerItemUtils.getItemSafely(polymerItem, itemStack, this.player);
            if (data.item() instanceof BlockItem || data.item() instanceof BucketItem) {
                this.send(new ClientboundContainerSetSlotPacket(this.player.inventoryMenu.containerId, this.player.inventoryMenu.incrementStateId(), packet.getHand() == InteractionHand.MAIN_HAND ? 36 + this.player.getInventory().selected : 45, itemStack));
            }
        }
    }

    @Inject(method = "onPlayerInteractItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/network/NetworkThreadUtils;forceMainThread(Lnet/minecraft/network/packet/Packet;Lnet/minecraft/network/listener/PacketListener;Lnet/minecraft/server/world/ServerWorld;)V", shift = At.Shift.AFTER))
    private void polymer$resendHandOnUse(ServerboundUseItemPacket packet, CallbackInfo ci) {
        ItemStack itemStack = this.player.getItemInHand(packet.getHand());

        if (itemStack.getItem() instanceof PolymerItem polymerItem) {
            var data = PolymerItemUtils.getItemSafely(polymerItem, itemStack, this.player);
            if (data.item() instanceof Equipable equipment) {
                if (equipment.getEquipmentSlot().getType() == EquipmentSlot.Type.HUMANOID_ARMOR) {
                    this.send(new ClientboundContainerSetSlotPacket(this.player.inventoryMenu.containerId, this.player.inventoryMenu.incrementStateId(),
                            packet.getHand() == InteractionHand.MAIN_HAND ? 36 + this.player.getInventory().selected : 45, itemStack));

                    this.send(new ClientboundContainerSetSlotPacket(this.player.inventoryMenu.containerId, this.player.inventoryMenu.incrementStateId(),
                            8 - equipment.getEquipmentSlot().getIndex(), this.player.getItemBySlot(equipment.getEquipmentSlot())));
                } else if (equipment.getEquipmentSlot().getType() == EquipmentSlot.Type.ANIMAL_ARMOR && packet.getHand() == InteractionHand.OFF_HAND) {
                    this.send(new ClientboundContainerSetSlotPacket(this.player.inventoryMenu.containerId, this.player.inventoryMenu.incrementStateId(),
                            45, itemStack));
                    this.send(new ClientboundContainerSetSlotPacket(this.player.inventoryMenu.containerId, this.player.inventoryMenu.incrementStateId(),
                            36 + this.player.getInventory().selected, this.player.getMainHandItem()));
                }
            }
        }
    }


    @Inject(method = "onPlayerInteractBlock", at = @At("TAIL"))
    private void polymer$updateMoreBlocks(ServerboundUseItemOnPacket packet, CallbackInfo ci) {
        if (PolymerImpl.RESEND_BLOCKS_AROUND_CLICK) {
            var base = packet.getHitResult().getBlockPos();
            for (Direction direction : Direction.values()) {
                var pos = base.relative(direction);
                var state = player.serverLevel().getBlockState(pos);
                player.connection.send(new ClientboundBlockUpdatePacket(pos, state));

                if (state.hasBlockEntity()) {
                    var be = player.level().getBlockEntity(pos);
                    if (be != null) {
                        player.connection.send(ClientboundBlockEntityDataPacket.create(be));
                    }
                }
            }
        }

        /*var stack = this.player.getStackInHand(packet.getHand());

        if (stack.getItem() instanceof PolymerItem virtualItem) {
            var data = PolymerItemUtils.getItemSafely(virtualItem, stack, this.player);
            if (data.item() instanceof BlockItem || data.item() instanceof BucketItem) {
                this.onPlayerInteractItem(new PlayerInteractItemC2SPacket(packet.getHand(), 0));
            }
        }*/
    }

    @Inject(method = "onClickSlot", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerPlayerEntity;updateLastActionTime()V", shift = At.Shift.AFTER))
    private void polymer$storeArmor(ServerboundContainerClickPacket packet, CallbackInfo ci) {
        if (this.player.containerMenu == this.player.inventoryMenu) {
            for (ItemStack stack : this.player.getInventory().armor) {
                polymerCore$armorItems.add(stack.copy());
            }
        }
    }

    @Inject(method = "onClickSlot", at = @At("TAIL"))
    private void polymer$updateArmor(ServerboundContainerClickPacket packet, CallbackInfo ci) {
        if (this.player.containerMenu == this.player.inventoryMenu && packet.getSlotNum() != -999) {
            int x = 0;
            for (ItemStack stack : this.player.getInventory().armor) {
                if (stack.getItem() instanceof PolymerItem && !ItemStack.matches(this.polymerCore$armorItems.get(x), stack)) {
                    this.send(new ClientboundContainerSetSlotPacket(this.player.inventoryMenu.containerId,
                            this.player.inventoryMenu.incrementStateId(),
                            8 - x,
                            stack));

                    if (packet.getSlotNum() != 8 - x) {
                        this.send(new ClientboundContainerSetSlotPacket(this.player.inventoryMenu.containerId,
                                this.player.inventoryMenu.incrementStateId(),
                                packet.getSlotNum(),
                                this.player.inventoryMenu.getSlot(packet.getSlotNum()).getItem()));
                    }

                    this.send(new ClientboundContainerSetSlotPacket(-1,
                            0,
                            0,
                            this.player.containerMenu.getCarried()));
                    return;
                }
                x++;
            }
        }

        this.polymerCore$armorItems.clear();
    }
}
