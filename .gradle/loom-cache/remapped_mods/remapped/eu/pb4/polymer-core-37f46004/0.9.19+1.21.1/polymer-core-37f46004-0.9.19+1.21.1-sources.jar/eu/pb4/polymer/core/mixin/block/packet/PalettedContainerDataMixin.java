package eu.pb4.polymer.core.mixin.block.packet;

import C;
import com.llamalad7.mixinextras.injector.ModifyReceiver;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import eu.pb4.polymer.core.api.block.PolymerBlockUtils;
import eu.pb4.polymer.core.api.utils.PolymerUtils;
import eu.pb4.polymer.core.impl.ClientMetadataKeys;
import eu.pb4.polymer.core.impl.PolymerImpl;
import eu.pb4.polymer.core.impl.interfaces.PolymerIdList;
import eu.pb4.polymer.networking.api.server.PolymerServerNetworking;
import net.minecraft.nbt.IntTag;
import net.minecraft.util.BitStorage;
import net.minecraft.util.SimpleBitStorage;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.GlobalPalette;
import net.minecraft.world.level.chunk.Palette;
import net.minecraft.world.level.chunk.PalettedContainer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(PalettedContainer.Data.class)
public abstract class PalettedContainerDataMixin<T> {
    @Shadow public abstract Palette<T> palette();

    @Shadow public abstract BitStorage storage();

    @ModifyReturnValue(method = "getPacketSize", at = @At("RETURN"))
    private int changeCalculatedSize(int value) {
        var palette = this.palette();
        if (palette instanceof GlobalPalette<T> && palette.valueFor(0) instanceof BlockState) {
            var player = PolymerUtils.getPlayerContext();
            if (player == null) {
                return value;
            }

            var storage = this.storage();
            value -= storage.getRaw().length * 8;
            int bits;

            var playerBitCount = PolymerServerNetworking.getMetadata(player.connection, ClientMetadataKeys.BLOCKSTATE_BITS, IntTag.TYPE);
            if (playerBitCount == null) {
                bits = PolymerImpl.SYNC_MODDED_ENTRIES_POLYMC
                        ? ((PolymerIdList<?>) Block.BLOCK_STATE_REGISTRY).polymer$getVanillaBitCount()
                        : ((PolymerIdList<?>) Block.BLOCK_STATE_REGISTRY).polymer$getNonPolymerBitCount();
            } else {
                bits = playerBitCount.getAsInt();
            }

            var elementsPerLong = (char)(64 / bits);
            value += (storage.getSize() + elementsPerLong - 1) / elementsPerLong * 8;
        }
        return value;
    }

    @ModifyReceiver(method = "writePacket", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/collection/PaletteStorage;getData()[J"), require = 0)
    private BitStorage polymer$replaceData(BitStorage storage) {
        var palette = this.palette();
        if (palette instanceof GlobalPalette<T> && palette.valueFor(0) instanceof BlockState) {
            var player = PolymerUtils.getPlayerContext();
            if (player == null) {
                return storage;
            }
            int bits;

            var playerBitCount = PolymerServerNetworking.getMetadata(player.connection, ClientMetadataKeys.BLOCKSTATE_BITS, IntTag.TYPE);
            if (playerBitCount == null) {
                bits = PolymerImpl.SYNC_MODDED_ENTRIES_POLYMC
                        ? ((PolymerIdList<?>) Block.BLOCK_STATE_REGISTRY).polymer$getVanillaBitCount()
                        : ((PolymerIdList<?>) Block.BLOCK_STATE_REGISTRY).polymer$getNonPolymerBitCount();
            } else {
                bits = playerBitCount.getAsInt();
            }
            final int size = storage.getSize();
            var data = new SimpleBitStorage(bits, size);

            var stateMap = Block.BLOCK_STATE_REGISTRY;

            for (int i = 0; i < size; i++) {
                data.set(i, stateMap.getId(PolymerBlockUtils.getPolymerBlockState(stateMap.byId(storage.get(i)), player)));
            }

            return data;
        }

        return storage;
    }
}
