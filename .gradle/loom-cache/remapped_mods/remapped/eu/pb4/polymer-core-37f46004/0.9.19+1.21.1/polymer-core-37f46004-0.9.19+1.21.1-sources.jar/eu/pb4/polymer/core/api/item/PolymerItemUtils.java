package eu.pb4.polymer.core.api.item;

import I;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.Dynamic;
import com.mojang.serialization.MapCodec;
import eu.pb4.polymer.common.api.PolymerCommonUtils;
import eu.pb4.polymer.common.api.events.BooleanEvent;
import eu.pb4.polymer.common.api.events.FunctionEvent;
import eu.pb4.polymer.common.impl.CommonImpl;
import eu.pb4.polymer.common.impl.CompatStatus;
import eu.pb4.polymer.core.api.block.PolymerBlockUtils;
import eu.pb4.polymer.core.api.entity.PolymerEntityUtils;
import eu.pb4.polymer.core.api.other.PolymerComponent;
import eu.pb4.polymer.core.api.utils.PolymerUtils;
import eu.pb4.polymer.core.impl.PolymerImpl;
import eu.pb4.polymer.core.impl.PolymerImplUtils;
import eu.pb4.polymer.core.impl.TransformingComponent;
import eu.pb4.polymer.core.impl.compat.polymc.PolyMcUtils;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import eu.pb4.polymer.rsm.api.RegistrySyncUtils;
import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet;
import net.minecraft.ChatFormatting;
import net.minecraft.component.type.*;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.RegistryOps;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Unit;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.DefaultAttributes;
import net.minecraft.world.item.AdventureModePredicate;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.JukeboxPlayable;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.armortrim.ArmorTrim;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.CustomModelData;
import net.minecraft.world.item.component.DyedItemColor;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.item.component.Unbreakable;
import net.minecraft.world.item.enchantment.EnchantmentEffectComponents;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import org.jetbrains.annotations.Nullable;
import xyz.nucleoid.packettweaker.PacketContext;

import java.util.*;
import java.util.Map.Entry;
import java.util.function.Predicate;

public final class PolymerItemUtils {
    public static final String POLYMER_STACK = "$polymer:stack";
    private static final String POLYMC_STACK = "PolyMcOriginal";
    public static final MapCodec<ItemStack> POLYMER_STACK_CODEC = ItemStack.CODEC.fieldOf(POLYMER_STACK);
    public static final MapCodec<ItemStack> POLYMER_STACK_UNCOUNTED_CODEC = ItemStack.SINGLE_ITEM_CODEC.fieldOf(POLYMER_STACK);
    public static final MapCodec<Boolean> POLYMER_STACK_HAS_COUNT_CODEC = Codec.BOOL.optionalFieldOf("$polymer:counted", false);
    public static final MapCodec<ResourceLocation> POLYMER_STACK_ID_CODEC = ResourceLocation.CODEC.fieldOf("id").fieldOf(POLYMER_STACK);

    private static final Codec<Map<ResourceLocation, Tag>> COMPONENTS_CODEC = Codec.unboundedMap(ResourceLocation.CODEC,
            Codec.PASSTHROUGH.comapFlatMap((dynamic) -> {
                var nbt = dynamic.convert(NbtOps.INSTANCE).getValue();
                return DataResult.success(nbt == dynamic.getValue() ? nbt.copy() : nbt);
            }, (nbt) -> new Dynamic<>(NbtOps.INSTANCE, nbt.copy())));

    public static final MapCodec<Map<ResourceLocation, Tag>> POLYMER_STACK_COMPONENTS_CODEC = COMPONENTS_CODEC
            .optionalFieldOf("components", Map.of()).fieldOf(POLYMER_STACK);


    private static final MapCodec<ItemStack> POLYMC_STACK_CODEC = ItemStack.SINGLE_ITEM_CODEC.fieldOf(POLYMC_STACK);
    private static final MapCodec<ResourceLocation> POLYMC_STACK_ID_CODEC = ResourceLocation.CODEC.fieldOf("id").fieldOf(POLYMC_STACK);
    private static final MapCodec<Map<ResourceLocation, Tag>> POLYMC_STACK_COMPONENTS_CODEC = COMPONENTS_CODEC.optionalFieldOf("components", Map.of()).fieldOf(POLYMC_STACK);

    public static final Style CLEAN_STYLE = Style.EMPTY.withItalic(false).withColor(ChatFormatting.WHITE);
    /**
     * Allows to force rendering of some items as polymer one (for example vanilla ones)
     */
    public static final BooleanEvent<Predicate<ItemStack>> ITEM_CHECK = new BooleanEvent<>();
    /**
     * Allows to modify how virtual items looks before being sent to client (only if using build in methods!)
     * It can modify virtual version directly, as long as it's returned at the end.
     * You can also return new ItemStack, however please keep previous nbt so other modifications aren't removed if not needed!
     */
    public static final FunctionEvent<ItemModificationEventHandler, ItemStack> ITEM_MODIFICATION_EVENT = new FunctionEvent<>();
    private static final DataComponentType<?>[] COMPONENTS_TO_COPY = {DataComponents.CAN_BREAK, DataComponents.CAN_PLACE_ON,
            DataComponents.BLOCK_ENTITY_DATA, DataComponents.TRIM,
            DataComponents.TOOL,
            DataComponents.MAX_STACK_SIZE,
            DataComponents.FOOD,
            DataComponents.FIRE_RESISTANT,
            DataComponents.FIREWORKS,
            DataComponents.FIREWORK_EXPLOSION,
            DataComponents.DAMAGE,
            DataComponents.MAX_DAMAGE,
            DataComponents.ATTRIBUTE_MODIFIERS,
            DataComponents.BANNER_PATTERNS,
            DataComponents.BASE_COLOR,
            DataComponents.HIDE_TOOLTIP,
            DataComponents.CAN_BREAK,
            DataComponents.CAN_PLACE_ON,
            DataComponents.REPAIR_COST,
            DataComponents.BUNDLE_CONTENTS,
            DataComponents.RARITY,
            DataComponents.LODESTONE_TRACKER,
            DataComponents.ENCHANTMENTS,
            DataComponents.STORED_ENCHANTMENTS,
            DataComponents.POTION_CONTENTS,
            DataComponents.CUSTOM_NAME,
            DataComponents.JUKEBOX_PLAYABLE,
            DataComponents.WRITABLE_BOOK_CONTENT,
            DataComponents.WRITTEN_BOOK_CONTENT,
            DataComponents.CONTAINER,
    };
    @SuppressWarnings("rawtypes")
    private static final List<HideableTooltip> HIDEABLE_TOOLTIPS = List.of(
            HideableTooltip.of(DataComponents.ATTRIBUTE_MODIFIERS, ItemAttributeModifiers::withTooltip),
            HideableTooltip.of(DataComponents.TRIM, ArmorTrim::withTooltip),
            HideableTooltip.ofNeg(DataComponents.ENCHANTMENTS, ItemEnchantments::isEmpty, ItemEnchantments::withTooltip),
            HideableTooltip.ofNeg(DataComponents.STORED_ENCHANTMENTS, ItemEnchantments::isEmpty, ItemEnchantments::withTooltip),
            HideableTooltip.of(DataComponents.UNBREAKABLE, Unbreakable::withTooltip),
            HideableTooltip.of(DataComponents.CAN_BREAK, AdventureModePredicate::withTooltip),
            HideableTooltip.of(DataComponents.CAN_PLACE_ON, AdventureModePredicate::withTooltip),
            HideableTooltip.of(DataComponents.JUKEBOX_PLAYABLE, JukeboxPlayable::withTooltip)
    );
    private static final Set<ArmorMaterial> ARMOR_MATERIALS = new ReferenceOpenHashSet<>();

    private PolymerItemUtils() {
    }

    /**
     * This method creates a client side ItemStack representation
     *
     * @param itemStack Server side ItemStack
     * @param context   Networking context
     * @return Client side ItemStack
     */
    public static ItemStack getPolymerItemStack(ItemStack itemStack, PacketContext context) {
        return getPolymerItemStack(itemStack, context.getRegistryWrapperLookup() != null ? context.getRegistryWrapperLookup() : PolymerImplUtils.FALLBACK_LOOKUP,
                context.getPlayer());
    }

    /**
     * This method creates a client side ItemStack representation
     *
     * @param itemStack Server side ItemStack
     * @param player    Player being sent to
     * @return Client side ItemStack
     */
    public static ItemStack getPolymerItemStack(ItemStack itemStack, HolderLookup.Provider lookup, @Nullable ServerPlayer player) {
        return getPolymerItemStack(itemStack, PolymerUtils.getTooltipType(player), lookup, player);
    }

    /**
     * This method creates a client side ItemStack representation
     *
     * @param itemStack      Server side ItemStack
     * @param tooltipContext Tooltip Context
     * @param player         Player being sent to
     * @return Client side ItemStack
     */
    public static ItemStack getPolymerItemStack(ItemStack itemStack, TooltipFlag tooltipContext, HolderLookup.Provider lookup, @Nullable ServerPlayer player) {
        if (getPolymerIdentifier(itemStack) != null) {
            return itemStack;
        } else if (itemStack.getItem() instanceof PolymerItem item) {
            return item.getPolymerItemStack(itemStack, tooltipContext, lookup, player);
        } else if (isPolymerServerItem(itemStack, player)) {
            return createItemStack(itemStack, tooltipContext, lookup, player);
        }

        if (ITEM_CHECK.invoke((x) -> x.test(itemStack))) {
            return createItemStack(itemStack, tooltipContext, lookup, player);
        }

        return itemStack;
    }

    /**
     * This method gets real ItemStack from Virtual/Client side one
     *
     * @param itemStack Client side ItemStack
     * @return Server side ItemStack
     */
    public static ItemStack getRealItemStack(ItemStack itemStack, HolderLookup.Provider lookup) {
        var custom = itemStack.get(DataComponents.CUSTOM_DATA);

        if (custom != null && custom.contains(POLYMER_STACK)) {
            try {
                var counted = custom.read(POLYMER_STACK_HAS_COUNT_CODEC).result().orElse(Boolean.FALSE);

                //noinspection deprecation
                var x = (counted ? POLYMER_STACK_CODEC : POLYMER_STACK_UNCOUNTED_CODEC).decode(RegistryOps.create(NbtOps.INSTANCE, lookup), NbtOps.INSTANCE.getMap(custom.getUnsafe()).getOrThrow()).getOrThrow();

                if (!counted) {
                    x.setCount(itemStack.getCount());
                }

                return x;
            } catch (Throwable exception) {
                if (CommonImpl.LOG_MORE_ERRORS) {
                    var context = PacketContext.get();
                    Tag nbt = null;
                    try {
                        nbt = itemStack.saveOptional(lookup);
                    } catch (Throwable e) {
                        CommonImpl.LOGGER.error("Failed to encode ItemStack for debugging! See lower warning for more info!", exception);
                    }

                    CommonImpl.LOGGER.warn("Failed to decode seemingly polymeric ItemStack for {}!\nClient item data: {}",
                            context.getGameProfile() != null ? context.getGameProfile().getName() : "<UNKNOWN>",
                            nbt != null ? NbtUtils.prettyPrint(nbt) : "<ERROR>",
                            exception);
                }
            }
        }

        return itemStack;
    }

    /**
     * Returns stored identifier of Polymer ItemStack. If it's invalid, null is returned instead.
     */
    @Nullable
    public static ResourceLocation getPolymerIdentifier(ItemStack itemStack) {
        return getPolymerIdentifier(itemStack.get(DataComponents.CUSTOM_DATA));
    }

    public static ResourceLocation getPolymerIdentifier(@Nullable CustomData custom) {
        if (custom != null && custom.contains(POLYMER_STACK)) {
            try {
                return custom.read(POLYMER_STACK_ID_CODEC).result().orElse(null);
            } catch (Throwable ignored) {

            }
        }

        return null;
    }

    /**
     * Returns stored identifier of Polymer/other supported server mod ItemStack. If it's invalid, null is returned instead.
     */
    @Nullable
    public static ResourceLocation getServerIdentifier(ItemStack itemStack) {
        return getServerIdentifier(itemStack.get(DataComponents.CUSTOM_DATA));
    }

    @Nullable
    public static ResourceLocation getServerIdentifier(@Nullable CustomData nbtData) {
        if (nbtData == null) {
            return null;
        }
        var x = getPolymerIdentifier(nbtData);
        if (x != null) {
            return x;
        }

        if (nbtData.contains(POLYMC_STACK)) {
            try {
                return nbtData.read(POLYMC_STACK_ID_CODEC).result().orElse(null);
            } catch (Throwable ignored) {

            }
        }

        return null;
    }

    @Nullable
    public static Map<ResourceLocation, Tag> getServerComponents(ItemStack stack) {
        return getServerComponents(stack.get(DataComponents.CUSTOM_DATA));
    }

    @Nullable
    public static Map<ResourceLocation, Tag> getPolymerComponents(ItemStack stack) {
        return getPolymerComponents(stack.get(DataComponents.CUSTOM_DATA));
    }

    @Nullable
    public static Map<ResourceLocation, Tag> getServerComponents(@Nullable CustomData nbtData) {
        if (nbtData == null) {
            return null;
        }
        var x = getPolymerComponents(nbtData);
        if (x != null) {
            return x;
        }

        if (nbtData.contains(POLYMC_STACK)) {
            try {
                return nbtData.read(POLYMC_STACK_COMPONENTS_CODEC).result().orElse(Map.of());
            } catch (Throwable ignored) {

            }
        }

        return null;
    }

    @Nullable
    public static Map<ResourceLocation, Tag> getPolymerComponents(@Nullable CustomData nbtData) {
        if (nbtData == null || getPolymerIdentifier(nbtData) == null) {
            return null;
        }

        return nbtData.read(POLYMER_STACK_COMPONENTS_CODEC).result().orElse(Map.of());
    }

    public static boolean isPolymerServerItem(ItemStack itemStack) {
        return isPolymerServerItem(itemStack, PolymerUtils.getPlayerContext());
    }

    public static boolean isPolymerServerItem(ItemStack itemStack, PacketContext context) {
        return isPolymerServerItem(itemStack, context.getPlayer());
    }

    public static boolean isPolymerServerItem(ItemStack itemStack, @Nullable ServerPlayer player) {
        if (getPolymerIdentifier(itemStack) != null) {
            return false;
        }
        if (itemStack.getItem() instanceof PolymerItem) {
            return true;
        }
        var ctx = PacketContext.get();
        if (player != null && ctx.getPlayer() != player) {
            ctx = PacketContext.of(player);
        }

        for (var x : itemStack.getComponentsPatch().entrySet()) {
            if (!PolymerComponent.canSync(x.getKey(), x.getValue().orElse(null), ctx)) {
                return true;
            } else if (x.getValue() != null && x.getValue().isPresent()
                    && x.getValue().get() instanceof TransformingComponent t
                    && t.polymer$requireModification(ctx)) {
                return true;
            }
        }

        if (itemStack.has(DataComponents.ENCHANTMENTS) && itemStack.getOrDefault(DataComponents.ATTRIBUTE_MODIFIERS, ItemAttributeModifiers.EMPTY).showInTooltip()) {
            for (var ench : itemStack.getOrDefault(DataComponents.ENCHANTMENTS, ItemEnchantments.EMPTY).keySet()) {
                var attributes = ench.value().getEffects(EnchantmentEffectComponents.ATTRIBUTES);
                if (attributes != null) {
                    for (var attr : attributes) {
                        if (PolymerEntityUtils.isPolymerEntityAttribute(attr.attribute())
                                && DefaultAttributes.getSupplier(EntityType.PLAYER).hasAttribute(attr.attribute())) {
                            return true;
                        }
                    }
                }
            }
        }

        if (CompatStatus.POLYMER_RESOURCE_PACK) {
            var display = itemStack.get(DataComponents.DYED_COLOR);
            if (display != null) {
                return PolymerResourcePackUtils.isColorTaken(display.rgb());
            }
        }


        return ITEM_CHECK.invoke((x) -> x.test(itemStack));
    }

    /**
     * This method creates minimal representation of ItemStack
     *
     * @param itemStack Server side ItemStack
     * @param player    Player seeing it
     * @return Client side ItemStack
     */
    public static ItemStack createMinimalItemStack(ItemStack itemStack, HolderLookup.Provider lookup, @Nullable ServerPlayer player) {
        Item item = itemStack.getItem();
        var x = itemStack.get(DataComponents.CUSTOM_MODEL_DATA);
        int cmd = x != null ? x.value() : -1;
        if (itemStack.getItem() instanceof PolymerItem virtualItem) {
            var data = PolymerItemUtils.getItemSafely(virtualItem, itemStack, player);
            item = data.item();
            cmd = data.customModelData();
        }

        ItemStack out = new ItemStack(item, itemStack.getCount());

        try {
            PolymerCommonUtils.executeWithoutNetworkingLogic(() -> {
                out.set(DataComponents.CUSTOM_DATA, CustomData.of(
                        (CompoundTag) POLYMER_STACK_CODEC.encoder().encodeStart(RegistryOps.create(NbtOps.INSTANCE, lookup), itemStack).getOrThrow()
                ));
            });
        } catch (Throwable e) {
            out.set(DataComponents.CUSTOM_DATA, CustomData.EMPTY.update(RegistryOps.create(NbtOps.INSTANCE, lookup), POLYMER_STACK_ID_CODEC, BuiltInRegistries.ITEM.getKey(itemStack.getItem())).getOrThrow());
        }

        if (cmd != -1) {
            out.set(DataComponents.CUSTOM_MODEL_DATA, new CustomModelData(cmd));
        }

        return out;
    }

    public static int getSafeColor(int inputColor) {
        if (inputColor % 2 == 1) {
            return Math.max(0, inputColor - 1);
        }
        return inputColor;
    }

    /**
     * This method creates full (vanilla like) representation of ItemStack
     *
     * @param itemStack Server side ItemStack
     * @param player    Player seeing it
     * @return Client side ItemStack
     */

    public static ItemStack createItemStack(ItemStack itemStack, HolderLookup.Provider lookup, @Nullable ServerPlayer player) {
        return createItemStack(itemStack, PolymerUtils.getTooltipType(player), lookup, player);
    }

    /**
     * This method creates full (vanilla like) representation of ItemStack
     *
     * @param itemStack      Server side ItemStack
     * @param tooltipContext TooltipContext
     * @param player         Player seeing it
     * @return Client side ItemStack
     */
    public static ItemStack createItemStack(ItemStack itemStack, TooltipFlag tooltipContext, HolderLookup.Provider lookup, @Nullable ServerPlayer player) {
        Item item = itemStack.getItem();
        int cmd = -1;
        int color = -1;
        boolean storeCount;
        if (itemStack.getItem() instanceof PolymerItem virtualItem) {
            var data = PolymerItemUtils.getItemSafely(virtualItem, itemStack, player);
            item = data.item();
            cmd = data.customModelData();
            color = data.color();
            storeCount = virtualItem.shouldStorePolymerItemStackCount();
        } else {
            storeCount = false;
        }

        ItemStack out = new ItemStack(item, itemStack.getCount());
        for (var x : out.getComponents().keySet()) {
            if (itemStack.getComponents().get(x) == null) {
                out.set(x, null);
            }
        }

        var ctx = PacketContext.get();
        if (player != null && ctx.getPlayer() != player) {
            ctx = PacketContext.of(player);
        }

        for (var i = 0; i < COMPONENTS_TO_COPY.length; i++) {
            var key = COMPONENTS_TO_COPY[i];
            var x = itemStack.get(key);

            if (x instanceof TransformingComponent t) {
                //noinspection unchecked,rawtypes
                out.set((DataComponentType) key, t.polymer$getTransformed(ctx));
            } else {
                //noinspection unchecked,rawtypes
                out.set((DataComponentType) key, (Object) itemStack.get(key));
            }
        }
        try {
            PolymerCommonUtils.executeWithoutNetworkingLogic(() -> {
                var comp = CustomData.of(
                        (CompoundTag) (storeCount ? POLYMER_STACK_CODEC : POLYMER_STACK_UNCOUNTED_CODEC).encoder()
                                .encodeStart(RegistryOps.create(NbtOps.INSTANCE, lookup), itemStack).getOrThrow()
                );
                if (storeCount) {
                    out.set(DataComponents.CUSTOM_DATA, comp.update(RegistryOps.create(NbtOps.INSTANCE, lookup), POLYMER_STACK_HAS_COUNT_CODEC, true).getOrThrow());
                } else {
                    out.set(DataComponents.CUSTOM_DATA, comp);
                }
            });
        } catch (Throwable e) {
            out.set(DataComponents.CUSTOM_DATA, CustomData.EMPTY.update(RegistryOps.create(NbtOps.INSTANCE, lookup), POLYMER_STACK_ID_CODEC, BuiltInRegistries.ITEM.getKey(itemStack.getItem())).getOrThrow());
        }


        if (cmd == -1 && itemStack.has(DataComponents.CUSTOM_MODEL_DATA)) {
            out.set(DataComponents.CUSTOM_MODEL_DATA, itemStack.get(DataComponents.CUSTOM_MODEL_DATA));
        } else if (cmd != -1) {
            out.set(DataComponents.CUSTOM_MODEL_DATA, new CustomModelData(cmd));
        }

        if (color == -1 && itemStack.has(DataComponents.DYED_COLOR)) {
            out.set(DataComponents.DYED_COLOR, new DyedItemColor(getSafeColor(itemStack.get(DataComponents.DYED_COLOR).rgb()), false));
        } else if (color != -1) {
            out.set(DataComponents.DYED_COLOR, new DyedItemColor(color, false));
        }

        out.set(DataComponents.HIDE_ADDITIONAL_TOOLTIP, Unit.INSTANCE);

        for (var x : HIDEABLE_TOOLTIPS) {
            var a = out.get(x.type);
            //noinspection unchecked
            if (a != null && x.shouldSet.test(a)) {
                //noinspection unchecked
                out.set(x.type, x.setter.setTooltip(a, false));
            }
        }

        out.set(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, itemStack.hasFoil());

        try {
            var tooltip = itemStack.getTooltipLines(player != null ? Item.TooltipContext.of(player.level()) : Item.TooltipContext.EMPTY, player, tooltipContext);
            if (!tooltip.isEmpty()) {
                out.set(DataComponents.ITEM_NAME, tooltip.remove(0));

                if (itemStack.getItem() instanceof PolymerItem) {
                    ((PolymerItem) itemStack.getItem()).modifyClientTooltip(tooltip, itemStack, player);
                }

                var lore = new ArrayList<Component>();
                for (Component t : tooltip) {
                    lore.add(Component.empty().append(t).setStyle(PolymerItemUtils.CLEAN_STYLE));
                }
                out.set(DataComponents.LORE, new ItemLore(lore));
            }
        } catch (Throwable e) {
            if (PolymerImpl.LOG_MORE_ERRORS) {
                PolymerImpl.LOGGER.error("Failed to get tooltip of " + itemStack, e);
            }
            out.set(DataComponents.ITEM_NAME, itemStack.getOrDefault(DataComponents.ITEM_NAME,
                    itemStack.getItem().getName(itemStack)));
        }
        return ITEM_MODIFICATION_EVENT.invoke((col) -> {
            var custom = out;

            for (var in : col) {
                custom = in.modifyItem(itemStack, custom, player);
            }

            return custom;
        });
    }

    /**
     * This method is minimal wrapper around {@link PolymerItem#getPolymerItem(ItemStack, ServerPlayer)} to make sure
     * It gets replaced if it represents other PolymerItem
     *
     * @param item        PolymerItem
     * @param stack       Server side ItemStack
     * @param maxDistance Maximum number of checks for nested virtual blocks
     * @return Client side ItemStack
     */
    public static ItemWithMetadata getItemSafely(PolymerItem item, ItemStack stack, @Nullable ServerPlayer player, int maxDistance) {
        Item out = item.getPolymerItem(stack, player);
        PolymerItem lastVirtual = item;

        int req = 0;
        while (out instanceof PolymerItem newItem && newItem != item && req < maxDistance) {
            out = newItem.getPolymerItem(stack, player);
            lastVirtual = newItem;
            req++;
        }
        return new ItemWithMetadata(out, lastVirtual.getPolymerCustomModelData(stack, player), lastVirtual.getPolymerArmorColor(stack, player));
    }

    /**
     * This method is minimal wrapper around {@link PolymerItem#getPolymerItem(ItemStack, ServerPlayer)} to make sure
     * It gets replaced if it represents other PolymerItem
     *
     * @param item  PolymerItem
     * @param stack Server side ItemStack
     * @return Client side ItemStack
     */
    public static ItemWithMetadata getItemSafely(PolymerItem item, ItemStack stack, @Nullable ServerPlayer player) {
        return getItemSafely(item, stack, player, PolymerBlockUtils.NESTED_DEFAULT_DISTANCE);
    }

    /**
     * Marks ArmorMaterial as server-side only
     *
     * @param types ArmorMaterials
     */
    @SafeVarargs
    public static void registerArmorMaterial(Holder<ArmorMaterial>... types) {
        for (var type : types) {
            RegistrySyncUtils.setServerEntry(BuiltInRegistries.ARMOR_MATERIAL, type.value());
            ARMOR_MATERIALS.add(type.value());

        }
    }

    /**
     * Checks if ArmorMaterial is server-side only
     *
     * @param type ArmorMaterials
     */
    public static boolean isPolymerArmorMaterial(Holder<ArmorMaterial> type) {
        return ARMOR_MATERIALS.contains(type.value());
    }

    /**
     * @deprecated Use {@link PolymerComponent#registerDataComponent(DataComponentType[])} instead
     */
    @Deprecated
    public static void markAsPolymer(DataComponentType<?>... types) {
        PolymerComponent.registerDataComponent(types);
    }

    /**
     * @deprecated Use {@link PolymerComponent#isPolymerComponent(DataComponentType)} instead
     */
    @Deprecated
    public static boolean isPolymerComponent(DataComponentType<?> type) {
        return PolymerComponent.isPolymerComponent(type);
    }

    public static ItemStack getClientItemStack(ItemStack stack, ServerPlayer player) {
        var out = getPolymerItemStack(stack, player.registryAccess(), player);
        if (CompatStatus.POLYMC) {
            out = PolyMcUtils.toVanilla(out, player);
        }
        return out;
    }

    @FunctionalInterface
    public interface ItemModificationEventHandler {
        ItemStack modifyItem(ItemStack original, ItemStack client, ServerPlayer player);
    }

    public record ItemWithMetadata(Item item, int customModelData, int color) {
    }

    private record HideableTooltip<T>(DataComponentType<T> type, Predicate<T> shouldSet, TooltipSetter<T> setter) {

        public static <T> HideableTooltip<T> of(DataComponentType<T> type, TooltipSetter<T> setter) {
            return new HideableTooltip<>(type, x -> true, setter);
        }

        public static <T> HideableTooltip<T> of(DataComponentType<T> type, Predicate<T> shouldSet, TooltipSetter<T> setter) {
            return new HideableTooltip<>(type, shouldSet, setter);
        }

        public static <T> HideableTooltip<T> ofNeg(DataComponentType<T> type, Predicate<T> shouldntSet, TooltipSetter<T> setter) {
            return new HideableTooltip<>(type, shouldntSet.negate(), setter);
        }

        interface TooltipSetter<T> {
            T setTooltip(T val, boolean value);
        }
    }
}
