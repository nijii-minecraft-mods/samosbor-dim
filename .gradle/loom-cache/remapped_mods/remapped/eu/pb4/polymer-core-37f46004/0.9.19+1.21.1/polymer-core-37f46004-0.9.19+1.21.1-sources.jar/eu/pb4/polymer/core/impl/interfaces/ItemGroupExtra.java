package eu.pb4.polymer.core.impl.interfaces;

import eu.pb4.polymer.core.api.item.PolymerItemGroupUtils;
import net.minecraft.core.HolderLookup;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.flag.FeatureFlagSet;

public interface ItemGroupExtra {
    PolymerItemGroupUtils.Contents polymer$getContentsWith(ResourceLocation id, FeatureFlagSet enabledFeatures, boolean operatorEnabled, HolderLookup.Provider lookup);
    default boolean polymer$isSyncable() {
        return true;
    }
}
