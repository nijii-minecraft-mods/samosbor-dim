package eu.pb4.polymer.core.mixin.other;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.List;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;

@Mixin(CreativeModeTabs.class)
public interface ItemGroupsAccessor {
    @Invoker
    static void callUpdateEntries(CreativeModeTab.ItemDisplayParameters x) {
        throw new UnsupportedOperationException();
    }

    @Accessor
    static CreativeModeTab.ItemDisplayParameters getDisplayContext() {
        throw new UnsupportedOperationException();
    }
}
