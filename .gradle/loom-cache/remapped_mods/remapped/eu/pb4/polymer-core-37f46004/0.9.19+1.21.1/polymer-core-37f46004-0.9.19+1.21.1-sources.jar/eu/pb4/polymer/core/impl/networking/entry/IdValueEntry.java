package eu.pb4.polymer.core.impl.networking.entry;

import eu.pb4.polymer.networking.api.ContextByteBuf;
import java.util.function.BiFunction;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.ResourceLocation;

public record IdValueEntry(int rawId, ResourceLocation id)  {

    public static final StreamCodec<ContextByteBuf, IdValueEntry> CODEC = StreamCodec.ofMember(IdValueEntry::write, IdValueEntry::read);
    public void write(FriendlyByteBuf buf) {
        buf.writeVarInt(rawId);
        buf.writeResourceLocation(id);
    }

    public static IdValueEntry read(FriendlyByteBuf buf) {
        return new IdValueEntry(buf.readVarInt(), buf.readResourceLocation());
    }

    public static <T> T read(FriendlyByteBuf buf, BiFunction<Integer, ResourceLocation, T> function) {
        return function.apply(buf.readVarInt(), buf.readResourceLocation());
    }
}
