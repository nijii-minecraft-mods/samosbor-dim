package eu.pb4.polymer.core.mixin.client.rendering;

import com.llamalad7.mixinextras.sugar.Local;
import eu.pb4.polymer.core.api.utils.PolymerKeepModel;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;
import net.minecraft.client.resources.model.BlockStateModelLoader;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;

@Mixin(BlockStateModelLoader.class)
public class BlockStatesLoaderMixin {
    @Shadow @Final private BlockStateModelLoader.LoadedModel missingModel;

    @Inject(method = "loadBlockStates", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/resource/ResourceFinder;toResourcePath(Lnet/minecraft/util/Identifier;)Lnet/minecraft/util/Identifier;", ordinal = 0))
    private void setDefaultModelsForPolymer(ResourceLocation id, StateDefinition<Block, BlockState> stateManager, CallbackInfo ci,
                                            @Local(ordinal = 1) Map<BlockState, BlockStateModelLoader.LoadedModel> modelMap) {
        if (PolymerKeepModel.useServerModel(BuiltInRegistries.BLOCK.get(id))) {
            for (var state : stateManager.getPossibleStates()) {
                modelMap.put(state, this.missingModel);
            }
        }
    }
}
