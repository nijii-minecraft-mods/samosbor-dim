package eu.pb4.polymer.core.api.entity;

import eu.pb4.polymer.common.impl.CommonImplUtils;
import eu.pb4.polymer.common.impl.entity.InternalEntityHelpers;
import eu.pb4.polymer.core.impl.interfaces.EntityAttachedPacket;
import eu.pb4.polymer.core.impl.networking.PolymerServerProtocol;
import eu.pb4.polymer.core.mixin.entity.EntityAccessor;
import eu.pb4.polymer.core.mixin.entity.PlayerListS2CPacketAccessor;
import eu.pb4.polymer.rsm.api.RegistrySyncUtils;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenCustomHashMap;
import it.unimi.dsi.fastutil.objects.ObjectOpenCustomHashSet;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.npc.VillagerProfession;

public final class PolymerEntityUtils {
    private PolymerEntityUtils() {
    }

    private static final Set<EntityType<?>> ENTITY_TYPES = new ObjectOpenCustomHashSet<>(CommonImplUtils.IDENTITY_HASH);
    private static final Set<Attribute> ENTITY_ATTRIBUTES = new ObjectOpenCustomHashSet<>(CommonImplUtils.IDENTITY_HASH);

    private static final Map<VillagerProfession, PolymerVillagerProfession> VILLAGER_PROFESSIONS = new Object2ObjectOpenCustomHashMap<>(CommonImplUtils.IDENTITY_HASH);

    /**
     * Allows to get next free entity id you can use for networking
     *
     * @return free entity id
     */
    public static int requestFreeId() {
        return EntityAccessor.getCURRENT_ID().incrementAndGet();
    }

    /**
     * Marks EntityTypes as server-side only
     *
     * @param types Entity Types
     */
    public static void registerType(EntityType<?>... types) {
        ENTITY_TYPES.addAll(Arrays.asList(types));

        for (var type : types) {
            RegistrySyncUtils.setServerEntry(BuiltInRegistries.ENTITY_TYPE, type);
        }
    }


    /**
     * Marks EntityAttribute as server-side only
     */
    @SafeVarargs
    public static void registerAttribute(Holder<Attribute>... attributes) {
        for (var type : attributes) {
            ENTITY_ATTRIBUTES.add(type.value());
            RegistrySyncUtils.setServerEntry(BuiltInRegistries.ATTRIBUTE, type.value());
        }
    }

    /**
     * Marks EntityTypes as server-side only
     *
     * @param profession VillagerProfession to server side
     * @param mapper object managing mapping to client compatible one
     */
    public static void registerProfession(VillagerProfession profession, PolymerVillagerProfession mapper) {
        VILLAGER_PROFESSIONS.put(profession, mapper);
        RegistrySyncUtils.setServerEntry(BuiltInRegistries.VILLAGER_PROFESSION, profession);
    }

    @Nullable
    public static PolymerVillagerProfession getPolymerProfession(VillagerProfession profession) {
        return VILLAGER_PROFESSIONS.get(profession);
    }

    /**
     * Checks if EntityType is server-side only
     *
     * @param type EntityType
     */
    public static boolean isPolymerEntityType(EntityType<?> type) {
        return ENTITY_TYPES.contains(type);
    }

    public static boolean isPolymerEntityAttribute(Holder<Attribute> type) {
        return ENTITY_ATTRIBUTES.contains(type.value());
    }

    /**
     * @param type EntityType
     * @return Array of default DataTracker entries for entity type
     */
    public static SynchedEntityData.DataItem<?>[] getDefaultTrackedData(EntityType<?> type) {
        return InternalEntityHelpers.getExampleTrackedDataOfEntityType(type);
    }

    /**
     * @param type EntityType
     * @return Entity Class associated with EntityType
     */
    public static <T extends Entity> Class<T> getEntityClass(EntityType<T> type) {
        return InternalEntityHelpers.getEntityClass(type);
    }

    /**
     * @param type EntityType
     * @return True if EntityType is LivingEntity;
     */
    public static boolean isLivingEntity(EntityType<?> type) {
        return InternalEntityHelpers.isLivingEntity(type);
    }

    /**
     * @param type EntityType
     * @return True if EntityType is MobEntity;
     */
    public static boolean isMobEntity(EntityType<?> type) {
        return InternalEntityHelpers.isMobEntity(type);
    }

    /**
     * @return Creates PlayerEntity spawn packet, that can be used by VirtualEntities
     */
    public static ClientboundPlayerInfoUpdatePacket createMutablePlayerListPacket(EnumSet<ClientboundPlayerInfoUpdatePacket.Action> actions) {
        var packet = new ClientboundPlayerInfoUpdatePacket(actions, List.of());
        ((PlayerListS2CPacketAccessor) packet).setEntries(new ArrayList<>());
        return packet;
    }

    public static boolean canHoldEntityContext(Packet<?> packet) {
        return packet instanceof EntityAttachedPacket;
    }

    public static <T extends Packet<ClientGamePacketListener>> T setEntityContext(T packet, Entity entity) {
        return EntityAttachedPacket.setIfEmpty(packet, entity);
    }

    public static <T extends Packet<ClientGamePacketListener>> T forceSetEntityContext(T packet, Entity entity) {
        return EntityAttachedPacket.set(packet, entity);
    }

    @Nullable
    public static Entity getEntityContext(Packet<?> packet) {
        return EntityAttachedPacket.get(packet);
    }

    public static void sendEntityType(ServerPlayer player, int entityId, EntityType<?> entityType) {
        PolymerServerProtocol.sendEntityInfo(player.connection, entityId, entityType);
    }

    @Deprecated
    public static boolean isRegisteredEntityType(EntityType<?> type) {
        return ENTITY_TYPES.contains(type);
    }
}

