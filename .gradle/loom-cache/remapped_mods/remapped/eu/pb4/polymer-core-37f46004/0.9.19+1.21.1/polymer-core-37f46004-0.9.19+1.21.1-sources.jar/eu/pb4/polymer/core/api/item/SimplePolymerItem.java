package eu.pb4.polymer.core.api.item;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;

/**
 * Basic implementation of PolymerItem
 */
public class SimplePolymerItem extends Item implements PolymerItem {
    private final Item polymerItem;

    public SimplePolymerItem(Properties settings, Item polymerItem) {
        super(settings);
        this.polymerItem = polymerItem;
    }

    @Override
    public Item getPolymerItem(ItemStack itemStack, @Nullable ServerPlayer player) {
        return this.polymerItem;
    }
}
