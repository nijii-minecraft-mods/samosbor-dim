package eu.pb4.polymer.core.impl.interfaces;

import net.minecraft.server.level.ServerPlayer;

public interface ScreenHandlerPlayerContext {
    void polymer$setPlayer(ServerPlayer player);
}
