package eu.pb4.polymer.core.mixin.client.rendering;

import eu.pb4.polymer.core.api.block.PolymerBlock;
import eu.pb4.polymer.core.api.utils.PolymerKeepModel;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.renderer.block.BlockModelShaper;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin(BlockModelShaper.class)
public class BlockModelsMixin {
    @Inject(method = "getModelId(Lnet/minecraft/block/BlockState;)Lnet/minecraft/client/util/ModelIdentifier;", at = @At("HEAD"), cancellable = true, require = 0)
    private static void polymer$skipModels(BlockState state, CallbackInfoReturnable<ModelResourceLocation> cir) {
        if (PolymerKeepModel.useServerModel(state.getBlock())) {
            cir.setReturnValue(new ModelResourceLocation(ResourceLocation.fromNamespaceAndPath("minecraft", "air"), ""));
        }
    }

    @ModifyVariable(method = "getModel", at = @At("HEAD"), require = 0)
    private BlockState polymer$replaceBlockState(BlockState state) {
        return state.getBlock() instanceof PolymerBlock block && !PolymerKeepModel.is(block) ? Blocks.AIR.defaultBlockState() : state;
    }
}
