package eu.pb4.polymer.core.impl.networking.entry;

import I;
import eu.pb4.polymer.core.api.utils.PolymerUtils;
import eu.pb4.polymer.core.impl.interfaces.RegistryExtension;
import eu.pb4.polymer.networking.api.ContextByteBuf;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntList;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.Registry;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.network.ServerGamePacketListenerImpl;

public record PolymerTagEntry(ResourceLocation registry, List<TagData> tags) {

    public static final StreamCodec<ContextByteBuf, PolymerTagEntry> CODEC = StreamCodec.ofMember(PolymerTagEntry::write, PolymerTagEntry::read);

    public static PolymerTagEntry of(Registry<Object> registry, ServerGamePacketListenerImpl handler, int version) {
        if (registry instanceof RegistryExtension && !((RegistryExtension<Object>) registry).polymer$getEntries().isEmpty()) {
            var registryExtension = (RegistryExtension<Object>) registry;

            var out = new ArrayList<TagData>();
            for (var entry : registryExtension.polymer$getTagsInternal().values()){
                var ids = new IntArrayList();

                for (var obj : entry) {
                    if (PolymerUtils.isServerOnly(obj.value())) {
                        ids.add(registry.getId(obj.value()));
                    }
                }

                if (!ids.isEmpty()) {
                    out.add(new TagData(entry.key().location(), ids));
                }
            }

            return out.isEmpty() ? null : new PolymerTagEntry(registry.key().location(), out);
        }
        return null;
    }

    public static PolymerTagEntry read(FriendlyByteBuf buf) {
        var registry = buf.readResourceLocation();
        var size = buf.readVarInt();

        var tags = new ArrayList<TagData>();
        for (int i = 0; i < size; i++) {
            var tagId = buf.readResourceLocation();
            var sizeIds = buf.readVarInt();
            var idList = new IntArrayList(sizeIds);
            for (int a = 0; a < sizeIds; a++) {
                idList.add(buf.readVarInt());
            }
            tags.add(new TagData(tagId, idList));
        }

        return new PolymerTagEntry(registry, tags);
    }

    public void write(FriendlyByteBuf buf) {
        buf.writeResourceLocation(this.registry);
        buf.writeVarInt(this.tags.size());

        for (var tag : this.tags) {
            buf.writeResourceLocation(tag.id);
            buf.writeVarInt(tag.ids.size());
            for (var id : tag.ids) {
                buf.writeVarInt(id);
            }
        }
    }


    public record TagData(ResourceLocation id, IntList ids) {}
}
