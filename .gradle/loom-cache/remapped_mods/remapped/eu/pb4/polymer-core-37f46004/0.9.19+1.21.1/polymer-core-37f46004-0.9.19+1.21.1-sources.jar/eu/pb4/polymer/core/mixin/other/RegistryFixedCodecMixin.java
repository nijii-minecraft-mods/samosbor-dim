package eu.pb4.polymer.core.mixin.other;

import eu.pb4.polymer.common.api.PolymerCommonUtils;
import eu.pb4.polymer.core.api.entity.PolymerEntityUtils;
import eu.pb4.polymer.core.api.utils.PolymerSyncedObject;
import eu.pb4.polymer.core.api.utils.PolymerUtils;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import xyz.nucleoid.packettweaker.PacketContext;

import java.util.Optional;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.RegistryFixedCodec;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.Attributes;

@Mixin(RegistryFixedCodec.class)
public class RegistryFixedCodecMixin {
    @Shadow @Final private ResourceKey<Registry> registry;

    @ModifyVariable(
            method = "encode(Lnet/minecraft/registry/entry/RegistryEntry;Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult;",
            at = @At("HEAD")
    )
    private Holder<?> polymerCore$swapEntry(Holder<?> entry) {
        if (PolymerCommonUtils.isServerNetworkingThread()) {
            var player = PacketContext.get();
            try {
                if (entry.value() instanceof PolymerSyncedObject<?> polymerSyncedObject) {
                    var registry = ((Registry<Registry>) (Object) BuiltInRegistries.REGISTRY).get(this.registry);
                    var x = registry.wrapAsHolder(polymerSyncedObject.getPolymerReplacement(player.getPlayer()));
                    if (x == null) {
                        return (Holder<?>) registry.getHolder(0).orElse(entry);
                    }
                    return x;
                } else if (entry.value() instanceof EntityType<?> type && PolymerEntityUtils.isPolymerEntityType(type)) {
                    return EntityType.MARKER.builtInRegistryHolder();
                } else if (entry.value() instanceof Attribute && PolymerEntityUtils.isPolymerEntityAttribute((Holder<Attribute>) entry)) {
                    return Attributes.SPAWN_REINFORCEMENTS_CHANCE;
                }
            } catch (Throwable e) {
                e.printStackTrace();
            }
        }

        return entry;
    }
}
