package eu.pb4.polymer.core.api.other;

import eu.pb4.polymer.core.api.utils.PolymerSyncedObject;
import eu.pb4.polymer.core.api.utils.PolymerUtils;
import eu.pb4.polymer.core.impl.PolymerImplUtils;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;

/**
 * This class allows for creation of custom sound effects
 * It can be used to play custom sounds for players with resourcepack while keeping fallback for vanilla clients
 */
public class PolymerSoundEvent extends SoundEvent implements PolymerSyncedObject<SoundEvent> {
    @Nullable
    protected final SoundEvent polymerSound;

    @Nullable
    protected final UUID source;

    public static PolymerSoundEvent of(ResourceLocation identifier, @Nullable SoundEvent vanillaEvent) {
        return new PolymerSoundEvent(null, identifier, 16.0F, false, vanillaEvent);
    }

    static PolymerSoundEvent of(ResourceLocation identifier, float distanceToTravel, @Nullable SoundEvent vanillaEvent) {
        return new PolymerSoundEvent(null, identifier, distanceToTravel, true, vanillaEvent);
    }

    public static PolymerSoundEvent of(UUID uuid, ResourceLocation identifier, @Nullable SoundEvent vanillaEvent) {
        return new PolymerSoundEvent(uuid, identifier, 16.0F, false, vanillaEvent);
    }

    static PolymerSoundEvent of(UUID uuid, ResourceLocation identifier, float distanceToTravel, @Nullable SoundEvent vanillaEvent) {
        return new PolymerSoundEvent(uuid, identifier, distanceToTravel, true, vanillaEvent);
    }

    public PolymerSoundEvent(@Nullable UUID uuid, ResourceLocation id, float distanceToTravel, boolean useStaticDistance, @Nullable SoundEvent vanillaEvent) {
        super(id, distanceToTravel, useStaticDistance);
        this.source = uuid;
        this.polymerSound = vanillaEvent;
    }

    @Override
    public SoundEvent getPolymerReplacement(ServerPlayer player) {
        return this.source == null || this.polymerSound == null || PolymerUtils.hasResourcePack(player, this.source) ? this : (this.polymerSound instanceof PolymerSoundEvent pe ? pe.getPolymerReplacement(player) : this.polymerSound);
    }
}
