package eu.pb4.polymer.core.api.block;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Minimalistic implementation of PolymerBlock
*/
public class SimplePolymerBlock extends Block implements PolymerBlock {
    private Block polymerBlock;

    public SimplePolymerBlock(Properties settings, Block polymerBlock) {
        super(settings);
        this.polymerBlock = polymerBlock;
    }

    @Override
    public BlockState getPolymerBlockState(BlockState state) {
        return this.polymerBlock.defaultBlockState();
    }
}
