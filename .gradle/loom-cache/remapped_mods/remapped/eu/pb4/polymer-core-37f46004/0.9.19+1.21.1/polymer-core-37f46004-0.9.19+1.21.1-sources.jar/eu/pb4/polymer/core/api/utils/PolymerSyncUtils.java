package eu.pb4.polymer.core.api.utils;

import I;
import eu.pb4.polymer.common.api.events.SimpleEvent;
import eu.pb4.polymer.core.impl.networking.PolymerServerProtocol;
import eu.pb4.polymer.core.impl.networking.S2CPackets;
import eu.pb4.polymer.networking.api.server.PolymerServerNetworking;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.item.CreativeModeTab;

public final class PolymerSyncUtils {

    private PolymerSyncUtils() {
    }
    /**
     * This event is run before Polymer registry sync
     */
    public static final SimpleEvent<Consumer<ServerGamePacketListenerImpl>> ON_SYNC_STARTED = new SimpleEvent<>();
    /**
     * This event is run when it's suggested to sync custom content
     */
    public static final SimpleEvent<BiConsumer<ServerGamePacketListenerImpl, Boolean>> ON_SYNC_CUSTOM = new SimpleEvent<>();
    /**
     * This event is run after Polymer registry sync
     */
    public static final SimpleEvent<Consumer<ServerGamePacketListenerImpl>> ON_SYNC_FINISHED = new SimpleEvent<>();
    public static final SimpleEvent<BiConsumer<ServerGamePacketListenerImpl, Boolean>> BEFORE_BLOCK_SYNC = new SimpleEvent<>();
    public static final SimpleEvent<BiConsumer<ServerGamePacketListenerImpl, Boolean>> AFTER_BLOCK_SYNC = new SimpleEvent<>();
    public static final SimpleEvent<BiConsumer<ServerGamePacketListenerImpl, Boolean>> BEFORE_BLOCK_STATE_SYNC = new SimpleEvent<>();
    public static final SimpleEvent<BiConsumer<ServerGamePacketListenerImpl, Boolean>> AFTER_BLOCK_STATE_SYNC = new SimpleEvent<>();
    public static final SimpleEvent<BiConsumer<ServerGamePacketListenerImpl, Boolean>> BEFORE_ITEM_SYNC = new SimpleEvent<>();
    public static final SimpleEvent<BiConsumer<ServerGamePacketListenerImpl, Boolean>> AFTER_ITEM_SYNC = new SimpleEvent<>();
    public static final SimpleEvent<BiConsumer<ServerGamePacketListenerImpl, Boolean>> BEFORE_ITEM_GROUP_SYNC = new SimpleEvent<>();
    public static final SimpleEvent<BiConsumer<ServerGamePacketListenerImpl, Boolean>> AFTER_ITEM_GROUP_SYNC = new SimpleEvent<>();
    public static final SimpleEvent<BiConsumer<ServerGamePacketListenerImpl, Boolean>> BEFORE_ENTITY_SYNC = new SimpleEvent<>();
    public static final SimpleEvent<BiConsumer<ServerGamePacketListenerImpl, Boolean>> AFTER_ENTITY_SYNC = new SimpleEvent<>();

    /**
     * Resends synchronization packets to player if their client supports that
     */
    public static void synchronizePolymerRegistries(ServerGamePacketListenerImpl handler) {
        PolymerServerProtocol.sendSyncPackets(handler, true);
    }

    /**
     * Resends synchronization packets to player if their client supports that
     */
    public static void synchronizeCreativeTabs(ServerGamePacketListenerImpl handler) {
        PolymerServerProtocol.sendCreativeSyncPackets(handler);
    }

    /**
     * Sends/Updates Creative tab for player
     */
    public static void sendCreativeTab(CreativeModeTab group, ServerGamePacketListenerImpl handler) {
        PolymerServerProtocol.removeItemGroup(group, handler);
        PolymerServerProtocol.syncItemGroup(group, handler);
    }

    /**
     * Removes creative tab from player
     */
    public static void removeCreativeTab(CreativeModeTab group, ServerGamePacketListenerImpl handler) {
        PolymerServerProtocol.removeItemGroup(group, handler);
        PolymerServerProtocol.removeItemGroup(group, handler);
    }

    /**
     * Rebuild creative search index
     */
    public static void rebuildItemGroups(ServerGamePacketListenerImpl handler) {
        var ver = PolymerServerNetworking.getSupportedVersion(handler, S2CPackets.SYNC_ITEM_GROUP_APPLY_UPDATE);
        if (ver > -1) {
            //handler.sendPacket(new CustomPayloadS2CPacketMixin(S2CPackets.SYNC_ITEM_GROUP_APPLY_UPDATE, PolymerServerNetworking.buf(ver)));
        }
    }

}
