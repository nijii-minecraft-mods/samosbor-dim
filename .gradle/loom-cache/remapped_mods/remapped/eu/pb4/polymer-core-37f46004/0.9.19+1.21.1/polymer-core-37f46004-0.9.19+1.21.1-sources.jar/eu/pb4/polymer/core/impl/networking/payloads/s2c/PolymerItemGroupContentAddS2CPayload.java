package eu.pb4.polymer.core.impl.networking.payloads.s2c;

import eu.pb4.polymer.core.api.item.PolymerItemGroupUtils;
import eu.pb4.polymer.core.api.item.PolymerItemGroupUtils.Contents;
import eu.pb4.polymer.core.api.item.PolymerItemUtils;
import eu.pb4.polymer.core.impl.PolymerImplUtils;
import eu.pb4.polymer.core.impl.networking.S2CPackets;
import eu.pb4.polymer.networking.api.ContextByteBuf;
import xyz.nucleoid.packettweaker.PacketContext;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;

public record PolymerItemGroupContentAddS2CPayload(ResourceLocation groupId, List<ItemStack> stacksMain, List<ItemStack> stacksSearch) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<PolymerItemGroupContentAddS2CPayload> ID = new CustomPacketPayload.Type<>(S2CPackets.SYNC_ITEM_GROUP_CONTENTS_ADD);
    public static final StreamCodec<ContextByteBuf, PolymerItemGroupContentAddS2CPayload> CODEC = StreamCodec.ofMember(PolymerItemGroupContentAddS2CPayload::write, PolymerItemGroupContentAddS2CPayload::read);

    public static PolymerItemGroupContentAddS2CPayload of(CreativeModeTab group, ServerGamePacketListenerImpl handler) {
        List<ItemStack> stacksMain;
        List<ItemStack> stacksSearch;

        var contents = PolymerItemGroupUtils.getContentsFor(handler.player, group);

        if (PolymerItemGroupUtils.isPolymerItemGroup(group)) {
            stacksMain = List.copyOf(contents.main());
            stacksSearch = List.copyOf(contents.search());
        } else {
            stacksMain = new ArrayList<>();
            stacksSearch = new ArrayList<>();
            for (var item : contents.main()) {
                if (PolymerItemUtils.isPolymerServerItem(item, handler.player) || PolymerImplUtils.isServerSideSyncableEntry(BuiltInRegistries.ITEM, item.getItem())) {
                    stacksMain.add(item);
                }
            }

            for (var item : contents.search()) {
                if (PolymerItemUtils.isPolymerServerItem(item, handler.player) || PolymerImplUtils.isServerSideSyncableEntry(BuiltInRegistries.ITEM, item.getItem())) {
                    stacksSearch.add(item);
                }
            }
        }

        return new PolymerItemGroupContentAddS2CPayload(PolymerItemGroupUtils.getId(group), stacksMain, stacksSearch);
    }

    public void write(ContextByteBuf buf) {
        buf.writeResourceLocation(this.groupId);

        ItemStack.LIST_STREAM_CODEC.encode(buf, this.stacksMain);
        ItemStack.LIST_STREAM_CODEC.encode(buf, this.stacksSearch);
    }

    public boolean isNonEmpty() {
        return !this.stacksMain.isEmpty() || !this.stacksSearch.isEmpty();
    }

    public static PolymerItemGroupContentAddS2CPayload read(ContextByteBuf buf) {
        return new PolymerItemGroupContentAddS2CPayload(buf.readResourceLocation(),
                ItemStack.LIST_STREAM_CODEC.decode(buf),
                ItemStack.LIST_STREAM_CODEC.decode(buf)
        );
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return ID;
    }
}
