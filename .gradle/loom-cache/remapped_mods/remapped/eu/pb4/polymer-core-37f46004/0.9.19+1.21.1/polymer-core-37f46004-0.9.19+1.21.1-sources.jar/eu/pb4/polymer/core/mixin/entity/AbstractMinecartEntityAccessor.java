package eu.pb4.polymer.core.mixin.entity;

import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.world.entity.vehicle.AbstractMinecart;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(AbstractMinecart.class)
public interface AbstractMinecartEntityAccessor {
    @Accessor
    static EntityDataAccessor<Integer> getCUSTOM_BLOCK_ID() {
        throw new UnsupportedOperationException();
    }
}
