package eu.pb4.polymer.core.mixin.item.packet;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import eu.pb4.polymer.core.api.item.PolymerItemUtils;
import eu.pb4.polymer.core.impl.networking.TransformingPacketCodec;
import net.minecraft.core.component.DataComponentPredicate;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.item.trading.ItemCost;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import xyz.nucleoid.packettweaker.PacketContext;

@Mixin(ItemCost.class)
public class TradedItemMixin {
    @ModifyExpressionValue(method = "<clinit>", at = @At(value = "INVOKE", target = "Lnet/minecraft/network/codec/PacketCodec;tuple(Lnet/minecraft/network/codec/PacketCodec;Ljava/util/function/Function;Lnet/minecraft/network/codec/PacketCodec;Ljava/util/function/Function;Lnet/minecraft/network/codec/PacketCodec;Ljava/util/function/Function;Lcom/mojang/datafixers/util/Function3;)Lnet/minecraft/network/codec/PacketCodec;"))
    private static StreamCodec<RegistryFriendlyByteBuf, ItemCost> polymerifyTheStack(StreamCodec<RegistryFriendlyByteBuf, ItemCost> original) {
        return new TransformingPacketCodec<>(original, (buf, tradedItem) -> {
            var stack = PolymerItemUtils.getPolymerItemStack(tradedItem.itemStack(), buf.registryAccess(), PacketContext.get().getPlayer());
            return new ItemCost(stack.getItem().builtInRegistryHolder(), stack.getCount(), DataComponentPredicate.allOf(stack.getComponents()));
        }, (buf, tradedItem) -> {
            var stack = PolymerItemUtils.getRealItemStack(tradedItem.itemStack(), buf.registryAccess());
            return new ItemCost(stack.getItem().builtInRegistryHolder(), stack.getCount(), DataComponentPredicate.allOf(stack.getComponents()));
        });
    }
}
