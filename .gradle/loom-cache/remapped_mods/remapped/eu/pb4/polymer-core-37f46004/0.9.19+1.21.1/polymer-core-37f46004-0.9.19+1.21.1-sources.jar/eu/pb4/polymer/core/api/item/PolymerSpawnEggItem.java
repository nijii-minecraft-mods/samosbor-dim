package eu.pb4.polymer.core.api.item;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SpawnEggItem;
import org.jetbrains.annotations.Nullable;

public class PolymerSpawnEggItem extends SpawnEggItem implements PolymerItem {

    private final Item visualItem;

    public PolymerSpawnEggItem(EntityType<? extends Mob> type, Item visualItem, Properties settings) {
        super(type, 0, 0, settings);
        this.visualItem = visualItem;
    }


    @Override
    public Item getPolymerItem(ItemStack itemStack, @Nullable ServerPlayer player) {
        return this.visualItem;
    }
}
