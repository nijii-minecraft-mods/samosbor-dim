package eu.pb4.polymer.core.api.other;

import eu.pb4.polymer.core.api.utils.PolymerSyncedObject;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;
import net.minecraft.core.component.DataComponents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionContents;

public interface PolymerStatusEffect extends PolymerSyncedObject<MobEffect> {
    @Nullable
    default ItemStack getPolymerIcon(ServerPlayer player) {
        var icon = Items.POTION.getDefaultInstance();
        icon.set(DataComponents.POTION_CONTENTS, new PotionContents(Optional.empty(),
                Optional.of(((MobEffect) this).getColor()), List.of() ));
        return icon;
    }

    @Override
    @Nullable
    default MobEffect getPolymerReplacement(ServerPlayer player) {
        return null;
    }
}
