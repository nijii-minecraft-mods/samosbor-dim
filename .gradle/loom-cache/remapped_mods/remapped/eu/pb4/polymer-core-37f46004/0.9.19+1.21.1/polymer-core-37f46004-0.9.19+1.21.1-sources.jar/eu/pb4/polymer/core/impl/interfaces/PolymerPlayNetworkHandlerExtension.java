package eu.pb4.polymer.core.impl.interfaces;

import eu.pb4.polymer.core.api.block.BlockMapper;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
@SuppressWarnings({"unused"})
public interface PolymerPlayNetworkHandlerExtension extends PolymerCommonNetworkHandlerExtension {
    boolean polymer$advancedTooltip();
    void polymer$setAdvancedTooltip(boolean value);

    BlockMapper polymer$getBlockMapper();
    void polymer$setBlockMapper(BlockMapper mapper);

    static PolymerPlayNetworkHandlerExtension of(ServerPlayer player) {
        return (PolymerPlayNetworkHandlerExtension) player.connection;
    }

    static PolymerPlayNetworkHandlerExtension of(ServerGamePacketListenerImpl handler) {
        return (PolymerPlayNetworkHandlerExtension) handler;
    }

    void polymer$delayAfterSequence(Runnable runnable);
}
