package eu.pb4.polymer.resourcepack.mixin;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ArmorMaterial;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(ArmorMaterial.Layer.class)
public interface LayerAccessor {
    @Accessor
    ResourceLocation getId();
}
