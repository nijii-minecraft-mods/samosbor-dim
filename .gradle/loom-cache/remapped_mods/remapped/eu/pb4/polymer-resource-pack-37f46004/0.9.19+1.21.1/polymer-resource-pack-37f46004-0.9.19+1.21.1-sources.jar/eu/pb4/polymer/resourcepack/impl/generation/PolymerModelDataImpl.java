package eu.pb4.polymer.resourcepack.impl.generation;

import eu.pb4.polymer.resourcepack.api.PolymerModelData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;

public record PolymerModelDataImpl(Item item, int value, ResourceLocation modelPath) implements PolymerModelData {
}
