package eu.pb4.polymer.resourcepack.impl.generation;

import eu.pb4.polymer.resourcepack.api.PolymerArmorModel;
import java.util.List;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ArmorMaterial;

public record PolymerArmorModelImpl(int color, ResourceLocation modelId, List<ArmorMaterial.Layer> layers) implements PolymerArmorModel {
    public static final PolymerArmorModel EMPTY = new PolymerArmorModelImpl(-1, ResourceLocation.parse("empty"), List.of());
}
