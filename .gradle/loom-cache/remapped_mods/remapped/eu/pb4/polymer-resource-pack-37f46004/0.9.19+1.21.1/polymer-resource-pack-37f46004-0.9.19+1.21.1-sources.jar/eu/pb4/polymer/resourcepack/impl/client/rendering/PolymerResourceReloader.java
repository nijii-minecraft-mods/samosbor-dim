package eu.pb4.polymer.resourcepack.impl.client.rendering;

import I;
import com.google.gson.Gson;
import com.mojang.blaze3d.systems.RenderSystem;
import eu.pb4.polymer.common.impl.CommonImpl;
import eu.pb4.polymer.common.impl.CommonImplUtils;
import eu.pb4.polymer.resourcepack.impl.PolymerResourcePackImpl;
import eu.pb4.polymer.resourcepack.impl.PolymerResourcePackMod;
import eu.pb4.polymer.resourcepack.mixin.client.ArmorFeatureRendererAccessor;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.PreparableReloadListener;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraft.world.item.ArmorMaterial;


public record PolymerResourceReloader(TextureManager manager) implements PreparableReloadListener {
    private static final Gson GSON = new Gson();
    public static final ResourceLocation POLYMER_ARMOR_ID = CommonImplUtils.id("armors.json");

    @Override
    public CompletableFuture<Void> reload(PreparationBarrier synchronizer, ResourceManager manager, ProfilerFiller prepareProfiler, ProfilerFiller applyProfiler, Executor prepareExecutor, Executor applyExecutor) {
        return CompletableFuture.supplyAsync(() -> {
            PolymerResourcePackMod.ARMOR_TEXTURES.clear();
            PolymerResourcePackMod.hasArmorTextures = false;
            if (PolymerResourcePackImpl.USE_ALT_ARMOR_HANDLER) {
                var polymerArmor = manager.getResource(POLYMER_ARMOR_ID);
                if (polymerArmor.isPresent()) {
                    try {
                        HashMap<String, String> data =  GSON.fromJson(new String(polymerArmor.get().open().readAllBytes()), HashMap.class);

                        for (var entry : data.entrySet()) {
                            var id = ResourceLocation.parse(entry.getValue());
                            var key = Integer.parseInt(entry.getKey());
                            PolymerResourcePackMod.ARMOR_TEXTURES.put(key, List.of(
                                    new ArmorMaterial.Layer(id, "", false)
                            ));
                        }
                        PolymerResourcePackMod.hasArmorTextures = true;
                    } catch (Exception e) {
                        CommonImpl.LOGGER.warn("Invalid armors.json file!", e);
                    }
                }
            }
            return null;
        }, prepareExecutor).thenCompose(synchronizer::wait).thenAcceptAsync(v -> {
            if (PolymerResourcePackMod.hasArmorTextures) {
                for (var id : PolymerResourcePackMod.ARMOR_TEXTURES.values()) {
                    var first = id.getFirst().texture(false);
                    var second = id.getFirst().texture(true);
                    this.manager.register(first, new PolymerArmorResourceTexture(first));
                    this.manager.register(second, new PolymerArmorResourceTexture(second));
                }
            }
        }, (runnable) -> {
            Objects.requireNonNull(runnable);
            RenderSystem.recordRenderCall(runnable::run);
        });
    }

    @Override
    public String getName() {
        return "Polymer Resource Pack Resource Reloader";
    }
}
