package eu.pb4.polymer.resourcepack.mixin.accessors;

import com.mojang.serialization.Codec;
import net.minecraft.server.packs.OverlayMetadataSection;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(OverlayMetadataSection.class)
public interface PackOverlaysMetadataAccessor {
    @Accessor
    static Codec<OverlayMetadataSection> getCODEC() {
        throw new UnsupportedOperationException();
    }
}
