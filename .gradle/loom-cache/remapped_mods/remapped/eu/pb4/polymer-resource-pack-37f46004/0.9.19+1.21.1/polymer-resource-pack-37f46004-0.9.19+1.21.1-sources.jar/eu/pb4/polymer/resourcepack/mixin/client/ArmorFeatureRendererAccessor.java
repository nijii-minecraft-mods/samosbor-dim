package eu.pb4.polymer.resourcepack.mixin.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.resources.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;

@Environment(EnvType.CLIENT)
@Mixin(HumanoidArmorLayer.class)
public interface ArmorFeatureRendererAccessor{
    @Accessor
    static Map<String, ResourceLocation> getARMOR_TEXTURE_CACHE() {
        throw new UnsupportedOperationException();
    }
}
