package eu.pb4.polymer.resourcepack.api;

import org.jetbrains.annotations.ApiStatus;

import java.util.List;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ArmorMaterial;

/**
 * Represents information about armor texture
 */
@ApiStatus.NonExtendable
public interface PolymerArmorModel {
    int color();
    ResourceLocation modelId();
    List<ArmorMaterial.Layer> layers();
    @Deprecated
    default ResourceLocation modelPath() {
        return modelId();
    }
}
