package eu.pb4.polymer.resourcepack.api;

import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomModelData;
import org.jetbrains.annotations.ApiStatus;

/**
 * Represents information about CustomModelData of item
 */
@ApiStatus.NonExtendable
public interface PolymerModelData {
    Item item();
    int value();
    ResourceLocation modelPath();
    default CustomModelData asComponent() {
        return new CustomModelData(value());
    }
    default ItemStack asStack() {
        var stack = item().getDefaultInstance();
        stack.set(DataComponents.CUSTOM_MODEL_DATA, asComponent());
        return stack;
    }
}
