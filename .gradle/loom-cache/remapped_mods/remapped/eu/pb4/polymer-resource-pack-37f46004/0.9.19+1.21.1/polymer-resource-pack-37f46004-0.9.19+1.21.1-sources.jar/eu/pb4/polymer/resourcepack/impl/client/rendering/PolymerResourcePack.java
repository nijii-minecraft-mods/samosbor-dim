package eu.pb4.polymer.resourcepack.impl.client.rendering;

import eu.pb4.polymer.common.impl.client.ClientUtils;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.network.chat.Component;
import net.minecraft.resource.*;
import net.minecraft.server.packs.FilePackResources;
import net.minecraft.server.packs.PackLocationInfo;
import net.minecraft.server.packs.PackSelectionConfig;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.repository.Pack;
import net.minecraft.server.packs.repository.PackSource;
import net.minecraft.server.packs.repository.RepositorySource;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.nio.file.Path;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

@ApiStatus.Internal
@Environment(EnvType.CLIENT)
public class PolymerResourcePack  {
    public static boolean generated = false;

    @Nullable
    public static Pack.ResourcesSupplier setup() {
        Path outputPath = PolymerResourcePackUtils.getMainPath();
        if ((outputPath.toFile().exists() && generated) || PolymerResourcePackUtils.buildMain(outputPath)) {
            generated = true;
            return new FilePackResources.FileResourcesSupplier(outputPath.toFile());
        } else {
            return null;
        }
    }

    public static class Provider implements RepositorySource {
        @Override
        public void loadPacks(Consumer<Pack> profileAdder) {
            if (PolymerResourcePackUtils.hasResources()) {
                var pack = PolymerResourcePack.setup();

                if (pack != null) {
                    profileAdder.accept(Pack.readMetaAndCreate(
                            new PackLocationInfo(ClientUtils.PACK_ID,
                            Component.translatable("text.polymer.resource_pack.name"), PackSource.BUILT_IN, Optional.empty()),
                            pack,
                            PackType.CLIENT_RESOURCES,
                            new PackSelectionConfig(PolymerResourcePackUtils.isRequired(), Pack.Position.TOP, false)
                    ));
                }
            }
        }
    }
}
