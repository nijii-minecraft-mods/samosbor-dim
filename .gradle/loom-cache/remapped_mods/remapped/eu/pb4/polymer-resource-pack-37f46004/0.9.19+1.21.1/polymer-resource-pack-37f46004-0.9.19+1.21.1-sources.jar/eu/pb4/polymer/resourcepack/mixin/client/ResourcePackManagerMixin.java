package eu.pb4.polymer.resourcepack.mixin.client;

import eu.pb4.polymer.resourcepack.impl.client.rendering.PolymerResourcePack;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.server.packs.repository.Pack;
import net.minecraft.server.packs.repository.PackRepository;
import net.minecraft.server.packs.repository.RepositorySource;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.HashSet;
import java.util.Set;
@Environment(EnvType.CLIENT)
@Mixin(PackRepository.class)
public abstract class ResourcePackManagerMixin<T extends Pack> {
    @Shadow
    @Final
    @Mutable
    private Set<RepositorySource> providers;

    @Inject(method = "<init>", at = @At("RETURN"))
    public void polymer_construct(RepositorySource[] providers, CallbackInfo ci) {
        this.providers = new HashSet<>(this.providers);
        this.providers.add(new PolymerResourcePack.Provider());
    }
}
