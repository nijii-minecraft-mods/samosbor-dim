package eu.pb4.polymer.resourcepack.api.model;

import com.google.gson.JsonObject;
import eu.pb4.polymer.common.impl.CommonImplUtils;
import it.unimi.dsi.fastutil.objects.Object2FloatMap;
import it.unimi.dsi.fastutil.objects.Object2FloatOpenHashMap;
import java.util.ArrayList;
import java.util.Comparator;
import net.minecraft.resources.ResourceLocation;

public record ItemOverride(Object2FloatMap<ResourceLocation> predicate, ResourceLocation model) {
    /**
     * All Items
     */
    public static ResourceLocation CUSTOM_MODEL_DATA = ResourceLocation.parse("custom_model_data");
    public static ResourceLocation LEFT_HANDED = ResourceLocation.parse("lefthanded");
    public static ResourceLocation COOLDOWN = ResourceLocation.parse("cooldown");
    public static ResourceLocation DAMAGED = ResourceLocation.parse("damaged");
    public static ResourceLocation DAMAGE = ResourceLocation.parse("damage");

    /**
     * Bows and crossbows
     */
    public static ResourceLocation PULL = ResourceLocation.parse("pull");
    public static ResourceLocation PULLING = ResourceLocation.parse("pulling");
    /**
     * Crossbows
     */
    public static ResourceLocation CHARGED = ResourceLocation.parse("charged");
    public static ResourceLocation FIREWORK = ResourceLocation.parse("firework");
    /**
     * Bundle
     */
    public static ResourceLocation FILLED = ResourceLocation.parse("filled");
    /**
     * Clock
     */
    public static ResourceLocation TIME = ResourceLocation.parse("time");
    /**
     * Compass
     */
    public static ResourceLocation ANGLE = ResourceLocation.parse("angle");
    /**
     * Elytra
     */
    public static ResourceLocation BROKEN = ResourceLocation.parse("broken");
    /**
     * Fishing rod
     */
    public static ResourceLocation CAST = ResourceLocation.parse("cast");
    /**
     * Shield
     */
    public static ResourceLocation BLOCKING = ResourceLocation.parse("blocking");
    /**
     * Trident
     */
    public static ResourceLocation THROWING = ResourceLocation.parse("throwing");
    /**
     * Light
     */
    public static ResourceLocation LEVEL = ResourceLocation.parse("level");
    /**
     * Goat Horn
     */
    public static ResourceLocation TOOTING = ResourceLocation.parse("tooting");

    public static ItemOverride of(ResourceLocation model) {
        return new ItemOverride(new Object2FloatOpenHashMap<>(), model);
    }

    public static ItemOverride of(ResourceLocation model, ResourceLocation key, float value) {
        return of(model).set(key, value);
    }

    public ItemOverride set(ResourceLocation key, float value) {
        this.predicate.put(key, value);
        return this;
    }

    public JsonObject toJson() {
        var object = new JsonObject();
        object.addProperty("model", CommonImplUtils.shortId(this.model));
        var pred = new JsonObject();
        var entries = new ArrayList<>(predicate.keySet());
        entries.sort(Comparator.comparing(x -> x));
        for (var key : entries) {
            pred.addProperty(CommonImplUtils.shortId(key), predicate.getFloat(key));
        }
        object.add("predicate", pred);
        return object;
    }
}
