package eu.pb4.polymer.resourcepack.api.metadata;

import com.google.gson.JsonParser;
import com.mojang.serialization.Codec;
import com.mojang.serialization.JsonOps;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import eu.pb4.polymer.resourcepack.mixin.accessors.PackOverlaysMetadataAccessor;
import eu.pb4.polymer.resourcepack.mixin.accessors.ResourceFilterAccessor;
import java.util.*;
import net.minecraft.SharedConstants;
import net.minecraft.network.chat.Component;
import net.minecraft.server.packs.OverlayMetadataSection;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.metadata.pack.PackMetadataSection;
import net.minecraft.server.packs.resources.ResourceFilterSection;
import net.minecraft.util.InclusiveRange;
import net.minecraft.util.ResourceLocationPattern;

public record PackMcMeta(PackMetadataSection pack, Optional<ResourceFilterSection> filter, Optional<OverlayMetadataSection> overlays, Optional<LanguageResourceMetadata> language) {
    public static final Codec<PackMcMeta> CODEC = RecordCodecBuilder.create(instaince -> instaince.group(
            PackMetadataSection.CODEC.fieldOf("pack").forGetter(PackMcMeta::pack),
            ResourceFilterAccessor.getCODEC().optionalFieldOf("filter").forGetter(PackMcMeta::filter),
            PackOverlaysMetadataAccessor.getCODEC().optionalFieldOf("overlays").forGetter(PackMcMeta::overlays),
            LanguageResourceMetadata.CODEC.optionalFieldOf("language").forGetter(PackMcMeta::language)
    ).apply(instaince, PackMcMeta::new));

    public static PackMcMeta fromString(String string) {
        return CODEC.decode(JsonOps.INSTANCE, JsonParser.parseString(string)).getOrThrow().getFirst();
    }

    public String asString() {
        return CODEC.encodeStart(JsonOps.INSTANCE, this).getOrThrow().toString();
    }

    public static class Builder {
        private PackMetadataSection metadata = new PackMetadataSection(
                Component.literal("Server Resource Pack"),
                SharedConstants.getCurrentVersion().getPackVersion(PackType.CLIENT_RESOURCES),
                Optional.empty()
        );
        private final List<ResourceLocationPattern> filter = new ArrayList<>();
        private final List<OverlayMetadataSection.OverlayEntry> overlay = new ArrayList<>();
        private final Map<String, LanguageDefinition> language = new HashMap<>();

        public Builder metadata(PackMetadataSection metadata) {
            this.metadata = metadata;
            return this;
        }

        public Builder description(Component description) {
            this.metadata = new PackMetadataSection(description, this.metadata.packFormat(), this.metadata.supportedFormats());
            return this;
        }

        public Builder addFilter(ResourceLocationPattern entry) {
            this.filter.add(entry);
            return this;
        }

        public Builder addOverlay(InclusiveRange<Integer> format, String overlay) {
            this.overlay.add(new OverlayMetadataSection.OverlayEntry(format, overlay));
            return this;
        }

        public Builder addOverlay(OverlayMetadataSection.OverlayEntry entry) {
            this.overlay.add(entry);
            return this;
        }

        public Builder addLanguage(String name, LanguageDefinition definition) {
            this.language.put(name, definition);
            return this;
        }

        public PackMcMeta build() {
            return new PackMcMeta(this.metadata,
                    this.filter.isEmpty() ? Optional.empty() : Optional.of(new ResourceFilterSection(this.filter)),
                    this.overlay.isEmpty() ? Optional.empty() : Optional.of(new OverlayMetadataSection(this.overlay)),
                    this.language.isEmpty() ? Optional.empty() : Optional.of(new LanguageResourceMetadata(this.language))
            );
        }
    }
}
