package eu.pb4.polymer.resourcepack.mixin.client.compat;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import eu.pb4.polymer.resourcepack.impl.PolymerResourcePackMod;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ArmorMaterials;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.List;

@Environment(EnvType.CLIENT)
@Mixin(HumanoidArmorLayer.class)
public class armor_ArmorFeatureRendererMixin<T extends LivingEntity, M extends HumanoidModel<T>, A extends HumanoidModel<T>> {
    @WrapOperation(method = "renderArmor", at = @At(value = "INVOKE", target = "Lnet/minecraft/item/ArmorMaterial;layers()Ljava/util/List;"))
    private List<ArmorMaterial.Layer> polymer$changeArmorTexture(ArmorMaterial instance, Operation<List<ArmorMaterial.Layer>> original, @Local ItemStack stack) {
        if (PolymerResourcePackMod.hasArmorTextures && instance == ArmorMaterials.LEATHER.value()) {
            var color = stack.get(DataComponents.DYED_COLOR);
            if (color != null) {
                return PolymerResourcePackMod.ARMOR_TEXTURES.getOrDefault(color.rgb(), PolymerResourcePackMod.LEATHER_OVERRIDE);
            }

            return PolymerResourcePackMod.LEATHER_OVERRIDE;
        }

        return original.call(instance);
    }
}
