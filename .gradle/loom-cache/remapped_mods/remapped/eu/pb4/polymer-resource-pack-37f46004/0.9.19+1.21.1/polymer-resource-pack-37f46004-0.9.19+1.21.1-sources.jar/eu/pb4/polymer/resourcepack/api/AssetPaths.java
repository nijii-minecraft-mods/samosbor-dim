package eu.pb4.polymer.resourcepack.api;

import net.minecraft.resources.ResourceLocation;

public final class AssetPaths {
    public static String PACK_METADATA = "pack.mcmeta";
    public static String PACK_ICON = "pack.png";

    private AssetPaths() {}

    public static String texture(String namespace, String path) {
        return "assets/" + namespace + "/textures/" + path;
    }

    public static String model(String namespace, String path) {
        return "assets/" + namespace + "/models/" + path;
    }

    public static String model(ResourceLocation id) {
        return model(id.getNamespace(), id.getPath());
    }

    public static String texture(ResourceLocation id) {
        return texture(id.getNamespace(), id.getPath());
    }

    public static String blockModel(ResourceLocation id) {
        return model(id.getNamespace(), "block/" + id.getPath() + ".json");
    }

    public static String blockTexture(ResourceLocation id) {
        return texture(id.getNamespace(), "block/" + id.getPath() + ".png");
    }

    public static String blockTextureMetadata(ResourceLocation id) {
        return texture(id.getNamespace(), "block/" + id.getPath() + ".png.mcmeta");
    }

    public static String itemModel(ResourceLocation id) {
        return model(id.getNamespace(), "item/" + id.getPath() + ".json");
    }

    public static String itemTexture(ResourceLocation id) {
        return texture(id.getNamespace(), "item/" + id.getPath() + ".png");
    }

    public static String itemTextureMetadata(ResourceLocation id) {
        return texture(id.getNamespace(), "item/" + id.getPath() + ".png.mcmeta");
    }

    public static String armorTexture(ResourceLocation id, int layer) {
        return texture(id.getNamespace(), "models/armor/" + id.getPath() + "_layer_" + layer + ".png");
    }

    public static String armorOverlayTexture(ResourceLocation id, int layer) {
        return texture(id.getNamespace(), "models/armor/" + id.getPath() + "_layer_" + layer + "_overlay.png");
    }

    public static String armorTexturePolymerMetadata(ResourceLocation id, int layer) {
        return texture(id.getNamespace(), "models/armor/" + id.getPath() + "_layer_" + layer + ".polymer.json");
    }
}
