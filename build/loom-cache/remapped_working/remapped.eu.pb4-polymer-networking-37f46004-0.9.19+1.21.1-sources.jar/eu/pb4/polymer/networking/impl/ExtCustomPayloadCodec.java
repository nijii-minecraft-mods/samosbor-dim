package eu.pb4.polymer.networking.impl;

import io.netty.buffer.ByteBuf;
import java.util.Map;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.ResourceLocation;

public interface ExtCustomPayloadCodec {
    void polymer$setCodecMap(Map<ResourceLocation, StreamCodec<ByteBuf, ?>> codecs);
}
