package eu.pb4.polymer.networking.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import eu.pb4.polymer.networking.impl.ExtCustomPayloadCodec;
import eu.pb4.polymer.networking.impl.ServerPackets;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.ClientboundCustomPayloadPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(ClientboundCustomPayloadPacket.class)
public class CustomPayloadS2CPacketMixin {
    @ModifyExpressionValue(method = "<clinit>", at = @At(value = "INVOKE", target = "Lnet/minecraft/network/packet/CustomPayload;createCodec(Lnet/minecraft/network/packet/CustomPayload$CodecFactory;Ljava/util/List;)Lnet/minecraft/network/codec/PacketCodec;"))
    private static StreamCodec modifyCodec(StreamCodec codec) {
        ((ExtCustomPayloadCodec) codec).polymer$setCodecMap(ServerPackets.PAYLOAD_CODEC);
        return codec;
    }
}
