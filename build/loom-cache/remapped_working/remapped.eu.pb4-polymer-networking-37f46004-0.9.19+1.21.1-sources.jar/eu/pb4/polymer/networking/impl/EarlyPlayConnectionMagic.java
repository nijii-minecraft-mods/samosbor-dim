package eu.pb4.polymer.networking.impl;

import eu.pb4.polymer.networking.api.server.EarlyPlayNetworkHandler;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.common.ServerboundClientInformationPacket;
import net.minecraft.network.protocol.common.ServerboundCustomPayloadPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ClientInformation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerConfigurationPacketListenerImpl;
import org.apache.commons.lang3.mutable.MutableObject;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;

@ApiStatus.Internal
public class EarlyPlayConnectionMagic {
    private static final List<Function<EarlyPlayNetworkHandler.Context, EarlyPlayNetworkHandler>> CONSTRUCTORS = new ArrayList<>();

    public static void handle(ServerPlayer player, ClientInformation options, ServerConfigurationPacketListenerImpl loginHandler, MinecraftServer server, Connection connection, Consumer<ContextImpl> finish) {
        var iterator = new ArrayList<>(CONSTRUCTORS).iterator();

        var context = new ContextImpl(server, player, connection, loginHandler, new ArrayList<>(), (c) -> {
            //connection.disableAutoRead();
            while (iterator.hasNext()) {
                var handler = iterator.next().apply(c);
                if (handler != null) {
                    //connection.enableAutoRead();
                    return;
                }
            }
            finish.accept(c);
        }, new MutableObject<>(options));

        context.continueRunning.accept(context);
    }

    public static void register(Function<EarlyPlayNetworkHandler.Context, @Nullable EarlyPlayNetworkHandler> constructor) {
        CONSTRUCTORS.add(constructor);
    }

    public record ContextImpl(
            MinecraftServer server,
            ServerPlayer player,
            Connection connection,
            ServerConfigurationPacketListenerImpl loginHandler,
            List<Packet<?>> storedPackets,
            Consumer<ContextImpl> continueRunning,
            MutableObject<ClientInformation> options
    ) implements EarlyPlayNetworkHandler.Context {
        public void addStoredPacket(Packet<?> packet) {
            if (packet instanceof ServerboundCustomPayloadPacket || packet instanceof ServerboundClientInformationPacket) {
                this.storedPackets.add(packet);
            }
        }
    }
}
