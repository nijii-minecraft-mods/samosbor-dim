package eu.pb4.polymer.networking.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.authlib.GameProfile;
import eu.pb4.polymer.networking.impl.EarlyPlayConnectionMagic;
import eu.pb4.polymer.networking.impl.ExtClientConnection;
import eu.pb4.polymer.networking.impl.NetImpl;
import net.minecraft.network.Connection;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerGamePacketListener;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.*;
import net.minecraft.server.players.PlayerList;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = ServerConfigurationPacketListenerImpl.class, priority = 900)
public abstract class ServerConfigurationNetworkHandlerMixin extends ServerCommonPacketListenerImpl {
    public ServerConfigurationNetworkHandlerMixin(MinecraftServer server, Connection connection, CommonListenerCookie clientData) {
        super(server, connection, clientData);
    }
    @Shadow
    protected abstract GameProfile playerProfile();


    @WrapOperation(method = "onReady", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/PlayerManager;onPlayerConnect(Lnet/minecraft/network/ClientConnection;Lnet/minecraft/server/network/ServerPlayerEntity;Lnet/minecraft/server/network/ConnectedClientData;)V"))
    private void polymerNet$prePlayHandshakeHackfest(PlayerList manager, Connection connection, ServerPlayer player, CommonListenerCookie clientData, Operation<Void> original) {
        if (NetImpl.IS_DISABLED || true) {
            original.call(manager, connection, player, clientData);
            return;
        }

        EarlyPlayConnectionMagic.handle(player, clientData.clientInformation(), (ServerConfigurationPacketListenerImpl) (Object) this, player.server, connection, (context) -> {
            ((ExtClientConnection) connection).polymerNet$wrongPacketConsumer(context::addStoredPacket);

            if (connection.isConnected()) {
                var oldPlayer = player.server.getPlayerList().getPlayer(this.playerProfile().getId());
                if (oldPlayer != null) {
                    this.disconnect(Component.translatable("multiplayer.disconnect.duplicate_login"));
                } else {
                    //original.call(manager, connection, player, new ConnectedClientData(clientData.gameProfile(), clientData.latency(), context.options().getValue()));
                    ((ExtClientConnection) connection).polymerNet$wrongPacketConsumer(null);
                    if (this.connection.getPacketListener() instanceof ServerGamePacketListener listener) {
                        for (var packetx : context.storedPackets()) {
                            try {
                                //noinspection unchecked
                                ((Packet<ServerGamePacketListener>) packetx).handle(listener);
                            } catch (Throwable e) {
                                e.printStackTrace();
                            }
                        }
                    }
                    //connection.enableAutoRead();
                }
            }
        });
    }
}
