package eu.pb4.polymer.networking.api.server;


import eu.pb4.polymer.common.api.events.SimpleEvent;
import eu.pb4.polymer.networking.impl.*;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.function.BiConsumer;
import net.minecraft.nbt.Tag;
import net.minecraft.nbt.TagType;
import net.minecraft.network.protocol.common.ClientboundCustomPayloadPacket;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.network.ServerCommonPacketListenerImpl;
import net.minecraft.server.network.ServerConfigurationPacketListenerImpl;
import net.minecraft.server.network.ServerGamePacketListenerImpl;

public final class PolymerServerNetworking {
    private PolymerServerNetworking() {
    }

    public static final SimpleEvent<BiConsumer<ServerGamePacketListenerImpl, PolymerHandshakeHandler>> ON_PLAY_SYNC = new SimpleEvent<>();
    public static boolean send(ServerGamePacketListenerImpl handler, CustomPacketPayload payload) {
        handler.send(new ClientboundCustomPayloadPacket(payload));
        return true;
    }

    @Nullable
    public static <T extends Tag> T getMetadata(ServerCommonPacketListenerImpl handler, ResourceLocation identifier, TagType<T> type) {
        var x = ExtClientConnection.of(handler).polymerNet$getMetadataMap().get(identifier);
        if (x != null && x.getType() == type) {
            //noinspection unchecked
            return (T) x;
        }
        return null;
    }

    public static void setServerMetadata(ResourceLocation identifier, @Nullable Tag nbtElement) {
        if (nbtElement == null) {
            ServerPacketRegistry.METADATA.remove(identifier);
        } else {
            ServerPacketRegistry.METADATA.put(identifier, nbtElement);
        }
    }

    public static <T extends CustomPacketPayload> void registerCommonHandler(Class<T> payloadClass, PolymerServerPacketHandler<ServerCommonPacketListenerImpl, T> handler) {
        ServerPacketRegistry.COMMON_PACKET_LISTENERS.computeIfAbsent(payloadClass, (x) -> new ArrayList<>()).add(handler);
    }

    public static <T extends CustomPacketPayload> void registerPlayHandler(Class<T> payloadClass, PolymerServerPacketHandler<ServerGamePacketListenerImpl, T> handler) {
        ServerPacketRegistry.PLAY_PACKET_LISTENERS.computeIfAbsent(payloadClass, (x) -> new ArrayList<>()).add(handler);
    }

    public static <T extends CustomPacketPayload> void registerConfigurationHandler(Class<T> payloadClass, PolymerServerPacketHandler<ServerConfigurationPacketListenerImpl, T> handler) {
        ServerPacketRegistry.CONFIG_PACKET_LISTENERS.computeIfAbsent(payloadClass, (x) -> new ArrayList<>()).add(handler);
    }

    public static int getSupportedVersion(ServerGamePacketListenerImpl handler, ResourceLocation serverPacket) {
        return ExtClientConnection.of(handler).polymerNet$getSupportedVersion(serverPacket);
    }

    public static long getLastPacketReceivedTime(ServerGamePacketListenerImpl handler, ResourceLocation identifier) {
        return ((NetworkHandlerExtension) handler).polymerNet$lastPacketUpdate(identifier);
    }
}
