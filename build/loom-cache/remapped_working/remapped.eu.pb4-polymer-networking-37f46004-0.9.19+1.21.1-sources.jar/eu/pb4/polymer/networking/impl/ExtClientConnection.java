package eu.pb4.polymer.networking.impl;

import io.netty.channel.Channel;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectMap;
import org.jetbrains.annotations.ApiStatus;

import java.util.function.Consumer;
import net.minecraft.nbt.Tag;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.Packet;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.network.ServerCommonPacketListenerImpl;

@ApiStatus.Internal
public interface ExtClientConnection {
    static ExtClientConnection of(ServerCommonPacketListenerImpl networkHandler) {
        return of(NetworkHandlerExtension.of(networkHandler).polymerNet$getConnection());
    }

    boolean polymerNet$hasPolymer();
    String polymerNet$version();

    void polymerNet$setVersion(String version);

    int polymerNet$getSupportedVersion(ResourceLocation identifier);
    void polymerNet$setSupportedVersion(ResourceLocation identifier, int i);
    Object2IntMap<ResourceLocation> polymerNet$getSupportMap();
    Object2ObjectMap<ResourceLocation, Tag> polymerNet$getMetadataMap();

    void polymerNet$wrongPacketConsumer(Consumer<Packet<?>> consumer);
    Channel polymerNet$getChannel();

    static ExtClientConnection of(Connection connection) {
        return (ExtClientConnection) connection;
    }
}
