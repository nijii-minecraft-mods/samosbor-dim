package eu.pb4.polymer.networking.impl;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectMap;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.Connection;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerCommonPacketListenerImpl;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

@ApiStatus.Internal
@SuppressWarnings({"unused"})
public interface NetworkHandlerExtension {

    long polymerNet$lastPacketUpdate(ResourceLocation identifier);
    void polymerNet$savePacketTime(ResourceLocation identifier);
    static NetworkHandlerExtension of(ServerPlayer player) {
        return (NetworkHandlerExtension) player.connection;
    }

    Connection polymerNet$getConnection();

    @Nullable
    RegistryAccess polymer$getDynamicRegistryManager();

    static NetworkHandlerExtension of(ServerCommonPacketListenerImpl handler) {
        return (NetworkHandlerExtension) handler;
    }
}