package eu.pb4.polymer.networking.mixin.client;

import eu.pb4.polymer.networking.impl.NetworkHandlerExtension;
import eu.pb4.polymer.networking.impl.client.ClientPacketRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientCommonPacketListenerImpl;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.common.ClientboundCustomPayloadPacket;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientCommonPacketListenerImpl.class)
public class ClientCommonNetworkHandlerMixin implements NetworkHandlerExtension {
    @Shadow @Final protected Connection connection;

    @Shadow @Final protected Minecraft client;

    @Inject(method = "onCustomPayload(Lnet/minecraft/network/packet/s2c/common/CustomPayloadS2CPacket;)V", at = @At("HEAD"), cancellable = true)
    private void polymerNet$catchPackets(ClientboundCustomPayloadPacket packet, CallbackInfo ci) {
        if (ClientPacketRegistry.handle(this.client, (ClientCommonPacketListenerImpl) (Object) this, packet.payload())) {
            ci.cancel();
        }
    }

    @Override
    public long polymerNet$lastPacketUpdate(ResourceLocation identifier) {
        return 0;
    }

    @Override
    public void polymerNet$savePacketTime(ResourceLocation identifier) {

    }

    @Override
    public Connection polymerNet$getConnection() {
        return this.connection;
    }

    @Override
    public @Nullable RegistryAccess polymer$getDynamicRegistryManager() {
        return null;
    }
}
