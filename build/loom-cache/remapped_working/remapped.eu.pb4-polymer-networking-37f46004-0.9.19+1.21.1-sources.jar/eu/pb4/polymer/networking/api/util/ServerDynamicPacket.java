package eu.pb4.polymer.networking.api.util;

import org.jetbrains.annotations.Nullable;

import java.util.function.BiFunction;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.network.protocol.common.ClientCommonPacketListener;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerCommonPacketListenerImpl;

public interface ServerDynamicPacket extends Packet<ClientCommonPacketListener> {
    static Packet<ClientCommonPacketListener> of(BiFunction<ServerCommonPacketListenerImpl, @Nullable ServerPlayer, Packet<ClientCommonPacketListener>> builder) {
        return (ServerDynamicPacket) builder::apply;
    }

    Packet<ClientCommonPacketListener> createPacket(ServerCommonPacketListenerImpl handler, @Nullable ServerPlayer player);

    @Override
    default PacketType<? extends Packet<ClientCommonPacketListener>> type() {
        throw new UnsupportedOperationException();
    };

    @Override
    default void apply(ClientCommonPacketListener listener) {
        throw new UnsupportedOperationException();
    }

    @Override
    default boolean isSkippable() {
        return true;
    }
}
