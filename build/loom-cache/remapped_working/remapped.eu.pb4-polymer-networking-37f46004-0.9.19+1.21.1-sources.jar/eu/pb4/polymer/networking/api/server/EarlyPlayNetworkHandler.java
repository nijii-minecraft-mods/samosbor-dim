package eu.pb4.polymer.networking.api.server;

import I;
import com.mojang.authlib.GameProfile;
import eu.pb4.polymer.common.impl.CommonImpl;
import eu.pb4.polymer.networking.impl.EarlyPlayConnectionMagic;
import eu.pb4.polymer.networking.impl.TempPlayerLoginAttachments;
import net.minecraft.network.Connection;
import net.minecraft.network.DisconnectionDetails;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.TickablePacketListener;
import net.minecraft.network.chat.Component;
import net.minecraft.network.packet.c2s.common.*;
import net.minecraft.network.packet.c2s.play.*;
import net.minecraft.network.packet.s2c.play.*;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.common.ClientboundCustomPayloadPacket;
import net.minecraft.network.protocol.common.ClientboundDisconnectPacket;
import net.minecraft.network.protocol.common.ClientboundKeepAlivePacket;
import net.minecraft.network.protocol.common.ClientboundPingPacket;
import net.minecraft.network.protocol.common.ServerboundClientInformationPacket;
import net.minecraft.network.protocol.common.ServerboundCustomPayloadPacket;
import net.minecraft.network.protocol.common.ServerboundKeepAlivePacket;
import net.minecraft.network.protocol.common.ServerboundPongPacket;
import net.minecraft.network.protocol.common.ServerboundResourcePackPacket;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.cookie.ServerboundCookieResponsePacket;
import net.minecraft.network.protocol.game.ClientboundLoginPacket;
import net.minecraft.network.protocol.game.ClientboundRespawnPacket;
import net.minecraft.network.protocol.game.CommonPlayerSpawnInfo;
import net.minecraft.network.protocol.game.GameProtocols;
import net.minecraft.network.protocol.game.ServerGamePacketListener;
import net.minecraft.network.protocol.game.ServerboundAcceptTeleportationPacket;
import net.minecraft.network.protocol.game.ServerboundBlockEntityTagQueryPacket;
import net.minecraft.network.protocol.game.ServerboundChangeDifficultyPacket;
import net.minecraft.network.protocol.game.ServerboundChatAckPacket;
import net.minecraft.network.protocol.game.ServerboundChatCommandPacket;
import net.minecraft.network.protocol.game.ServerboundChatCommandSignedPacket;
import net.minecraft.network.protocol.game.ServerboundChatPacket;
import net.minecraft.network.protocol.game.ServerboundChatSessionUpdatePacket;
import net.minecraft.network.protocol.game.ServerboundChunkBatchReceivedPacket;
import net.minecraft.network.protocol.game.ServerboundClientCommandPacket;
import net.minecraft.network.protocol.game.ServerboundCommandSuggestionPacket;
import net.minecraft.network.protocol.game.ServerboundConfigurationAcknowledgedPacket;
import net.minecraft.network.protocol.game.ServerboundContainerButtonClickPacket;
import net.minecraft.network.protocol.game.ServerboundContainerClickPacket;
import net.minecraft.network.protocol.game.ServerboundContainerClosePacket;
import net.minecraft.network.protocol.game.ServerboundContainerSlotStateChangedPacket;
import net.minecraft.network.protocol.game.ServerboundDebugSampleSubscriptionPacket;
import net.minecraft.network.protocol.game.ServerboundEditBookPacket;
import net.minecraft.network.protocol.game.ServerboundEntityTagQueryPacket;
import net.minecraft.network.protocol.game.ServerboundInteractPacket;
import net.minecraft.network.protocol.game.ServerboundJigsawGeneratePacket;
import net.minecraft.network.protocol.game.ServerboundLockDifficultyPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundMoveVehiclePacket;
import net.minecraft.network.protocol.game.ServerboundPaddleBoatPacket;
import net.minecraft.network.protocol.game.ServerboundPickItemPacket;
import net.minecraft.network.protocol.game.ServerboundPlaceRecipePacket;
import net.minecraft.network.protocol.game.ServerboundPlayerAbilitiesPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerInputPacket;
import net.minecraft.network.protocol.game.ServerboundRecipeBookChangeSettingsPacket;
import net.minecraft.network.protocol.game.ServerboundRecipeBookSeenRecipePacket;
import net.minecraft.network.protocol.game.ServerboundRenameItemPacket;
import net.minecraft.network.protocol.game.ServerboundSeenAdvancementsPacket;
import net.minecraft.network.protocol.game.ServerboundSelectTradePacket;
import net.minecraft.network.protocol.game.ServerboundSetBeaconPacket;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.network.protocol.game.ServerboundSetCommandBlockPacket;
import net.minecraft.network.protocol.game.ServerboundSetCommandMinecartPacket;
import net.minecraft.network.protocol.game.ServerboundSetCreativeModeSlotPacket;
import net.minecraft.network.protocol.game.ServerboundSetJigsawBlockPacket;
import net.minecraft.network.protocol.game.ServerboundSetStructureBlockPacket;
import net.minecraft.network.protocol.game.ServerboundSignUpdatePacket;
import net.minecraft.network.protocol.game.ServerboundSwingPacket;
import net.minecraft.network.protocol.game.ServerboundTeleportToEntityPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemOnPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.minecraft.network.protocol.ping.ServerboundPingRequestPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ClientInformation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerConfigurationPacketListenerImpl;
import net.minecraft.world.level.GameType;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;
import xyz.nucleoid.packettweaker.ContextProvidingPacketListener;

import java.util.Optional;
import java.util.function.Function;

/**
 * This api exposes Polymer's early play packets utilities.
 *
 * Use carefully, as client might not be initialized, or it might have leftover state from previous EarlyPlay handlers
 * Use this only if you know what you are doing and you need to do sync/packets before player joins a world.
 */

public class EarlyPlayNetworkHandler implements ServerGamePacketListener, TickablePacketListener, ContextProvidingPacketListener {

    public static void register(Function<Context, EarlyPlayNetworkHandler> constructor) {
        EarlyPlayConnectionMagic.register(constructor);
    }

    private final EarlyPlayConnectionMagic.ContextImpl context;
    private final ResourceLocation identifier;

    private volatile long lastResponse = 0;

    private volatile int keepAliveSent = 0;
    private volatile int keepAliveReceived = 0;
    private volatile int pingsId = 1024;
    private volatile boolean canContinue = true;
    private volatile boolean alreadyContinued;

    public EarlyPlayNetworkHandler(ResourceLocation identifier, Context context) {
        this.context = (EarlyPlayConnectionMagic.ContextImpl) context;
        this.identifier = identifier;

        this.context.connection().setupInboundProtocol(GameProtocols.SERVERBOUND_TEMPLATE.bind(RegistryFriendlyByteBuf.decorator(this.getServer().registryAccess())),
                this);

        this.sendKeepAlive();
    }

    public final ResourceLocation getId() {
        return this.identifier;
    }

    public void handleDisconnect(DisconnectionDetails reason) {

    }

    public void handleKeepAlive(long time) {

    }

    public boolean handleCustomPayload(ServerboundCustomPayloadPacket packet) {
        return false;
    }

    @Override
    public final void tick() {
        if (this.lastResponse++ == 1200) {
            this.disconnect(Component.translatable("multiplayer.disconnect.slow_login"));
        } else if (this.lastResponse == 20) {
            this.sendKeepAlive();
        }

        this.onTick();
    }

    protected void onTick() {
    }

    protected void forceRespawnPacket() {
        ((TempPlayerLoginAttachments) this.getPlayer()).polymerNet$setForceRespawnPacket();
    }

    protected boolean isForcingRespawnPacket() {
        return ((TempPlayerLoginAttachments) this.getPlayer()).polymerNet$getForceRespawnPacket();
    }

    @Override
    public final void handleKeepAlive(ServerboundKeepAlivePacket packet) {
        this.lastResponse = -20;
        this.keepAliveReceived++;
        if (this.canContinue) {
            this.handleKeepAlive(packet.getId());
        } else if (!this.alreadyContinued && this.keepAliveReceived >= this.keepAliveSent) {
            this.alreadyContinued = true;
            this.context.server().execute(() -> this.context.continueRunning().accept(this.context));
        }
    }

    @Override
    public void handlePong(ServerboundPongPacket packet) {

    }

    public final void sendPacket(Packet<?> packet) {
        this.context.connection().send(packet);
        if (packet instanceof ClientboundLoginPacket packet1) {
            if (this.isForcingRespawnPacket()) {
                this.context.connection().send(new ClientboundRespawnPacket(packet1.commonPlayerSpawnInfo(), ClientboundRespawnPacket.KEEP_ALL_DATA));
            }

            this.forceRespawnPacket();
        }
    }

    protected void sendPacket(CustomPacketPayload payload) {
        this.sendPacket(new ClientboundCustomPayloadPacket(payload));
    }

    public final void sendKeepAlive(long value) {
        this.keepAliveSent++;
        this.sendPacket(new ClientboundKeepAlivePacket(value));
    }

    public final void sendKeepAlive() {
        this.sendKeepAlive(System.currentTimeMillis());
    }

    public final void sendPing(int id) {
        this.sendPacket(new ClientboundPingPacket(id));
    }

    public final int sendPing() {
        var id = this.pingsId++;
        this.sendPing(id);
        return id;
    }

    @Override
    public final void handleCustomPayload(ServerboundCustomPayloadPacket packet) {
        if (!handleCustomPayload(packet)) {
            this.context.storedPackets().add(packet);
        }
    }

    @Override
    public void handleResourcePackResponse(ServerboundResourcePackPacket packet) {

    }

    @Override
    public void handleClientInformation(ServerboundClientInformationPacket packet) {
        try {
            this.getPlayer().updateOptions(packet.information());
        } catch (Throwable e) {
            // Ignore
        }

        this.context.options().setValue(packet.information());
    }

    public final void sendInitialGameJoin() {
        if (!this.isForcingRespawnPacket()) {
            var player = this.getPlayer();
            var world = this.getServer().overworld();
            this.sendPacket(new ClientboundLoginPacket(player.getId(), false, this.getServer().levelKeys(), 0, 2, 2,
                    true, false, true, new CommonPlayerSpawnInfo(
                    world.dimensionTypeRegistration(),
                    world.dimension(),
                    0,
                    GameType.ADVENTURE,
                    GameType.ADVENTURE,
                    false,
                    true,
                    Optional.empty(),
                    0
            ), this.getServer().enforceSecureProfile()));
        }
    }

    public final Connection getConnection() {
        return this.context.connection();
    }

    public final void disconnect(Component reason) {
        try {
            CommonImpl.LOGGER.info("Disconnecting {} on {}: {}", this.getConnectionInfo(), this.getId(), reason.getString());
            this.sendPacket(new ClientboundDisconnectPacket(reason));
            this.context.connection().disconnect(reason);
            this.context.storedPackets().clear();
        } catch (Exception var3) {
            CommonImpl.LOGGER.error("Error whilst disconnecting player", var3);
        }

    }

    public final MinecraftServer getServer() {
        return this.context.server();
    }

    public final void continueJoining() {
        if (this.canContinue) {
            this.canContinue = false;
            this.sendKeepAlive();
        }
    }

    public final ServerPlayer getPlayer() {
        return this.context.player();
    }

    public final String getConnectionInfo() {
        if (this.getPlayer().getGameProfile() != null) {
            GameProfile var10000 = this.getPlayer().getGameProfile() ;
            return "" + var10000 + " (" + this.context.connection().getRemoteAddress() + ")";
        } else {
            return String.valueOf(this.context.connection().getRemoteAddress());
        }
    }

    @Override
    public void handleAnimate(ServerboundSwingPacket packet) {

    }

    @Override
    public void handleChat(ServerboundChatPacket packet) {

    }

    @Override
    public void handleChatCommand(ServerboundChatCommandPacket packet) {

    }

    @Override
    public void handleSignedChatCommand(ServerboundChatCommandSignedPacket packet) {

    }

    @Override
    public void handleChatAck(ServerboundChatAckPacket packet) {

    }

    @Override
    public void handleClientCommand(ServerboundClientCommandPacket packet) {

    }

    @Override
    public void handleContainerButtonClick(ServerboundContainerButtonClickPacket packet) {

    }

    @Override
    public void handleContainerClick(ServerboundContainerClickPacket packet) {

    }

    @Override
    public void handlePlaceRecipe(ServerboundPlaceRecipePacket packet) {

    }

    @Override
    public void handleContainerClose(ServerboundContainerClosePacket packet) {

    }

    @Override
    public void handleInteract(ServerboundInteractPacket packet) {

    }

    @Override
    public void handleMovePlayer(ServerboundMovePlayerPacket packet) {

    }


    @Override
    public void handlePlayerAbilities(ServerboundPlayerAbilitiesPacket packet) {

    }

    @Override
    public void handlePlayerAction(ServerboundPlayerActionPacket packet) {

    }

    @Override
    public void handlePlayerCommand(ServerboundPlayerCommandPacket packet) {

    }

    @Override
    public void handlePlayerInput(ServerboundPlayerInputPacket packet) {

    }

    @Override
    public void handleSetCarriedItem(ServerboundSetCarriedItemPacket packet) {

    }

    @Override
    public void handleSetCreativeModeSlot(ServerboundSetCreativeModeSlotPacket packet) {

    }

    @Override
    public void handleSignUpdate(ServerboundSignUpdatePacket packet) {

    }

    @Override
    public void handleUseItemOn(ServerboundUseItemOnPacket packet) {

    }

    @Override
    public void handleUseItem(ServerboundUseItemPacket packet) {

    }

    @Override
    public void handleTeleportToEntityPacket(ServerboundTeleportToEntityPacket packet) {

    }

    @Override
    public void handlePaddleBoat(ServerboundPaddleBoatPacket packet) {

    }

    @Override
    public void handleMoveVehicle(ServerboundMoveVehiclePacket packet) {

    }

    @Override
    public void handleAcceptTeleportPacket(ServerboundAcceptTeleportationPacket packet) {

    }

    @Override
    public void handleRecipeBookSeenRecipePacket(ServerboundRecipeBookSeenRecipePacket packet) {

    }

    @Override
    public void handleRecipeBookChangeSettingsPacket(ServerboundRecipeBookChangeSettingsPacket packet) {

    }

    @Override
    public void handleSeenAdvancements(ServerboundSeenAdvancementsPacket packet) {

    }

    @Override
    public void handleCustomCommandSuggestions(ServerboundCommandSuggestionPacket packet) {

    }

    @Override
    public void handleSetCommandBlock(ServerboundSetCommandBlockPacket packet) {

    }

    @Override
    public void handleSetCommandMinecart(ServerboundSetCommandMinecartPacket packet) {

    }

    @Override
    public void handlePickItem(ServerboundPickItemPacket packet) {

    }

    @Override
    public void handleRenameItem(ServerboundRenameItemPacket packet) {

    }

    @Override
    public void handleSetBeaconPacket(ServerboundSetBeaconPacket packet) {

    }

    @Override
    public void handleSetStructureBlock(ServerboundSetStructureBlockPacket packet) {

    }

    @Override
    public void handleSelectTrade(ServerboundSelectTradePacket packet) {

    }

    @Override
    public void handleEditBook(ServerboundEditBookPacket packet) {

    }

    @Override
    public void handleEntityTagQuery(ServerboundEntityTagQueryPacket packet) {

    }

    @Override
    public void handleContainerSlotStateChanged(ServerboundContainerSlotStateChangedPacket packet) {

    }

    @Override
    public void handleBlockEntityTagQuery(ServerboundBlockEntityTagQueryPacket packet) {

    }

    @Override
    public void handleSetJigsawBlock(ServerboundSetJigsawBlockPacket packet) {

    }

    @Override
    public void handleJigsawGenerate(ServerboundJigsawGeneratePacket packet) {

    }

    @Override
    public void handleChangeDifficulty(ServerboundChangeDifficultyPacket packet) {

    }

    @Override
    public void handleLockDifficulty(ServerboundLockDifficultyPacket packet) {

    }

    @Override
    public void handleChatSessionUpdate(ServerboundChatSessionUpdatePacket packet) {

    }

    @Override
    public void handleConfigurationAcknowledged(ServerboundConfigurationAcknowledgedPacket packet) {

    }

    @Override
    public void handleChunkBatchReceived(ServerboundChunkBatchReceivedPacket packet) {

    }

    @Override
    public void handleDebugSampleSubscription(ServerboundDebugSampleSubscriptionPacket packet) {

    }

    @Override
    public void onDisconnect(DisconnectionDetails info) {
        this.context.storedPackets().clear();
        this.handleDisconnect(info);
    }

    @Override
    public boolean isAcceptingMessages() {
        return this.getConnection().isConnected();
    }

    @Override
    public void handlePingRequest(ServerboundPingRequestPacket packet) {

    }

    @Override
    public void handleCookieResponse(ServerboundCookieResponsePacket packet) {

    }

    @ApiStatus.NonExtendable
    public interface Context {
        MinecraftServer server();
        ServerPlayer player();
    }

    @Override
    public final @Nullable ServerPlayer getPlayerForPacketTweaker() {
        return this.getPlayer();
    }


    @Override
    public GameProfile getGameProfileForPacketTweaker() {
        return this.getPlayer().getGameProfile();
    }

    @Override
    public ClientInformation getClientOptionsForPacketTweaker() {
        return this.context.options().getValue();
    }

    protected final ServerConfigurationPacketListenerImpl getConfigurationNetworkHandler() {
        return this.context.loginHandler();
    }
}
