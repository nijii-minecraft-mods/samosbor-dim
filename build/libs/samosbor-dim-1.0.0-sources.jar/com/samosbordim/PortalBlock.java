package com.samosbordim;

import eu.pb4.polymer.core.api.block.PolymerBlock;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public class PortalBlock extends class_2248 implements PolymerBlock {

    private static final class_5321<class_1937> GIGAKHRUSHCHEVKA_KEY = class_5321.method_29179(class_7924.field_41223, class_2960.method_60655(SamosborDim.MOD_ID, "gigakhrushchevka"));

    public PortalBlock(class_2251 properties) {
        super(properties);
    }

    @Override
    public class_2248 getPolymerReplacement(class_3222 player) {
        return class_2246.field_9973; // Visual placeholder for the portal
    }

    @Override
    public class_2680 getPolymerBlockState(class_2680 state) {
        return class_2246.field_9973.method_9564();
    }

    @Override
    protected class_1269 method_55766(class_2680 blockState, class_1937 level, class_2338 blockPos, class_1657 player, class_3965 blockHitResult) {
        if (!level.field_9236 && player instanceof class_3222 serverPlayer) {
            class_3218 targetLevel;
            if (level.method_27983() == GIGAKHRUSHCHEVKA_KEY) {
                targetLevel = serverPlayer.field_13995.method_3847(class_1937.field_25179);
            } else {
                targetLevel = serverPlayer.field_13995.method_3847(GIGAKHRUSHCHEVKA_KEY);
            }

            if (targetLevel != null) {
                // Find a safe spot in the new dimension (simplistic for now)
                class_2338 targetPos = new class_2338(blockPos.method_10263(), 50, blockPos.method_10260());
                if (targetLevel.method_27983() == GIGAKHRUSHCHEVKA_KEY) {
                    // Try to find a floor block
                    targetPos = new class_2338(blockPos.method_10263(), 5, blockPos.method_10260());
                } else {
                    targetPos = targetLevel.method_43126();
                }

                serverPlayer.method_14251(targetLevel, targetPos.method_10263(), targetPos.method_10264(), targetPos.method_10260(), serverPlayer.method_36454(), serverPlayer.method_36455());
                return class_1269.field_5812;
            }
        }
        return class_1269.field_5811;
    }
}
