package com.samosbordim;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1923;
import net.minecraft.class_1966;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2791;
import net.minecraft.class_2794;
import net.minecraft.class_2893;
import net.minecraft.class_2902;
import net.minecraft.class_3233;
import net.minecraft.class_4543;
import net.minecraft.class_4966;
import net.minecraft.class_5138;
import net.minecraft.class_5539;
import net.minecraft.class_6748;
import net.minecraft.class_7138;

public class GigakhrushchevkaChunkGenerator extends class_2794 {

    public static final MapCodec<GigakhrushchevkaChunkGenerator> CODEC = RecordCodecBuilder.mapCodec(instance ->
            instance.group(
                    class_1966.field_24713.fieldOf("biome_source").forGetter(class_2794::method_12098)
            ).apply(instance, instance.stable(GigakhrushchevkaChunkGenerator::new)));

    public GigakhrushchevkaChunkGenerator(class_1966 biomeSource) {
        super(biomeSource);
    }

    @Override
    protected MapCodec<? extends class_2794> method_28506() {
        return CODEC;
    }

    @Override
    public void method_12108(class_3233 region, long seed, class_7138 randomState, class_4543 biomeManager, class_5138 structureManager, class_2791 chunk, class_2893.class_2894 step) {
    }

    @Override
    public void method_12110(class_3233 region, class_5138 structureManager, class_7138 randomState, class_2791 chunk) {
    }

    @Override
    public void method_12107(class_3233 region) {
    }

    @Override
    public int method_12104() {
        return 1024;
    }

    @Override
    public int method_33730() {
        return 0;
    }
    
    @Override
    public int method_16398() {
        return 0;
    }

    @Override
    public CompletableFuture<class_2791> method_12088(class_6748 blender, class_7138 randomState, class_5138 structureManager, class_2791 chunk) {
        class_1923 chunkPos = chunk.method_12004();
        int minX = chunkPos.method_8326();
        int minZ = chunkPos.method_8328();
        
        class_2680 floorState = ModBlocks.INDUSTRIAL_FLOOR.method_9564();
        class_2680 wallState = ModBlocks.PEELING_WALL.method_9564();
        class_2680 rustyState = ModBlocks.RUSTY_CONCRETE.method_9564();
        class_2680 fogState = ModBlocks.FOG_WINDOW.method_9564();
        class_2680 air = class_2246.field_10124.method_9564();
        class_2680 ironBars = class_2246.field_10576.method_9564();
        
        Random random = new Random(chunkPos.method_8324());

        int roomSize = 16;
        int corridorWidth = 4;
        int floorHeight = 5;

        for (int y = 0; y < method_12104(); y++) {
            boolean isFloor = (y % floorHeight == 0);
            
            for (int x = 0; x < 16; x++) {
                for (int z = 0; z < 16; z++) {
                    int worldX = minX + x;
                    int worldZ = minZ + z;
                    
                    class_2680 state = air;
                    
                    // Main layout: Grid of rooms with a large central corridor
                    boolean inCorridorX = Math.abs(worldX % 64) < corridorWidth;
                    boolean inCorridorZ = Math.abs(worldZ % 64) < corridorWidth;
                    
                    boolean isStairwell = (worldX % 32 >= 12 && worldX % 32 <= 20) && (worldZ % 32 >= 12 && worldZ % 32 <= 20);

                    if (isFloor) {
                        if (isStairwell) {
                            // Hole for stairs, with iron bars around
                            if (worldX % 32 == 12 || worldX % 32 == 20 || worldZ % 32 == 12 || worldZ % 32 == 20) {
                                state = ironBars;
                            } else {
                                // Empty space for falling/stairs
                            }
                        } else {
                            state = (random.nextFloat() > 0.9) ? rustyState : floorState;
                        }
                    } else {
                        // Walls
                        boolean isWallX = (worldX % roomSize == 0);
                        boolean isWallZ = (worldZ % roomSize == 0);
                        
                        if (isStairwell) {
                            if (worldX % 32 == 12 || worldX % 32 == 20 || worldZ % 32 == 12 || worldZ % 32 == 20) {
                                // Add some fences or walls around the stairwell
                                if (y % floorHeight == 1) state = ironBars;
                            }
                        } else if (isWallX || isWallZ) {
                            // Make some exterior walls into fog windows
                            boolean isExterior = (worldX % 128 == 0 || worldZ % 128 == 0);
                            
                            if (isExterior && (y % floorHeight == 2 || y % floorHeight == 3)) {
                                state = fogState;
                            } else {
                                // Internal walls
                                // Leave doors
                                boolean isDoorX = isWallX && (worldZ % roomSize == roomSize / 2 || worldZ % roomSize == roomSize / 2 + 1);
                                boolean isDoorZ = isWallZ && (worldX % roomSize == roomSize / 2 || worldX % roomSize == roomSize / 2 + 1);
                                
                                if (!(isDoorX || isDoorZ) || y % floorHeight >= 3) {
                                    state = (random.nextFloat() > 0.8) ? rustyState : wallState;
                                }
                            }
                        }
                    }
                    
                    chunk.method_12010(new class_2338(worldX, y, worldZ), state, false);
                }
            }
        }
        
        return CompletableFuture.completedFuture(chunk);
    }

    @Override
    public int method_16397(int x, int z, class_2902.class_2903 types, class_5539 levelHeightAccessor, class_7138 randomState) {
        return 1024;
    }

    @Override
    public class_4966 method_26261(int x, int z, class_5539 levelHeightAccessor, class_7138 randomState) {
        return new class_4966(0, new class_2680[0]);
    }

    @Override
    public void method_40450(List<String> list, class_7138 randomState, class_2338 blockPos) {
    }
}
