package com.samosbordim;

import net.fabricmc.api.ModInitializer;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;

public class SamosborDim implements ModInitializer {
    public static final String MOD_ID = "samosbor_dim";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Initializing Samosbor Dimension Mod!");
        
        ModBlocks.registerModBlocks();
        
        class_2378.method_10230(class_7923.field_41157, class_2960.method_60655(MOD_ID, "gigakhrushchevka"), GigakhrushchevkaChunkGenerator.CODEC);
        
        PolymerResourcePackUtils.addModAssets(MOD_ID);
        PolymerResourcePackUtils.markAsRequired();
    }
}
