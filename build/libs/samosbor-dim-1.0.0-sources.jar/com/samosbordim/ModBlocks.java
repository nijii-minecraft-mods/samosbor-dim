package com.samosbordim;

import eu.pb4.polymer.core.api.block.PolymerBlock;
import eu.pb4.polymer.core.api.item.PolymerItem;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4970;
import net.minecraft.class_7923;

public class ModBlocks {

    public static final class_2248 RUSTY_CONCRETE = registerBlock("rusty_concrete", new SamosborBlock(class_4970.class_2251.method_9630(class_2246.field_10038)));
    public static final class_2248 PEELING_WALL = registerBlock("peeling_wall", new SamosborBlock(class_4970.class_2251.method_9630(class_2246.field_10107)));
    public static final class_2248 INDUSTRIAL_FLOOR = registerBlock("industrial_floor", new SamosborBlock(class_4970.class_2251.method_9630(class_2246.field_10360)));
    public static final class_2248 FOG_WINDOW = registerBlock("fog_window", new SamosborBlock(class_4970.class_2251.method_9630(class_2246.field_10399).method_9631(state -> 5)));
    public static final class_2248 PORTAL_DOOR = registerBlock("portal_door", new PortalBlock(class_4970.class_2251.method_9630(class_2246.field_9973)));

    private static class_2248 registerBlock(String name, class_2248 block) {
        registerBlockItem(name, block);
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(SamosborDim.MOD_ID, name), block);
    }

    private static class_1792 registerBlockItem(String name, class_2248 block) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(SamosborDim.MOD_ID, name),
                new PolymerBlockItem(block, new class_1792.class_1793()));
    }

    public static void registerModBlocks() {
        SamosborDim.LOGGER.info("Registering Mod Blocks for " + SamosborDim.MOD_ID);
    }

    public static class SamosborBlock extends class_2248 implements PolymerBlock {
        public SamosborBlock(class_2251 properties) {
            super(properties);
        }

        @Override
        public class_2248 getPolymerReplacement(class_3222 player) {
            return class_2246.field_10340;
        }
        
        @Override
        public class_2680 getPolymerBlockState(class_2680 state) {
            return class_2246.field_10340.method_9564();
        }
    }
    
    public static class PolymerBlockItem extends class_1747 implements PolymerItem {
        public PolymerBlockItem(class_2248 block, class_1793 properties) {
            super(block, properties);
        }

        @Override
        public class_1792 getPolymerItem(class_1799 itemStack, class_3222 player) {
            return class_1802.field_20391;
        }
        
        @Override
        public class_1792 getPolymerReplacement(class_3222 player) {
            return class_1802.field_20391;
        }
    }
}
